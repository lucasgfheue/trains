package com.locomotora.entidad;

/**
 * Los modelos de locomotora. Las medidas están en bloques y salen del estudio de diseño
 * (adelante = hacia el frente, desde el centro de la locomotora; un valor negativo es hacia atrás).
 */
public enum TipoLocomotora {
    // ---------------------------------------------------------------------------------- trenes reales (estilo Traincraft)
    //         id             diésel  tono   vel.   acel.   asiento        chimenea/escape  cilindros            silbato/bocina  largo
    //                                sonido máx.           atrás  alto    adel.  alto      adel. lado  alto     adel.  alto     frente atrás
    SCOTSMAN( "scotsman",     false,  1.1F,  0.40,  0.011,  3.25,  1.15F,  2.81,  2.40,     1.87, 0.53, 0.60,    -2.31, 2.35,    4.13,  8.75),
    F7(       "f7",           true,   1.0F,  0.40,  0.012, -2.60,  1.30F, -2.38,  2.75,     0.0,  0.0,  0.0,      2.13, 2.75,    4.50,  4.50),
    V200(     "v200",         true,   1.2F,  0.40,  0.014, -3.60,  1.15F,  0.0,   2.50,     0.0,  0.0,  0.0,      4.00, 2.30,    5.25,  5.25),
    // ---------------------------------------------------------------------------------- vapor
    MALLARD(  "mallard",      false,  0.95F,  0.40,   0.012,   3.12,   0.85F,   2.31,   2.27,      1.86,  0.53,  0.59,    -1.94,   2.35,     4.00,   9.12),
    BIG_BOY(  "bigboy",       false,  0.80F,  0.34,   0.010,   5.75,   1.30F,   6.38,   2.96,      5.81,  0.53,  0.47,    -2.62,   2.87,     8.12,   16.12),
    GS4(      "gs4",          false,  0.90F,  0.40,   0.011,   3.62,   1.17F,   3.00,   2.70,      2.59,  0.53,  0.59,    -2.50,   2.54,     5.50,   12.88),
    BR01(     "br01",         false,  1.20F,  0.40,   0.011,   3.25,   1.10F,   2.88,   2.64,      1.93,  0.53,  0.56,    -2.12,   2.42,     4.12,   9.38),
    PANNIER(  "pannier",      false,  1.30F,  0.30,   0.016,   1.38,   0.64F,   2.12,   2.20,      2.00,  0.35,  0.50,    -0.62,   1.98,     3.00,   3.06),
    // ---------------------------------------------------------------------------------- diésel
    HST(      "hst",          true,   1.10F,  0.40,   0.015,  -3.75,   0.82F,  -1.25,   2.39,      0.00,  0.00,  0.00,     4.69,   1.54,     5.06,   5.38),
    DELTIC(   "deltic",       true,   1.05F,  0.40,   0.014,  -4.75,   0.73F,   0.00,   2.33,      0.00,  0.00,  0.00,     5.75,   1.54,     6.10,   6.10),
    SD40(     "sd40",         true,   0.95F,  0.34,   0.012,  -3.88,   1.14F,  -0.19,   2.52,      0.00,  0.00,  0.00,     2.38,   2.55,     6.12,   6.12),
    ES44(     "es44",         true,   0.90F,  0.36,   0.013,  -4.50,   1.23F,   1.00,   2.70,      0.00,  0.00,  0.00,     4.00,   2.86,     6.50,   6.50),
    DD51(     "dd51",         true,   1.25F,  0.36,   0.013,   0.00,   0.87F,   2.50,   2.14,      0.00,  0.00,  0.00,     0.62,   2.23,     5.38,   5.38),
    CLASS08(  "class08",      true,   1.15F,  0.25,   0.018,   1.50,   0.79F,   1.50,   1.96,      0.00,  0.00,  0.00,    -0.75,   2.29,     2.62,   2.62),
    // ---------------------------------------------------------------------------------- vapor (segunda tanda)
    ROCKET(   "rocket",       false,  1.35F,  0.30,   0.014,   1.00,   0.71F,   0.81,   2.58,     -0.55,  0.47,  1.13,     0.06,   1.48,     1.19,   3.25),
    JUPITER(  "jupiter",      false,  1.15F,  0.32,   0.013,   1.62,   0.92F,   2.12,   2.77,      1.90,  0.53,  0.44,    -0.38,   2.23,     3.50,   6.00),
    HIAWATHA( "hiawatha",     false,  1.00F,  0.40,   0.012,   2.00,   0.70F,   2.44,   2.45,      2.80,  0.53,  0.59,     1.25,   2.47,     4.50,   9.06),
    T1(       "t1",           false,  0.95F,  0.40,   0.011,   3.75,   1.11F,   4.56,   2.70,      4.81,  0.53,  0.56,    -2.50,   2.66,     7.12,   13.00),
    NWJ(      "nwj",          false,  0.85F,  0.40,   0.011,   2.88,   1.34F,   3.88,   2.77,      4.06,  0.53,  0.50,    -1.88,   2.66,     6.38,   12.50),
    MERCHANT( "merchant",     false,  1.10F,  0.40,   0.012,   3.00,   0.98F,   2.81,   2.45,      2.56,  0.53,  0.53,    -1.88,   2.40,     4.00,   8.50),
    BR9F(     "br9f",         false,  1.10F,  0.36,   0.012,   3.00,   1.09F,   3.31,   2.70,      3.43,  0.53,  0.44,    -1.62,   2.54,     4.81,   8.00),
    D51(      "d51",          false,  1.25F,  0.36,   0.012,   2.62,   1.09F,   2.94,   2.58,      2.90,  0.53,  0.41,    -0.38,   2.60,     4.38,   8.38),
    P36(      "p36",          false,  0.90F,  0.40,   0.011,   3.12,   1.34F,   4.38,   2.89,      3.81,  0.53,  0.53,    -1.88,   2.79,     5.88,   11.25),
    GARRATT(  "garratt",      false,  0.85F,  0.30,   0.010,   2.62,   1.09F,   2.62,   2.58,      7.62,  0.53,  0.41,    -0.88,   2.48,     9.12,   9.12);

    private final String id;
    private final boolean diesel;
    private final float tonoSonido;
    private final double velocidadMaxima;
    private final double aceleracion;
    private final double asientoAtras;
    private final float alturaAsiento;
    private final double chimeneaAdelante;
    private final double chimeneaAlto;
    private final double cilindroAdelante;
    private final double cilindroLado;
    private final double cilindroAlto;
    private final double silbatoAdelante;
    private final double silbatoAlto;
    private final double largoFrente;
    private final double largoAtras;

    TipoLocomotora(String id, boolean diesel, float tonoSonido, double velocidadMaxima, double aceleracion,
                   double asientoAtras, float alturaAsiento, double chimeneaAdelante, double chimeneaAlto,
                   double cilindroAdelante, double cilindroLado, double cilindroAlto,
                   double silbatoAdelante, double silbatoAlto, double largoFrente, double largoAtras) {
        this.id = id;
        this.diesel = diesel;
        this.tonoSonido = tonoSonido;
        this.velocidadMaxima = velocidadMaxima;
        this.aceleracion = aceleracion;
        this.asientoAtras = asientoAtras;
        this.alturaAsiento = alturaAsiento;
        this.chimeneaAdelante = chimeneaAdelante;
        this.chimeneaAlto = chimeneaAlto;
        this.cilindroAdelante = cilindroAdelante;
        this.cilindroLado = cilindroLado;
        this.cilindroAlto = cilindroAlto;
        this.silbatoAdelante = silbatoAdelante;
        this.silbatoAlto = silbatoAlto;
        this.largoFrente = largoFrente;
        this.largoAtras = largoAtras;
    }

    public String id() { return id; }
    /** Las diésel usan bidones de diésel, bocina, motor y humo de escape; las de vapor, carbón y silbato. */
    public boolean diesel() { return diesel; }
    /** Tono del silbato o la bocina (1 = normal). */
    public float tonoSilbato() { return tonoSonido; }
    /** Bloques por tick a toda máquina (0.4 es el tope de los rieles normales). */
    public double velocidadMaxima() { return velocidadMaxima; }
    public double aceleracion() { return aceleracion; }
    public double asientoAtras() { return asientoAtras; }
    public float alturaAsiento() { return alturaAsiento; }
    public double chimeneaAdelante() { return chimeneaAdelante; }
    public double chimeneaAlto() { return chimeneaAlto; }
    public double cilindroAdelante() { return cilindroAdelante; }
    public double cilindroLado() { return cilindroLado; }
    public double cilindroAlto() { return cilindroAlto; }
    public double silbatoAdelante() { return silbatoAdelante; }
    public double silbatoAlto() { return silbatoAlto; }
    public double largoFrente() { return largoFrente; }
    public double largoAtras() { return largoAtras; }
}
