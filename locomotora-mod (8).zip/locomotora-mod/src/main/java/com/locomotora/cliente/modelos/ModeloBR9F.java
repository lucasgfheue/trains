package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "BR 9F Evening Star" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloBR9F {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("br9f"), "main"),
            LocomotoraMod.id("textures/entity/br9f.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, -32.0F, -7.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, -32.0F, -7.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, -32.0F, -7.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, -16.0F, -7.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, -16.0F, -7.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, -16.0F, -7.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi2_0", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, 0.0F, -7.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi2_1", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, 0.0F, -7.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi2_2", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, 0.0F, -7.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi3_0", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, 16.0F, -7.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi3_1", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, 16.0F, -7.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi3_2", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, 16.0F, -7.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi4_0", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, 32.0F, -7.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi4_1", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, 32.0F, -7.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi4_2", DatosModelo.RUEDA, 7.0F, 0.0F, 0.0F, 0.0F, 32.0F, -7.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 7.0F, 3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_i", DatosModelo.MOTRIZ, 7.0F, 3.0F, 0.0F, -42.0F, 0.0F, -10.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_i", DatosModelo.CRUCETA, 7.0F, 3.0F, 0.0F, -42.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, -32.0F, -7.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, -32.0F, -7.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, -32.0F, -7.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -7.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -7.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -7.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd2_0", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, 0.0F, -7.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd2_1", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, 0.0F, -7.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd2_2", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, 0.0F, -7.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd3_0", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, 16.0F, -7.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd3_1", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, 16.0F, -7.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd3_2", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, 16.0F, -7.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd4_0", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, 32.0F, -7.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd4_1", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, 32.0F, -7.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd4_2", DatosModelo.RUEDA, 7.0F, 0.0F, 1.5707963267948966F, 0.0F, 32.0F, -7.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 7.0F, 3.0F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_d", DatosModelo.MOTRIZ, 7.0F, 3.0F, 1.5707963267948966F, -42.0F, 0.0F, -10.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_d", DatosModelo.CRUCETA, 7.0F, 3.0F, 1.5707963267948966F, -42.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -66.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -66.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -66.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -66.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -66.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -66.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 72.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 72.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 72.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 90.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 90.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 90.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 108.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 108.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 108.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 72.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 72.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 72.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 90.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 90.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 90.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 108.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 108.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 108.0F, -5.0F, 1.0471975511965976F, "tender")),
            ModeloBR9F::crearCapa,
            16.0F,
            ModeloBR9F::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -66.0F, 32.0F),
                new DatosModelo.Segmento("tender", 72.0F, 108.0F)));

    private ModeloBR9F() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g0);
        piezas5(g1);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
        escalas1(g0, g1);
        escalas2(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(452, 167).addBox(-7.0F, -7.0F, -6.0F, 14.0F, 14.0F, 2.0F).texOffs(670, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(128, 219).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(160, 248).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-32.0F, -7.0F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(702, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -7.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(734, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -7.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(452, 167).addBox(-7.0F, -7.0F, -6.0F, 14.0F, 14.0F, 2.0F).texOffs(670, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(138, 219).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(166, 248).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-16.0F, -7.0F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(702, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -7.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(734, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -7.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi2_0", CubeListBuilder.create().texOffs(452, 167).addBox(-7.0F, -7.0F, -6.0F, 14.0F, 14.0F, 2.0F).texOffs(670, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(148, 219).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(172, 248).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(0.0F, -7.0F, 0.0F));
        g.addOrReplaceChild("rmi2_1", CubeListBuilder.create().texOffs(702, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -7.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi2_2", CubeListBuilder.create().texOffs(734, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -7.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi3_0", CubeListBuilder.create().texOffs(452, 167).addBox(-7.0F, -7.0F, -6.0F, 14.0F, 14.0F, 2.0F).texOffs(670, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(158, 219).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(178, 248).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(16.0F, -7.0F, 0.0F));
        g.addOrReplaceChild("rmi3_1", CubeListBuilder.create().texOffs(702, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -7.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi3_2", CubeListBuilder.create().texOffs(734, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -7.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi4_0", CubeListBuilder.create().texOffs(452, 167).addBox(-7.0F, -7.0F, -6.0F, 14.0F, 14.0F, 2.0F).texOffs(670, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(168, 219).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(184, 248).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(32.0F, -7.0F, 0.0F));
        g.addOrReplaceChild("rmi4_1", CubeListBuilder.create().texOffs(702, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(32.0F, -7.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi4_2", CubeListBuilder.create().texOffs(734, 208).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 167).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(32.0F, -7.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(224, 248).addBox(-32.0F, -10.5F, -7.5F, 64.0F, 1.0F, 1.0F).texOffs(180, 232).addBox(-33.5F, -11.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(188, 232).addBox(-17.5F, -11.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(196, 232).addBox(-1.5F, -11.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(204, 232).addBox(14.5F, -11.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(212, 232).addBox(30.5F, -11.5F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_i", CubeListBuilder.create().texOffs(756, 251).addBox(-42.0F, -0.5F, -0.5F, 42.0F, 1.0F, 1.0F).texOffs(220, 232).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(0.0F, -10.0F, -8.5F));
        g.addOrReplaceChild("cruceta_i", CubeListBuilder.create().texOffs(178, 219).addBox(-43.392720131306824F, -8.5F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(30, 253).addBox(-51.892720131306824F, -7.5F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_i", CubeListBuilder.create().texOffs(928, 251).addBox(-48.892720131306824F, -5.5F, -9.0F, 14.0F, 1.0F, 1.0F).texOffs(958, 251).addBox(-48.892720131306824F, -9.5F, -9.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_i_0", CubeListBuilder.create().texOffs(132, 184).addBox(-60.892720131306824F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(780, 167).addBox(-60.892720131306824F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.0F, -8.5F));
        g.addOrReplaceChild("cil_i_1", CubeListBuilder.create().texOffs(160, 184).addBox(-60.892720131306824F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(824, 167).addBox(-60.892720131306824F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_2", CubeListBuilder.create().texOffs(188, 184).addBox(-60.892720131306824F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(868, 167).addBox(-60.892720131306824F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_3", CubeListBuilder.create().texOffs(216, 184).addBox(-60.892720131306824F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(912, 167).addBox(-60.892720131306824F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_0", CubeListBuilder.create().texOffs(668, 196).addBox(-61.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(956, 184).addBox(-61.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.0F, -8.5F));
        g.addOrReplaceChild("cil_i_a_1", CubeListBuilder.create().texOffs(674, 196).addBox(-61.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(978, 184).addBox(-61.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_2", CubeListBuilder.create().texOffs(680, 196).addBox(-61.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(1000, 184).addBox(-61.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_3", CubeListBuilder.create().texOffs(686, 196).addBox(-61.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(0, 196).addBox(-61.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_0", CubeListBuilder.create().texOffs(692, 196).addBox(-49.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(22, 196).addBox(-49.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.0F, -8.5F));
        g.addOrReplaceChild("cil_i_b_1", CubeListBuilder.create().texOffs(698, 196).addBox(-49.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(44, 196).addBox(-49.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_2", CubeListBuilder.create().texOffs(704, 196).addBox(-49.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(66, 196).addBox(-49.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_3", CubeListBuilder.create().texOffs(710, 196).addBox(-49.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(88, 196).addBox(-49.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(452, 167).addBox(-7.0F, -7.0F, 4.0F, 14.0F, 14.0F, 2.0F).texOffs(670, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(188, 219).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(190, 248).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-32.0F, -7.0F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(702, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -7.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(734, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -7.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(452, 167).addBox(-7.0F, -7.0F, 4.0F, 14.0F, 14.0F, 2.0F).texOffs(670, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(198, 219).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(196, 248).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-16.0F, -7.0F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(702, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -7.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(734, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -7.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd2_0", CubeListBuilder.create().texOffs(452, 167).addBox(-7.0F, -7.0F, 4.0F, 14.0F, 14.0F, 2.0F).texOffs(670, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(208, 219).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(202, 248).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(0.0F, -7.0F, 0.0F));
        g.addOrReplaceChild("rmd2_1", CubeListBuilder.create().texOffs(702, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -7.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd2_2", CubeListBuilder.create().texOffs(734, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -7.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd3_0", CubeListBuilder.create().texOffs(452, 167).addBox(-7.0F, -7.0F, 4.0F, 14.0F, 14.0F, 2.0F).texOffs(670, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(218, 219).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(208, 248).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(16.0F, -7.0F, 0.0F));
        g.addOrReplaceChild("rmd3_1", CubeListBuilder.create().texOffs(702, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -7.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd3_2", CubeListBuilder.create().texOffs(734, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -7.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd4_0", CubeListBuilder.create().texOffs(452, 167).addBox(-7.0F, -7.0F, 4.0F, 14.0F, 14.0F, 2.0F).texOffs(670, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(228, 219).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(214, 248).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(32.0F, -7.0F, 0.0F));
        g.addOrReplaceChild("rmd4_1", CubeListBuilder.create().texOffs(702, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(32.0F, -7.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd4_2", CubeListBuilder.create().texOffs(734, 208).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 167).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(32.0F, -7.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(354, 248).addBox(-32.0F, -10.5F, 6.5F, 64.0F, 1.0F, 1.0F).texOffs(228, 232).addBox(-33.5F, -11.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(236, 232).addBox(-17.5F, -11.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(244, 232).addBox(-1.5F, -11.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(252, 232).addBox(14.5F, -11.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(260, 232).addBox(30.5F, -11.5F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_d", CubeListBuilder.create().texOffs(842, 251).addBox(-42.0F, -0.5F, -0.5F, 42.0F, 1.0F, 1.0F).texOffs(268, 232).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(0.0F, -10.0F, 8.5F));
        g.addOrReplaceChild("cruceta_d", CubeListBuilder.create().texOffs(238, 219).addBox(-43.392720131306824F, -8.5F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(52, 253).addBox(-51.892720131306824F, -7.5F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_d", CubeListBuilder.create().texOffs(988, 251).addBox(-48.892720131306824F, -5.5F, 8.0F, 14.0F, 1.0F, 1.0F).texOffs(0, 253).addBox(-48.892720131306824F, -9.5F, 8.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_d_0", CubeListBuilder.create().texOffs(244, 184).addBox(-60.892720131306824F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(956, 167).addBox(-60.892720131306824F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.0F, 8.5F));
        g.addOrReplaceChild("cil_d_1", CubeListBuilder.create().texOffs(272, 184).addBox(-60.892720131306824F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(0, 184).addBox(-60.892720131306824F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_2", CubeListBuilder.create().texOffs(300, 184).addBox(-60.892720131306824F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(44, 184).addBox(-60.892720131306824F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_3", CubeListBuilder.create().texOffs(328, 184).addBox(-60.892720131306824F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(88, 184).addBox(-60.892720131306824F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_0", CubeListBuilder.create().texOffs(716, 196).addBox(-61.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(110, 196).addBox(-61.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.0F, 8.5F));
        g.addOrReplaceChild("cil_d_a_1", CubeListBuilder.create().texOffs(722, 196).addBox(-61.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(132, 196).addBox(-61.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_2", CubeListBuilder.create().texOffs(728, 196).addBox(-61.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(154, 196).addBox(-61.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_3", CubeListBuilder.create().texOffs(734, 196).addBox(-61.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(176, 196).addBox(-61.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_0", CubeListBuilder.create().texOffs(740, 196).addBox(-49.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(198, 196).addBox(-49.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.0F, 8.5F));
        g.addOrReplaceChild("cil_d_b_1", CubeListBuilder.create().texOffs(746, 196).addBox(-49.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(220, 196).addBox(-49.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_2", CubeListBuilder.create().texOffs(752, 196).addBox(-49.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(242, 196).addBox(-49.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_3", CubeListBuilder.create().texOffs(758, 196).addBox(-49.392720131306824F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(264, 196).addBox(-49.392720131306824F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rbi0_0", CubeListBuilder.create().texOffs(118, 208).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(864, 228).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(140, 208).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(248, 219).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-66.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi0_1", CubeListBuilder.create().texOffs(886, 228).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(148, 208).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi0_2", CubeListBuilder.create().texOffs(908, 228).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(156, 208).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd0_0", CubeListBuilder.create().texOffs(118, 208).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(864, 228).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(140, 208).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(258, 219).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-66.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd0_1", CubeListBuilder.create().texOffs(886, 228).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(148, 208).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd0_2", CubeListBuilder.create().texOffs(908, 228).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(156, 208).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(0, 167).addBox(-70.0F, -20.0F, 2.0F, 112.0F, 16.0F, 1.0F).texOffs(226, 167).addBox(-70.0F, -20.0F, -3.0F, 112.0F, 16.0F, 1.0F).texOffs(60, 134).addBox(-73.0F, -15.0F, -12.0F, 3.0F, 7.0F, 24.0F).texOffs(276, 232).addBox(-75.0F, -13.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(162, 134).addBox(-70.0F, -21.0F, -12.5F, 106.0F, 1.0F, 25.0F).texOffs(282, 232).addBox(-70.0F, -20.0F, 11.5F, 106.0F, 2.0F, 1.0F).texOffs(496, 232).addBox(-70.0F, -20.0F, -12.5F, 106.0F, 2.0F, 1.0F).texOffs(220, 248).addBox(-64.0F, -30.5F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tope_i_0", CubeListBuilder.create().texOffs(838, 99).addBox(-76.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(90, 99).addBox(-76.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("tope_i_1", CubeListBuilder.create().texOffs(858, 99).addBox(-76.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(148, 99).addBox(-76.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_i_2", CubeListBuilder.create().texOffs(878, 99).addBox(-76.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(206, 99).addBox(-76.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_0", CubeListBuilder.create().texOffs(764, 196).addBox(-77.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(286, 196).addBox(-77.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("tope_ic_1", CubeListBuilder.create().texOffs(770, 196).addBox(-77.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(308, 196).addBox(-77.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_2", CubeListBuilder.create().texOffs(776, 196).addBox(-77.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(330, 196).addBox(-77.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_3", CubeListBuilder.create().texOffs(782, 196).addBox(-77.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(352, 196).addBox(-77.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_0", CubeListBuilder.create().texOffs(898, 99).addBox(-76.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(264, 99).addBox(-76.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("tope_d_1", CubeListBuilder.create().texOffs(918, 99).addBox(-76.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(322, 99).addBox(-76.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_2", CubeListBuilder.create().texOffs(938, 99).addBox(-76.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(380, 99).addBox(-76.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_0", CubeListBuilder.create().texOffs(788, 196).addBox(-77.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(374, 196).addBox(-77.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("tope_dc_1", CubeListBuilder.create().texOffs(794, 196).addBox(-77.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(396, 196).addBox(-77.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_2", CubeListBuilder.create().texOffs(800, 196).addBox(-77.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(418, 196).addBox(-77.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_3", CubeListBuilder.create().texOffs(806, 196).addBox(-77.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(440, 196).addBox(-77.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_0", CubeListBuilder.create().texOffs(576, 56).addBox(-62.0F, -19.0F, -2.5F, 16.0F, 38.0F, 5.0F).texOffs(378, 0).addBox(-62.0F, -2.5F, -19.0F, 16.0F, 5.0F, 38.0F), PartPose.offset(0.0F, -29.5F, 0.0F));
        g.addOrReplaceChild("caja_humo_1", CubeListBuilder.create().texOffs(618, 56).addBox(-62.0F, -19.0F, -2.5F, 16.0F, 38.0F, 5.0F).texOffs(486, 0).addBox(-62.0F, -2.5F, -19.0F, 16.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.5F, 0.0F, 0.2617993877991494F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_2", CubeListBuilder.create().texOffs(660, 56).addBox(-62.0F, -19.0F, -2.5F, 16.0F, 38.0F, 5.0F).texOffs(594, 0).addBox(-62.0F, -2.5F, -19.0F, 16.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.5F, 0.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_3", CubeListBuilder.create().texOffs(702, 56).addBox(-62.0F, -19.0F, -2.5F, 16.0F, 38.0F, 5.0F).texOffs(702, 0).addBox(-62.0F, -2.5F, -19.0F, 16.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.5F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_4", CubeListBuilder.create().texOffs(744, 56).addBox(-62.0F, -19.0F, -2.5F, 16.0F, 38.0F, 5.0F).texOffs(810, 0).addBox(-62.0F, -2.5F, -19.0F, 16.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.5F, 0.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_5", CubeListBuilder.create().texOffs(786, 56).addBox(-62.0F, -19.0F, -2.5F, 16.0F, 38.0F, 5.0F).texOffs(0, 56).addBox(-62.0F, -2.5F, -19.0F, 16.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.5F, 0.0F, 1.3089969389957472F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_0", CubeListBuilder.create().texOffs(828, 56).addBox(-63.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(108, 56).addBox(-63.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offset(0.0F, -29.5F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("puerta_1", CubeListBuilder.create().texOffs(840, 56).addBox(-63.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(186, 56).addBox(-63.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.5F, 0.0F, 0.2617993877991494F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_2", CubeListBuilder.create().texOffs(852, 56).addBox(-63.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(264, 56).addBox(-63.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.5F, 0.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_3", CubeListBuilder.create().texOffs(864, 56).addBox(-63.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(342, 56).addBox(-63.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.5F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_4", CubeListBuilder.create().texOffs(876, 56).addBox(-63.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(420, 56).addBox(-63.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.5F, 0.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_5", CubeListBuilder.create().texOffs(888, 56).addBox(-63.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(498, 56).addBox(-63.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -29.5F, 0.0F, 1.3089969389957472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(710, 232).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -37.86875702787048F, 0.9429324576398823F, 3.0293958569265813F, -0.0008140795485585897F, -0.007225220289547102F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(756, 232).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -38.01687662128411F, 0.9596215276866058F, 3.029395856926578F, -0.0008140795485585843F, -0.007225220289547102F));
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(802, 232).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -38.16499621469775F, 0.9763105977333293F, 3.029395856926577F, -0.0008140795485585897F, -0.007225220289547275F));
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(952, 219).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -38.31311580811139F, 0.992999667780053F, 3.029395856926579F, -0.0008140795485585897F, -0.007225220289547102F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(848, 232).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -37.449112605606985F, 2.781514802150535F, 2.8050016811269938F, -0.0024014193406536F, -0.00686292925075139F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(894, 232).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -37.5898048641133F, 2.830745152631075F, 2.805001681126996F, -0.002401419340653573F, -0.006862929250751044F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(940, 232).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -37.73049712261962F, 2.8799755031116154F, 2.805001681126994F, -0.0024014193406535892F, -0.00686292925075139F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(0, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -37.87118938112594F, 2.9292058535921557F, 2.805001681126993F, -0.0024014193406536F, -0.00686292925075139F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(0, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -36.63086648469478F, 4.480620379887036F, 2.5806058732580603F, -0.0038683471767526957F, -0.0061565088639504335F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(46, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -36.75707651097256F, 4.559923395460258F, 2.580605873258059F, -0.0038683471767526523F, -0.006156508863950087F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(92, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -36.88328653725034F, 4.639226411033479F, 2.5806058732580603F, -0.0038683471767527065F, -0.0061565088639504335F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(48, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -37.00949656352813F, 4.718529426606701F, 2.5806058732580603F, -0.0038683471767526957F, -0.00615650886395026F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(138, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -35.455048942334656F, 5.95504894233466F, 2.3562077069393506F, -0.005141306079040025F, -0.005141374030531436F));
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(184, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -35.56044803865917F, 6.060448038659167F, 2.356207706939352F, -0.005141306079039939F, -0.005141374030531262F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(230, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -35.66584713498368F, 6.165847134983673F, 2.356207706939352F, -0.005141306079040025F, -0.005141374030531609F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(96, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -35.77124623130818F, 6.271246231308181F, 2.3562077069393523F, -0.005141306079040004F, -0.005141374030531262F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(276, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -33.980620379887036F, 7.130866484694777F, 2.1318069228818053F, -0.006156462800088277F, -0.0038684204873895727F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(322, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -34.05992339546026F, 7.257076510972562F, 2.131806922881805F, -0.006156462800088167F, -0.0038684204873897458F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(368, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -34.13922641103348F, 7.383286537250344F, 2.1318069228818044F, -0.006156462800088254F, -0.0038684204873895727F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(144, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -34.21852942660671F, 7.509496563528128F, 2.1318069228818044F, -0.006156462800088254F, -0.0038684204873897458F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(414, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -32.28151480215053F, 7.949112605606979F, 1.907403780271642F, -0.006862909461828971F, -0.002401475894728747F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(460, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -32.330745152631074F, 8.089804864113297F, 1.9074037802716417F, -0.006862909461828885F, -0.0024014758947289204F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(506, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -32.379975503111616F, 8.230497122619614F, 1.907403780271642F, -0.006862909461829015F, -0.002401475894728747F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(192, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -32.42920585359216F, 8.371189381125934F, 1.907403780271642F, -0.006862909461828971F, -0.0024014758947289204F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(552, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -30.442932457639884F, 8.36875702787048F, 1.6829990054638875F, -0.007225217895336709F, -0.0008141007980377249F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(598, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -30.459621527686608F, 8.516876621284114F, 1.6829990054638877F, -0.0072252178953366225F, -0.0008141007980377249F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(644, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -30.47631059773333F, 8.664996214697751F, 1.6829990054638877F, -0.007225217895336753F, -0.0008141007980377249F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(240, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -30.492999667780055F, 8.813115808111387F, 1.6829990054638875F, -0.007225217895336709F, -0.0008141007980377249F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(690, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -28.557067542360116F, 8.368757027870478F, 1.4585936481259059F, -0.007225217895336709F, 0.0008141007980377249F));
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(736, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -28.540378472313392F, 8.516876621284114F, 1.4585936481259054F, -0.0072252178953366225F, 0.0008141007980377249F));
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(782, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -28.52368940226667F, 8.664996214697751F, 1.4585936481259056F, -0.007225217895336753F, 0.0008141007980377249F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(288, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -28.507000332219945F, 8.813115808111387F, 1.4585936481259056F, -0.007225217895336709F, 0.0008141007980377249F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(828, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -26.718485197849468F, 7.94911260560698F, 1.2341888733181514F, -0.006862909461828971F, 0.0024014758947288337F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(874, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -26.669254847368926F, 8.089804864113297F, 1.2341888733181516F, -0.006862909461828885F, 0.0024014758947288337F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(920, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -26.620024496888384F, 8.230497122619614F, 1.2341888733181514F, -0.006862909461829015F, 0.0024014758947288337F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(336, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -26.57079414640784F, 8.371189381125934F, 1.2341888733181516F, -0.006862909461828993F, 0.0024014758947288337F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(966, 236).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -25.019379620112964F, 7.13086648469478F, 1.0097857307079887F, -0.006156462800088254F, 0.0038684204873896595F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(0, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -24.940076604539748F, 7.257076510972563F, 1.0097857307079883F, -0.006156462800088167F, 0.0038684204873895727F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(46, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -24.860773588966524F, 7.383286537250346F, 1.0097857307079883F, -0.006156462800088277F, 0.0038684204873896595F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(384, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -24.7814705733933F, 7.50949656352813F, 1.0097857307079885F, -0.006156462800088277F, 0.0038684204873896595F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(92, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -23.54495105766534F, 5.9550489423346615F, 0.7853849466504426F, -0.005141306079040004F, 0.005141374030531522F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(138, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -23.439551961340833F, 6.060448038659168F, 0.7853849466504431F, -0.005141306079039939F, 0.005141374030531262F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(184, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -23.33415286501633F, 6.165847134983675F, 0.7853849466504429F, -0.005141306079040047F, 0.005141374030531436F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(432, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -23.22875376869182F, 6.271246231308183F, 0.7853849466504426F, -0.005141306079040004F, 0.005141374030531436F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(230, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -22.369133515305222F, 4.4806203798870365F, 0.5609867803317327F, -0.0038683471767526957F, 0.0061565088639504335F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(276, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -22.24292348902744F, 4.559923395460258F, 0.5609867803317329F, -0.0038683471767526523F, 0.00615650886395026F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(322, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -22.116713462749654F, 4.63922641103348F, 0.5609867803317328F, -0.003868347176752717F, 0.00615650886395026F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(480, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -21.990503436471872F, 4.718529426606702F, 0.5609867803317328F, -0.003868347176752685F, 0.0061565088639504335F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(368, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -21.550887394393023F, 2.781514802150538F, 0.33659097246279923F, -0.0024014193406536057F, 0.006862929250751304F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(414, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -21.410195135886706F, 2.8307451526310783F, 0.336590972462799F, -0.002401419340653573F, 0.006862929250751304F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(460, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -21.269502877380386F, 2.8799755031116185F, 0.3365909724627996F, -0.0024014193406536F, 0.006862929250751218F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(528, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -21.12881061887407F, 2.929205853592159F, 0.33659097246279934F, -0.0024014193406535892F, 0.00686292925075139F));
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(506, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -21.131242972129524F, 0.9429324576398852F, 0.1121967966632145F, -0.0008140795485585956F, 0.007225220289547188F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(552, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -20.983123378715884F, 0.9596215276866087F, 0.11219679666321485F, -0.0008140795485585847F, 0.007225220289547102F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(598, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -20.83500378530225F, 0.9763105977333323F, 0.11219679666321519F, -0.0008140795485585901F, 0.007225220289547188F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(576, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -20.686884191888613F, 0.9929996677800559F, 0.11219679666321553F, -0.0008140795485585901F, 0.007225220289547102F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(644, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -21.13124297212952F, -0.9429324576398812F, -0.11219679666321285F, 0.0008140795485585892F, 0.007225220289547188F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(690, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -20.983123378715884F, -0.9596215276866048F, -0.11219679666321414F, 0.0008140795485585838F, 0.007225220289547015F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(736, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -20.83500378530225F, -0.9763105977333284F, -0.11219679666321448F, 0.0008140795485585892F, 0.007225220289547275F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(624, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -20.68688419188861F, -0.9929996677800519F, -0.11219679666321397F, 0.0008140795485585892F, 0.007225220289547102F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(782, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -21.55088739439302F, -2.781514802150534F, -0.3365909724628004F, 0.0024014193406535892F, 0.006862929250751304F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(828, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -21.410195135886703F, -2.8307451526310743F, -0.33659097246279923F, 0.002401419340653573F, 0.006862929250751218F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(874, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -21.269502877380383F, -2.8799755031116145F, -0.336590972462799F, 0.0024014193406536F, 0.00686292925075139F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(672, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -21.128810618874063F, -2.9292058535921552F, -0.3365909724627995F, 0.0024014193406536F, 0.006862929250751304F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(920, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -22.369133515305222F, -4.480620379887034F, -0.5609867803317325F, 0.003868347176752685F, 0.006156508863950347F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(966, 239).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -22.24292348902744F, -4.559923395460254F, -0.5609867803317325F, 0.0038683471767526523F, 0.006156508863950347F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(0, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -22.116713462749654F, -4.639226411033476F, -0.5609867803317327F, 0.0038683471767526957F, 0.006156508863950347F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(720, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -21.99050343647187F, -4.718529426606699F, -0.5609867803317328F, 0.003868347176752717F, 0.006156508863950347F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(46, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -23.544951057665337F, -5.955048942334657F, -0.7853849466504418F, 0.005141306079040025F, 0.005141374030531436F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(92, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -23.43955196134083F, -6.060448038659165F, -0.7853849466504415F, 0.005141306079039939F, 0.005141374030531436F));
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(138, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -23.33415286501632F, -6.165847134983672F, -0.7853849466504412F, 0.005141306079040004F, 0.005141374030531436F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(768, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -23.228753768691814F, -6.2712462313081785F, -0.7853849466504418F, 0.005141306079040025F, 0.005141374030531349F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(184, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -25.01937962011296F, -7.130866484694775F, -1.0097857307079878F, 0.006156462800088277F, 0.0038684204873896595F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(230, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -24.940076604539737F, -7.257076510972559F, -1.009785730707988F, 0.006156462800088189F, 0.0038684204873896595F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(276, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -24.860773588966516F, -7.383286537250342F, -1.009785730707988F, 0.006156462800088254F, 0.0038684204873896595F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(816, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -24.781470573393293F, -7.509496563528126F, -1.0097857307079876F, 0.006156462800088232F, 0.0038684204873896595F));
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(322, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -26.718485197849454F, -7.9491126056069765F, -1.2341888733181503F, 0.006862909461829015F, 0.0024014758947289204F));
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(368, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -26.66925484736892F, -8.089804864113294F, -1.2341888733181499F, 0.006862909461828907F, 0.0024014758947288337F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(414, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -26.620024496888377F, -8.230497122619612F, -1.23418887331815F, 0.006862909461829015F, 0.0024014758947288337F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(864, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -26.570794146407835F, -8.37118938112593F, -1.23418887331815F, 0.00686290946182895F, 0.0024014758947289204F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(460, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -28.557067542360116F, -8.368757027870476F, -1.458593648125905F, 0.007225217895336753F, 0.0008141007980378115F));
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(506, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -28.54037847231339F, -8.516876621284112F, -1.4585936481259052F, 0.0072252178953366225F, 0.0008141007980377249F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(552, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -28.523689402266665F, -8.66499621469775F, -1.4585936481259052F, 0.007225217895336753F, 0.0008141007980377249F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(912, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -28.507000332219942F, -8.813115808111387F, -1.4585936481259054F, 0.007225217895336709F, 0.0008141007980377249F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(598, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -30.442932457639884F, -8.368757027870478F, -1.6829990054638875F, 0.007225217895336709F, -0.0008141007980377249F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(644, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -30.459621527686608F, -8.516876621284114F, -1.6829990054638877F, 0.0072252178953366225F, -0.0008141007980377249F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(690, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -30.47631059773333F, -8.664996214697751F, -1.6829990054638877F, 0.007225217895336753F, -0.0008141007980377249F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(960, 224).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -30.492999667780055F, -8.813115808111387F, -1.6829990054638875F, 0.007225217895336709F, -0.0008141007980377249F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(736, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -32.28151480215053F, -7.949112605606981F, -1.9074037802716417F, 0.006862909461828971F, -0.0024014758947289204F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(782, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -32.330745152631074F, -8.089804864113297F, -1.9074037802716415F, 0.006862909461828885F, -0.002401475894728747F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(828, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -32.379975503111616F, -8.230497122619614F, -1.9074037802716415F, 0.006862909461829015F, -0.0024014758947289204F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(0, 228).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -32.42920585359216F, -8.371189381125934F, -1.9074037802716417F, 0.006862909461828971F, -0.002401475894728747F));
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(874, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -33.980620379887036F, -7.13086648469478F, -2.1318069228818044F, 0.006156462800088254F, -0.0038684204873897458F));
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(920, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -34.05992339546025F, -7.257076510972562F, -2.131806922881805F, 0.006156462800088167F, -0.0038684204873893993F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(966, 242).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -34.139226411033476F, -7.383286537250345F, -2.1318069228818057F, 0.006156462800088254F, -0.0038684204873897458F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(48, 228).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -34.2185294266067F, -7.509496563528129F, -2.1318069228818053F, 0.006156462800088277F, -0.0038684204873895727F));
        g.addOrReplaceChild("caldera_96", CubeListBuilder.create().texOffs(0, 245).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -35.455048942334656F, -5.9550489423346615F, -2.356207706939352F, 0.005141306079040004F, -0.005141374030531609F));
        g.addOrReplaceChild("caldera_97", CubeListBuilder.create().texOffs(46, 245).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -35.56044803865917F, -6.060448038659168F, -2.3562077069393506F, 0.00514130607903996F, -0.005141374030531089F));
        g.addOrReplaceChild("caldera_98", CubeListBuilder.create().texOffs(92, 245).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -35.66584713498367F, -6.165847134983675F, -2.3562077069393506F, 0.005141306079040004F, -0.005141374030531436F));
        g.addOrReplaceChild("caldera_99", CubeListBuilder.create().texOffs(96, 228).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -35.77124623130818F, -6.271246231308182F, -2.356207706939351F, 0.005141306079040025F, -0.005141374030531436F));
        g.addOrReplaceChild("caldera_100", CubeListBuilder.create().texOffs(138, 245).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -36.63086648469478F, -4.480620379887041F, -2.5806058732580603F, 0.0038683471767526957F, -0.006156508863950607F));
        g.addOrReplaceChild("caldera_101", CubeListBuilder.create().texOffs(184, 245).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -36.75707651097256F, -4.559923395460262F, -2.5806058732580603F, 0.003868347176752674F, -0.006156508863950087F));
        g.addOrReplaceChild("caldera_102", CubeListBuilder.create().texOffs(230, 245).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -36.88328653725034F, -4.639226411033484F, -2.5806058732580586F, 0.0038683471767526957F, -0.0061565088639504335F));
        g.addOrReplaceChild("caldera_103", CubeListBuilder.create().texOffs(144, 228).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -37.009496563528124F, -4.718529426606707F, -2.5806058732580586F, 0.0038683471767526957F, -0.00615650886395026F));
        g.addOrReplaceChild("caldera_104", CubeListBuilder.create().texOffs(276, 245).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -37.44911260560697F, -2.781514802150544F, -2.8050016811269938F, 0.0024014193406536057F, -0.00686292925075139F));
        g.addOrReplaceChild("caldera_105", CubeListBuilder.create().texOffs(322, 245).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -37.58980486411329F, -2.830745152631084F, -2.8050016811269938F, 0.002401419340653573F, -0.006862929250751218F));
        g.addOrReplaceChild("caldera_106", CubeListBuilder.create().texOffs(368, 245).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -37.73049712261961F, -2.8799755031116248F, -2.805001681126994F, 0.0024014193406536057F, -0.00686292925075139F));
        g.addOrReplaceChild("caldera_107", CubeListBuilder.create().texOffs(192, 228).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -37.87118938112593F, -2.9292058535921655F, -2.805001681126994F, 0.002401419340653611F, -0.006862929250751218F));
        g.addOrReplaceChild("caldera_108", CubeListBuilder.create().texOffs(414, 245).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.75F, -37.86875702787047F, -0.942932457639888F, -3.029395856926578F, 0.0008140795485585959F, -0.007225220289547102F));
        g.addOrReplaceChild("caldera_109", CubeListBuilder.create().texOffs(460, 245).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.25F, -38.01687662128411F, -0.9596215276866117F, -3.029395856926577F, 0.000814079548558585F, -0.007225220289547275F));
        g.addOrReplaceChild("caldera_110", CubeListBuilder.create().texOffs(506, 245).addBox(-10.5F, -1.0F, -1.0F, 21.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.25F, -38.16499621469775F, -0.9763105977333353F, -3.0293958569265755F, 0.0008140795485585959F, -0.007225220289547102F));
        g.addOrReplaceChild("caldera_111", CubeListBuilder.create().texOffs(240, 228).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.75F, -38.31311580811139F, -0.9929996677800591F, -3.029395856926576F, 0.0008140795485586013F, -0.007225220289547102F));
        g.addOrReplaceChild("chimenea55_0", CubeListBuilder.create().texOffs(766, 208).addBox(-5.0F, -41.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(588, 167).addBox(-1.0F, -41.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offset(-55.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea55_1", CubeListBuilder.create().texOffs(790, 208).addBox(-5.0F, -41.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(612, 167).addBox(-1.0F, -41.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-55.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea55_2", CubeListBuilder.create().texOffs(814, 208).addBox(-5.0F, -41.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(636, 167).addBox(-1.0F, -41.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-55.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea55_3", CubeListBuilder.create().texOffs(838, 208).addBox(-5.0F, -41.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(660, 167).addBox(-1.0F, -41.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-55.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("copa55_0", CubeListBuilder.create().texOffs(288, 228).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(356, 184).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offset(-55.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("copa55_1", CubeListBuilder.create().texOffs(312, 228).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(380, 184).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-55.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("copa55_2", CubeListBuilder.create().texOffs(336, 228).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(404, 184).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-55.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("copa55_3", CubeListBuilder.create().texOffs(360, 228).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(428, 184).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-55.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("chimenea50_0", CubeListBuilder.create().texOffs(862, 208).addBox(-5.0F, -41.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(684, 167).addBox(-1.0F, -41.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offset(-50.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea50_1", CubeListBuilder.create().texOffs(886, 208).addBox(-5.0F, -41.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(708, 167).addBox(-1.0F, -41.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-50.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea50_2", CubeListBuilder.create().texOffs(910, 208).addBox(-5.0F, -41.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(732, 167).addBox(-1.0F, -41.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-50.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea50_3", CubeListBuilder.create().texOffs(934, 208).addBox(-5.0F, -41.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(756, 167).addBox(-1.0F, -41.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-50.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("copa50_0", CubeListBuilder.create().texOffs(384, 228).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(452, 184).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offset(-50.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("copa50_1", CubeListBuilder.create().texOffs(408, 228).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(476, 184).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-50.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("copa50_2", CubeListBuilder.create().texOffs(432, 228).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(500, 184).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-50.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("copa50_3", CubeListBuilder.create().texOffs(456, 228).addBox(-5.0F, -42.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(524, 184).addBox(-1.0F, -42.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-50.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("domo_0", CubeListBuilder.create().texOffs(930, 228).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-13.614752861305579F, -37.67830806393077F, 0.6701232371976483F, 0.07891475032283476F, 0.010386778017985534F, -1.6604609033111029F));
        g.addOrReplaceChild("domo_1", CubeListBuilder.create().texOffs(942, 228).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-13.85639320475216F, -38.82700641892781F, 0.6331974257059422F, 0.07392532651640002F, 0.04170284334270705F, -1.9387796090360496F));
        g.addOrReplaceChild("domo_2", CubeListBuilder.create().texOffs(60, 232).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-14.333873260875087F, -39.66441492150743F, 0.5602322151290824F, 0.06154168533106165F, 0.07290447886926735F, -2.2519705897285363F));
        g.addOrReplaceChild("domo_3", CubeListBuilder.create().texOffs(832, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.03846634744119F, -40.298319024476406F, 0.45256115688689325F, 0.04327797316167612F, 0.09682410651452762F, -2.563582615172655F));
        g.addOrReplaceChild("domo_4", CubeListBuilder.create().texOffs(552, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.969257359497727F, -40.72789543167236F, 0.3103240910098027F, 0.0234707562103759F, 0.11029877611100593F, -2.8407460319425635F));
        g.addOrReplaceChild("domo_5", CubeListBuilder.create().texOffs(74, 253).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.24605130307666F, -40.94529297370636F, 0.11521324237466748F, 0.005743150072623238F, 0.151248427368369F, -3.0691589231335668F));
        g.addOrReplaceChild("domo_6", CubeListBuilder.create().texOffs(562, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.827322772778532F, -37.67830806393077F, 1.7326412942324207F, 0.3843041050397767F, 0.03494474116657898F, -1.6560252880461153F));
        g.addOrReplaceChild("domo_7", CubeListBuilder.create().texOffs(572, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.057249872982446F, -38.82700641892781F, 1.6371675331953863F, 0.36111088773480515F, 0.14034920232426878F, -1.9219858385652704F));
        g.addOrReplaceChild("domo_8", CubeListBuilder.create().texOffs(840, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.511584621657462F, -39.66441492150743F, 1.4485118802195083F, 0.3026959217140364F, 0.24555443094611487F, -2.2271661684345903F));
        g.addOrReplaceChild("domo_9", CubeListBuilder.create().texOffs(848, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.182023352653903F, -40.298319024476406F, 1.170122307453361F, 0.21459820238426133F, 0.3264627627914412F, -2.5400136440322525F));
        g.addOrReplaceChild("domo_10", CubeListBuilder.create().texOffs(114, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-16.067695319699993F, -40.72789543167236F, 0.8023603791553625F, 0.11722620386214422F, 0.3759014550024245F, -2.8255388741708334F));
        g.addOrReplaceChild("domo_11", CubeListBuilder.create().texOffs(582, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.252172166361621F, -37.67830806393077F, 2.416761738347055F, 0.7360504728333915F, 0.054767507499565535F, -1.6422323659880307F));
        g.addOrReplaceChild("domo_12", CubeListBuilder.create().texOffs(592, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.458688783614043F, -38.82700641892781F, 2.283590877500977F, 0.6993803657812054F, 0.2216449598758065F, -1.8685208725966451F));
        g.addOrReplaceChild("domo_13", CubeListBuilder.create().texOffs(856, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.86676454029249F, -39.66441492150743F, 2.0204459522630236F, 0.6021059715794934F, 0.39468650644016157F, -2.1436866775754653F));
        g.addOrReplaceChild("domo_14", CubeListBuilder.create().texOffs(864, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.46894122445716F, -40.298319024476406F, 1.6321363407723966F, 0.4420232995627113F, 0.5363385921680205F, -2.454853464197945F));
        g.addOrReplaceChild("domo_15", CubeListBuilder.create().texOffs(122, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-16.264436746591976F, -40.72789543167236F, 1.1191663682282056F, 0.23534767534756446F, 0.5447698791026188F, -2.7924249282852793F));
        g.addOrReplaceChild("domo_16", CubeListBuilder.create().texOffs(602, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.8927349078395F, -37.67830806393077F, 2.914977203940961F, 1.0652894035663258F, 0.06589541459899866F, -1.622483364962499F));
        g.addOrReplaceChild("domo_17", CubeListBuilder.create().texOffs(612, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.063954586070173F, -38.82700641892781F, 2.754353168300189F, 1.0284657917767628F, 0.26997039173833376F, -1.7889761825174504F));
        g.addOrReplaceChild("domo_18", CubeListBuilder.create().texOffs(872, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.402283775661825F, -39.66441492150743F, 2.4369609131058416F, 0.9237570186598567F, 0.49561056795588265F, -2.006439009803173F));
        g.addOrReplaceChild("domo_19", CubeListBuilder.create().texOffs(880, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.90153899043549F, -40.298319024476406F, 1.9686012698666526F, 0.7256496239082494F, 0.7031966539201702F, -2.291727976339258F));
        g.addOrReplaceChild("domo_20", CubeListBuilder.create().texOffs(130, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-16.56107181227802F, -40.72789543167236F, 1.3498825304284636F, 0.37743993167236295F, 0.70966353414391F, -2.727804955264202F));
        g.addOrReplaceChild("domo_21", CubeListBuilder.create().texOffs(954, 228).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.772318335986888F, -37.67830806393077F, 3.2454156211722527F, 1.3282486116066174F, 0.06958527778300325F, -1.6025348451446173F));
        g.addOrReplaceChild("domo_22", CubeListBuilder.create().texOffs(888, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.895070314463073F, -38.82700641892781F, 3.0665834321247636F, 1.3011693445254529F, 0.28811057560919473F, -1.7059331573517649F));
        g.addOrReplaceChild("domo_23", CubeListBuilder.create().texOffs(896, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.137627582574915F, -39.66441492150743F, 2.713211960933084F, 1.21989255677864F, 0.5440706032116122F, -1.8483585192422087F));
        g.addOrReplaceChild("domo_24", CubeListBuilder.create().texOffs(904, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.49555703327425F, -40.298319024476406F, 2.1917596146025184F, 1.0447498394052437F, 0.809235472219285F, -2.063148330557264F));
        g.addOrReplaceChild("domo_25", CubeListBuilder.create().texOffs(138, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-16.96839379822882F, -40.72789543167236F, 1.502903640233337F, 0.5681017178086744F, 0.8930483605148094F, -2.5920081053564976F));
        g.addOrReplaceChild("domo_26", CubeListBuilder.create().texOffs(24, 219).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.13841298073595F, -37.67830806393077F, 3.4107477745401047F, 1.5221840134315983F, 0.0699483012824305F, -1.5812930533174652F));
        g.addOrReplaceChild("domo_27", CubeListBuilder.create().texOffs(80, 219).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.185889024082975F, -38.82700641892781F, 3.222805285192764F, 1.5118795575762647F, 0.2916084952791898F, -1.6157565345324838F));
        g.addOrReplaceChild("domo_28", CubeListBuilder.create().texOffs(70, 232).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-17.279701437682874F, -39.66441492150743F, 2.8514319082082658F, 1.4799178377129285F, 0.5614275801533937F, -1.6649763942878189F));
        g.addOrReplaceChild("domo_29", CubeListBuilder.create().texOffs(80, 232).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-17.41813565542443F, -40.298319024476406F, 2.3034150631012964F, 1.4049172037533708F, 0.8661819873759653F, -1.7472103115668602F));
        g.addOrReplaceChild("domo_30", CubeListBuilder.create().texOffs(912, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.601011882982796F, -40.72789543167236F, 1.5794664981684354F, 1.2213841821541722F, 1.1688863356250212F, -1.9287888522781986F));
        g.addOrReplaceChild("domo_31", CubeListBuilder.create().texOffs(146, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.85186868837372F, -40.94529297370636F, 0.5864045420514867F, 0.36075812310102723F, 1.3077500595524136F, -2.787815913415452F));
        g.addOrReplaceChild("domo_32", CubeListBuilder.create().texOffs(38, 219).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-18.861587019244183F, -37.67830806393077F, 3.4107477745401047F, 1.6194086401570753F, 0.0699483012824152F, -1.56029960027257F));
        g.addOrReplaceChild("domo_33", CubeListBuilder.create().texOffs(92, 219).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-18.814110975898252F, -38.82700641892781F, 3.2228052851927647F, 1.6297130960121688F, 0.2916084952791406F, -1.5258361190583465F));
        g.addOrReplaceChild("domo_34", CubeListBuilder.create().texOffs(90, 232).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-18.720298562300517F, -39.66441492150743F, 2.8514319082082658F, 1.6616748158747725F, 0.561427580153384F, -1.4766162593041314F));
        g.addOrReplaceChild("domo_35", CubeListBuilder.create().texOffs(100, 232).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-18.581864344562156F, -40.298319024476406F, 2.303415063101297F, 1.7366754498326762F, 0.8661819873762023F, -1.3943823420269F));
        g.addOrReplaceChild("domo_36", CubeListBuilder.create().texOffs(920, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.398988117008003F, -40.72789543167236F, 1.5794664981684357F, 1.9202084714282943F, 1.1688863356259502F, -1.2128038013190983F));
        g.addOrReplaceChild("domo_37", CubeListBuilder.create().texOffs(154, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.148131311622866F, -40.94529297370636F, 0.5864045420514868F, 2.780834530481421F, 1.3077500595575087F, -0.35377674018183575F));
        g.addOrReplaceChild("domo_38", CubeListBuilder.create().texOffs(966, 228).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.22768166401311F, -37.67830806393077F, 3.245415621172253F, 1.8133440419831757F, 0.0695852777830036F, -1.5390578084451754F));
        g.addOrReplaceChild("domo_39", CubeListBuilder.create().texOffs(928, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.104929685536924F, -38.82700641892781F, 3.0665834321247645F, 1.84042330906434F, 0.2881105756091945F, -1.435659496238028F));
        g.addOrReplaceChild("domo_40", CubeListBuilder.create().texOffs(936, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.86237241742508F, -39.66441492150743F, 2.7132119609330845F, 1.921700096811153F, 0.5440706032116124F, -1.2932341343475855F));
        g.addOrReplaceChild("domo_41", CubeListBuilder.create().texOffs(944, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.50444296672575F, -40.298319024476406F, 2.191759614602519F, 2.0968428141845514F, 0.8092354722192847F, -1.0784443230325278F));
        g.addOrReplaceChild("domo_42", CubeListBuilder.create().texOffs(162, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.03160620177118F, -40.72789543167236F, 1.5029036402333371F, 2.5734909357811198F, 0.8930483605148094F, -0.5495845482332957F));
        g.addOrReplaceChild("domo_43", CubeListBuilder.create().texOffs(622, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.1072650921605F, -37.67830806393077F, 2.9149772039409614F, 2.076303250023468F, 0.06589541459899842F, -1.5191092886272948F));
        g.addOrReplaceChild("domo_44", CubeListBuilder.create().texOffs(632, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.93604541392983F, -38.82700641892781F, 2.7543531683001894F, 2.11312686181303F, 0.2699703917383339F, -1.3526164710723425F));
        g.addOrReplaceChild("domo_45", CubeListBuilder.create().texOffs(952, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.597716224338175F, -39.66441492150743F, 2.4369609131058416F, 2.2178356349299353F, 0.49561056795588276F, -1.135153643786621F));
        g.addOrReplaceChild("domo_46", CubeListBuilder.create().texOffs(960, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.09846100956451F, -40.298319024476406F, 1.968601269866653F, 2.415943029681542F, 0.7031966539201708F, -0.8498646772505354F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("domo_47", CubeListBuilder.create().texOffs(170, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.438928187721977F, -40.72789543167236F, 1.3498825304284638F, 2.7641527219174287F, 0.70966353414391F, -0.4137876983255915F));
        g.addOrReplaceChild("domo_48", CubeListBuilder.create().texOffs(642, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.74782783363838F, -37.67830806393077F, 2.4167617383470557F, 2.4055421807564F, 0.05476750749956518F, -1.4993602876017629F));
        g.addOrReplaceChild("domo_49", CubeListBuilder.create().texOffs(652, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.54131121638596F, -38.82700641892781F, 2.2835908775009774F, 2.4422122878085872F, 0.22164495987580674F, -1.2730717809931482F));
        g.addOrReplaceChild("domo_50", CubeListBuilder.create().texOffs(968, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.13323545970751F, -39.66441492150743F, 2.0204459522630236F, 2.5394866820102986F, 0.39468650644016195F, -0.9979059760143293F));
        g.addOrReplaceChild("domo_51", CubeListBuilder.create().texOffs(976, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.531058775542842F, -40.298319024476406F, 1.632136340772397F, 2.6995693540270813F, 0.536338592168021F, -0.6867391893918483F));
        g.addOrReplaceChild("domo_52", CubeListBuilder.create().texOffs(178, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.735563253408028F, -40.72789543167236F, 1.119166368228206F, 2.9062449782422286F, 0.5447698791026189F, -0.34916772530451406F));
        g.addOrReplaceChild("domo_53", CubeListBuilder.create().texOffs(662, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.17267722722147F, -37.67830806393077F, 1.7326412942324216F, 2.7572885485500156F, 0.03494474116657922F, -1.4855673655436774F));
        g.addOrReplaceChild("domo_54", CubeListBuilder.create().texOffs(672, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.942750127017554F, -38.82700641892781F, 1.6371675331953874F, 2.780481765854989F, 0.1403492023242689F, -1.219606815024522F));
        g.addOrReplaceChild("domo_55", CubeListBuilder.create().texOffs(984, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.488415378342538F, -39.66441492150743F, 1.4485118802195092F, 2.8388967318757583F, 0.2455544309461141F, -0.9144264851552044F));
        g.addOrReplaceChild("domo_56", CubeListBuilder.create().texOffs(992, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.817976647346097F, -40.298319024476406F, 1.1701223074533618F, 2.926994451205533F, 0.32646276279144065F, -0.6015790095575402F));
        g.addOrReplaceChild("domo_57", CubeListBuilder.create().texOffs(186, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.932304680300007F, -40.72789543167236F, 0.8023603791553631F, 3.024366449727649F, 0.3759014550024246F, -0.3160537794189599F));
        g.addOrReplaceChild("domo_58", CubeListBuilder.create().texOffs(978, 228).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.38524713869442F, -37.67830806393077F, 0.6701232372101994F, 3.0626779032654876F, 0.010386778018180942F, -1.4811317502786803F));
        g.addOrReplaceChild("domo_59", CubeListBuilder.create().texOffs(990, 228).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.14360679524784F, -38.82700641892781F, 0.6331974257178017F, 3.067667327072016F, 0.04170284334348956F, -1.202813044553706F));
        g.addOrReplaceChild("domo_60", CubeListBuilder.create().texOffs(110, 232).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-21.666126739124913F, -39.66441492150743F, 0.5602322151395751F, 3.080050968257587F, 0.07290447887062972F, -0.8896220638612057F));
        g.addOrReplaceChild("domo_61", CubeListBuilder.create().texOffs(1000, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.96153365255881F, -40.298319024476406F, 0.45256115689536947F, 3.0983146804273143F, 0.09682410651632807F, -0.5780100384170885F));
        g.addOrReplaceChild("domo_62", CubeListBuilder.create().texOffs(682, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.030742640502275F, -40.72789543167236F, 0.3103240910156149F, 3.1181218973789826F, 0.11029877611305004F, -0.3008466216471993F));
        g.addOrReplaceChild("domo_63", CubeListBuilder.create().texOffs(84, 253).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.75394869692334F, -40.94529297370636F, 0.11521324237682537F, 3.1358495035170626F, 0.15124842737115876F, -0.0724337304562263F));
        g.addOrReplaceChild("domo_64", CubeListBuilder.create().texOffs(1002, 228).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.385247138694425F, -37.67830806393077F, -0.6701232371850969F, -3.0626779032684306F, -0.010386778017790282F, -1.4811317502786994F));
        g.addOrReplaceChild("domo_65", CubeListBuilder.create().texOffs(0, 232).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.14360679524784F, -38.82700641892781F, -0.6331974256940824F, -3.067667327074771F, -0.04170284334192439F, -1.2028130445537781F));
        g.addOrReplaceChild("domo_66", CubeListBuilder.create().texOffs(120, 232).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-21.666126739124913F, -39.66441492150743F, -0.5602322151185892F, -3.0800509682598762F, -0.07290447886790483F, -0.8896220638613108F));
        g.addOrReplaceChild("domo_67", CubeListBuilder.create().texOffs(1008, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.96153365255881F, -40.298319024476406F, -0.4525611568784167F, -3.098314680428921F, -0.0968241065127263F, -0.5780100384171871F));
        g.addOrReplaceChild("domo_68", CubeListBuilder.create().texOffs(692, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.030742640502275F, -40.72789543167236F, -0.31032409100399033F, -3.118121897379853F, -0.11029877610896031F, -0.3008466216472602F));
        g.addOrReplaceChild("domo_69", CubeListBuilder.create().texOffs(94, 253).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.75394869692334F, -40.94529297370636F, -0.11521324237250954F, -3.1358495035172775F, -0.15124842736557909F, -0.07243373045622628F));
        g.addOrReplaceChild("domo_70", CubeListBuilder.create().texOffs(702, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.172677227221467F, -37.67830806393077F, -1.732641294232419F, -2.7572885485500156F, -0.03494474116657929F, -1.4855673655436774F));
        g.addOrReplaceChild("domo_71", CubeListBuilder.create().texOffs(712, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.942750127017554F, -38.82700641892781F, -1.6371675331953846F, -2.7804817658549887F, -0.14034920232426878F, -1.219606815024522F));
        g.addOrReplaceChild("domo_72", CubeListBuilder.create().texOffs(1016, 245).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.488415378342538F, -39.66441492150743F, -1.448511880219507F, -2.8388967318757583F, -0.24555443094611407F, -0.9144264851552044F));
        g.addOrReplaceChild("domo_73", CubeListBuilder.create().texOffs(0, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.817976647346097F, -40.298319024476406F, -1.1701223074533598F, -2.926994451205533F, -0.32646276279144043F, -0.6015790095575402F));
        g.addOrReplaceChild("domo_74", CubeListBuilder.create().texOffs(194, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.932304680300003F, -40.72789543167236F, -0.8023603791553616F, -3.024366449727649F, -0.37590145500242406F, -0.3160537794189599F));
        g.addOrReplaceChild("domo_75", CubeListBuilder.create().texOffs(722, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.74782783363838F, -37.67830806393077F, -2.4167617383470543F, -2.405542180756404F, -0.054767507499565535F, -1.4993602876017618F));
        g.addOrReplaceChild("domo_76", CubeListBuilder.create().texOffs(732, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.54131121638596F, -38.82700641892781F, -2.283590877500976F, -2.4422122878085895F, -0.22164495987580635F, -1.273071780993148F));
        g.addOrReplaceChild("domo_77", CubeListBuilder.create().texOffs(8, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.13323545970751F, -39.66441492150743F, -2.0204459522630227F, -2.5394866820103004F, -0.3946865064401613F, -0.9979059760143287F));
        g.addOrReplaceChild("domo_78", CubeListBuilder.create().texOffs(16, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.53105877554284F, -40.298319024476406F, -1.6321363407723957F, -2.6995693540270826F, -0.53633859216802F, -0.6867391893918479F));
        g.addOrReplaceChild("domo_79", CubeListBuilder.create().texOffs(202, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.735563253408028F, -40.72789543167236F, -1.1191663682282051F, -2.906244978242229F, -0.5447698791026185F, -0.34916772530451406F));
        g.addOrReplaceChild("domo_80", CubeListBuilder.create().texOffs(742, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.1072650921605F, -37.67830806393077F, -2.914977203940961F, -2.076303250023466F, -0.06589541459899872F, -1.5191092886272939F));
        g.addOrReplaceChild("domo_81", CubeListBuilder.create().texOffs(752, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.93604541392983F, -38.82700641892781F, -2.754353168300189F, -2.1131268618130306F, -0.2699703917383334F, -1.3526164710723434F));
        g.addOrReplaceChild("domo_82", CubeListBuilder.create().texOffs(24, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.597716224338175F, -39.66441492150743F, -2.4369609131058416F, -2.2178356349299375F, -0.4956105679558826F, -1.1351536437866203F));
        g.addOrReplaceChild("domo_83", CubeListBuilder.create().texOffs(32, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.098461009564513F, -40.298319024476406F, -1.9686012698666524F, -2.4159430296815447F, -0.70319665392017F, -0.849864677250534F));
        g.addOrReplaceChild("domo_84", CubeListBuilder.create().texOffs(210, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.43892818772198F, -40.72789543167236F, -1.3498825304284636F, -2.76415272191743F, -0.70966353414391F, -0.4137876983255915F));
        g.addOrReplaceChild("domo_85", CubeListBuilder.create().texOffs(12, 232).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.22768166401311F, -37.67830806393077F, -3.2454156211722522F, -1.813344041983177F, -0.06958527778300325F, -1.539057808445176F));
        g.addOrReplaceChild("domo_86", CubeListBuilder.create().texOffs(40, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.104929685536927F, -38.82700641892781F, -3.0665834321247636F, -1.840423309064341F, -0.2881105756091946F, -1.4356594962380278F));
        g.addOrReplaceChild("domo_87", CubeListBuilder.create().texOffs(48, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.862372417425085F, -39.66441492150743F, -2.713211960933084F, -1.9217000968111526F, -0.544070603211612F, -1.2932341343475855F));
        g.addOrReplaceChild("domo_88", CubeListBuilder.create().texOffs(56, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.50444296672575F, -40.298319024476406F, -2.1917596146025184F, -2.0968428141845514F, -0.8092354722192847F, -1.0784443230325278F));
        g.addOrReplaceChild("domo_89", CubeListBuilder.create().texOffs(218, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.031606201771183F, -40.72789543167236F, -1.5029036402333367F, -2.5734909357811198F, -0.8930483605148093F, -0.5495845482332957F));
        g.addOrReplaceChild("domo_90", CubeListBuilder.create().texOffs(52, 219).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-18.861587019275554F, -37.67830806393077F, -3.4107477745401047F, -1.619408640158843F, -0.06994830128243942F, -1.5602996002721872F));
        g.addOrReplaceChild("domo_91", CubeListBuilder.create().texOffs(104, 219).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-18.814110975927893F, -38.82700641892781F, -3.222805285192764F, -1.6297130960143158F, -0.2916084952792183F, -1.525836119056708F));
        g.addOrReplaceChild("domo_92", CubeListBuilder.create().texOffs(130, 232).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-18.72029856232674F, -39.66441492150743F, -2.8514319082082658F, -1.661674815878075F, -0.5614275801533994F, -1.4766162593007268F));
        g.addOrReplaceChild("domo_93", CubeListBuilder.create().texOffs(140, 232).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-18.581864344583337F, -40.298319024476406F, -2.3034150631012964F, -1.736675449838589F, -0.8661819873758286F, -1.3943823420206387F));
        g.addOrReplaceChild("domo_94", CubeListBuilder.create().texOffs(64, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.39898811702253F, -40.72789543167236F, -1.5794664981684354F, -1.9202084714398628F, -1.1688863356244834F, -1.2128038013072497F));
        g.addOrReplaceChild("domo_95", CubeListBuilder.create().texOffs(226, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.14813131162826F, -40.94529297370636F, -0.5864045420514867F, -2.780834530493019F, -1.3077500595494633F, -0.3537767401700019F));
        g.addOrReplaceChild("domo_96", CubeListBuilder.create().texOffs(66, 219).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.138412980767313F, -37.67830806393077F, -3.4107477745401047F, -1.522184013433366F, -0.06994830128240621F, -1.5812930533170817F));
        g.addOrReplaceChild("domo_97", CubeListBuilder.create().texOffs(116, 219).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.185889024112612F, -38.82700641892781F, -3.2228052851927647F, -1.5118795575784112F, -0.29160849527911215F, -1.6157565345308462F));
        g.addOrReplaceChild("domo_98", CubeListBuilder.create().texOffs(150, 232).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-17.2797014377091F, -39.66441492150743F, -2.8514319082082658F, -1.4799178377162319F, -0.5614275801533782F, -1.664976394284413F));
        g.addOrReplaceChild("domo_99", CubeListBuilder.create().texOffs(160, 232).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-17.418135655445614F, -40.298319024476406F, -2.303415063101297F, -1.4049172037592839F, -0.8661819873763392F, -1.7472103115605988F));
        g.addOrReplaceChild("domo_100", CubeListBuilder.create().texOffs(72, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.601011882997323F, -40.72789543167236F, -1.5794664981684357F, -1.2213841821657412F, -1.1688863356264874F, -1.92878885226635F));
        g.addOrReplaceChild("domo_101", CubeListBuilder.create().texOffs(234, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.851868688379113F, -40.94529297370636F, -0.5864045420514868F, -0.36075812311262356F, -1.3077500595604579F, -2.78781591340362F));
        g.addOrReplaceChild("domo_102", CubeListBuilder.create().texOffs(24, 232).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.772318335986892F, -37.67830806393077F, -3.2454156211722536F, -1.328248611606618F, -0.06958527778300327F, -1.602534845144617F));
        g.addOrReplaceChild("domo_103", CubeListBuilder.create().texOffs(80, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.895070314463076F, -38.82700641892781F, -3.066583432124765F, -1.3011693445254537F, -0.28811057560919434F, -1.7059331573517642F));
        g.addOrReplaceChild("domo_104", CubeListBuilder.create().texOffs(88, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.13762758257492F, -39.66441492150743F, -2.7132119609330845F, -1.219892556778641F, -0.5440706032116126F, -1.8483585192422076F));
        g.addOrReplaceChild("domo_105", CubeListBuilder.create().texOffs(96, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.49555703327425F, -40.298319024476406F, -2.1917596146025193F, -1.0447498394052428F, -0.809235472219285F, -2.063148330557265F));
        g.addOrReplaceChild("domo_106", CubeListBuilder.create().texOffs(242, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-16.96839379822882F, -40.72789543167236F, -1.5029036402333371F, -0.5681017178086737F, -0.8930483605148094F, -2.5920081053564976F));
        g.addOrReplaceChild("domo_107", CubeListBuilder.create().texOffs(762, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.8927349078395F, -37.67830806393077F, -2.9149772039409623F, -1.0652894035663272F, -0.06589541459899834F, -1.6224833649624983F));
        g.addOrReplaceChild("domo_108", CubeListBuilder.create().texOffs(772, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.063954586070174F, -38.82700641892781F, -2.75435316830019F, -1.0284657917767641F, -0.26997039173833365F, -1.7889761825174495F));
        g.addOrReplaceChild("domo_109", CubeListBuilder.create().texOffs(104, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.402283775661829F, -39.66441492150743F, -2.436960913105842F, -0.9237570186598574F, -0.4956105679558831F, -2.006439009803173F));
        g.addOrReplaceChild("domo_110", CubeListBuilder.create().texOffs(112, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.90153899043549F, -40.298319024476406F, -1.968601269866653F, -0.7256496239082495F, -0.7031966539201706F, -2.291727976339259F));
        g.addOrReplaceChild("domo_111", CubeListBuilder.create().texOffs(250, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-16.561071812278023F, -40.72789543167236F, -1.3498825304284638F, -0.3774399316723642F, -0.7096635341439108F, -2.7278049552642014F));
        g.addOrReplaceChild("domo_112", CubeListBuilder.create().texOffs(782, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.252172166361621F, -37.67830806393077F, -2.416761738347056F, -0.7360504728333919F, -0.054767507499565014F, -1.6422323659880296F));
        g.addOrReplaceChild("domo_113", CubeListBuilder.create().texOffs(792, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.458688783614043F, -38.82700641892781F, -2.283590877500978F, -0.6993803657812054F, -0.2216449598758067F, -1.8685208725966451F));
        g.addOrReplaceChild("domo_114", CubeListBuilder.create().texOffs(120, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.86676454029249F, -39.66441492150743F, -2.0204459522630245F, -0.6021059715794935F, -0.3946865064401618F, -2.143686677575465F));
        g.addOrReplaceChild("domo_115", CubeListBuilder.create().texOffs(128, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.468941224457161F, -40.298319024476406F, -1.632136340772397F, -0.44202329956271214F, -0.5363385921680209F, -2.454853464197945F));
        g.addOrReplaceChild("domo_116", CubeListBuilder.create().texOffs(258, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-16.264436746591976F, -40.72789543167236F, -1.119166368228206F, -0.23534767534756526F, -0.5447698791026193F, -2.792424928285279F));
        g.addOrReplaceChild("domo_117", CubeListBuilder.create().texOffs(802, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.827322772778532F, -37.67830806393077F, -1.7326412942324225F, -0.3843041050397783F, -0.03494474116657898F, -1.6560252880461146F));
        g.addOrReplaceChild("domo_118", CubeListBuilder.create().texOffs(812, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.057249872982448F, -38.82700641892781F, -1.6371675331953883F, -0.3611108877348048F, -0.14034920232426906F, -1.9219858385652713F));
        g.addOrReplaceChild("domo_119", CubeListBuilder.create().texOffs(136, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.511584621657462F, -39.66441492150743F, -1.44851188021951F, -0.30269592171403636F, -0.24555443094611493F, -2.2271661684345894F));
        g.addOrReplaceChild("domo_120", CubeListBuilder.create().texOffs(144, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.182023352653903F, -40.298319024476406F, -1.1701223074533624F, -0.2145982023842617F, -0.3264627627914417F, -2.5400136440322525F));
        g.addOrReplaceChild("domo_121", CubeListBuilder.create().texOffs(266, 253).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-16.067695319699993F, -40.72789543167236F, -0.8023603791553634F, -0.11722620386214443F, -0.3759014550024248F, -2.8255388741708334F));
        g.addOrReplaceChild("domo_122", CubeListBuilder.create().texOffs(36, 232).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-13.614752861305579F, -37.67830806393077F, -0.6701232372180382F, -0.07891475032522545F, -0.010386778018302867F, -1.6604609033111184F));
        g.addOrReplaceChild("domo_123", CubeListBuilder.create().texOffs(48, 232).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-13.85639320475216F, -38.82700641892781F, -0.6331974257252087F, -0.0739253265186383F, -0.04170284334397836F, -1.938779609036109F));
        g.addOrReplaceChild("domo_124", CubeListBuilder.create().texOffs(170, 232).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-14.333873260875087F, -39.66441492150743F, -0.5602322151461286F, -0.06154168533292192F, -0.07290447887148085F, -2.251970589728621F));
        g.addOrReplaceChild("domo_125", CubeListBuilder.create().texOffs(152, 248).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.03846634744119F, -40.298319024476406F, -0.4525611569006634F, -0.043277973162981195F, -0.0968241065174533F, -2.5635826151727352F));
        g.addOrReplaceChild("domo_126", CubeListBuilder.create().texOffs(822, 245).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.969257359497725F, -40.72789543167236F, -0.31032409101924496F, -0.023470756211082702F, -0.11029877611432787F, -2.840746031942613F));
        g.addOrReplaceChild("domo_127", CubeListBuilder.create().texOffs(104, 253).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.24605130307666F, -40.94529297370636F, -0.1152132423781731F, -0.005743150072797755F, -0.15124842737290117F, -3.0691589231335668F));
        g.addOrReplaceChild("valvulas_0", CubeListBuilder.create().texOffs(592, 208).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(520, 167).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(26.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("valvulas_1", CubeListBuilder.create().texOffs(626, 208).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(554, 167).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(26.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("deflectori", CubeListBuilder.create().texOffs(900, 56).addBox(0.0F, -34.0F, -0.5F, 44.0F, 34.0F, 1.0F), PartPose.offset(-68.0F, -21.0F, -12.5F));
        g.addOrReplaceChild("deflectord", CubeListBuilder.create().texOffs(0, 99).addBox(0.0F, -34.0F, -0.5F, 44.0F, 34.0F, 1.0F), PartPose.offset(-68.0F, -21.0F, 12.5F));
        g.addOrReplaceChild("farol3_0", CubeListBuilder.create().texOffs(480, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(548, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-70.2F, -22.0F, -7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_1", CubeListBuilder.create().texOffs(504, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(572, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-70.2F, -22.0F, -7.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_2", CubeListBuilder.create().texOffs(528, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(596, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-70.2F, -22.0F, -7.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_3", CubeListBuilder.create().texOffs(552, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(620, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-70.2F, -22.0F, -7.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_vidrio", CubeListBuilder.create().texOffs(376, 208).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-70.82000000000001F, -22.0F, -7.0F, 0.0F, 0.0F, 1.5707963267948966F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("farol10_0", CubeListBuilder.create().texOffs(576, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(644, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-70.2F, -22.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_1", CubeListBuilder.create().texOffs(600, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(668, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-70.2F, -22.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_2", CubeListBuilder.create().texOffs(624, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(692, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-70.2F, -22.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_3", CubeListBuilder.create().texOffs(648, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(716, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-70.2F, -22.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_vidrio", CubeListBuilder.create().texOffs(408, 208).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-70.82000000000001F, -22.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_0", CubeListBuilder.create().texOffs(672, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(740, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-70.2F, -22.0F, 7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_1", CubeListBuilder.create().texOffs(696, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(764, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-70.2F, -22.0F, 7.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_2", CubeListBuilder.create().texOffs(720, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(788, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-70.2F, -22.0F, 7.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_3", CubeListBuilder.create().texOffs(744, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(812, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-70.2F, -22.0F, 7.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_vidrio", CubeListBuilder.create().texOffs(440, 208).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-70.82000000000001F, -22.0F, 7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_alto_0", CubeListBuilder.create().texOffs(768, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(836, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-63.3F, -39.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_alto_1", CubeListBuilder.create().texOffs(792, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(860, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-63.3F, -39.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_alto_2", CubeListBuilder.create().texOffs(816, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(884, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-63.3F, -39.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_alto_3", CubeListBuilder.create().texOffs(840, 228).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(908, 184).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-63.3F, -39.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_alto_vidrio", CubeListBuilder.create().texOffs(472, 208).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-63.919999999999995F, -39.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(790, 134).addBox(37.0F, -38.0F, 11.5F, 19.0F, 17.0F, 1.0F).texOffs(830, 134).addBox(37.0F, -38.0F, -12.5F, 19.0F, 17.0F, 1.0F).texOffs(424, 134).addBox(37.0F, -22.0F, -11.5F, 19.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_frente", CubeListBuilder.create().texOffs(786, 99).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 25.0F), PartPose.offset(36.0F, -32.0F, -12.5F));
        g.addOrReplaceChild("cabina_fuego", CubeListBuilder.create().texOffs(670, 134).addBox(37.0F, -33.0F, -5.0F, 2.0F, 11.0F, 10.0F).texOffs(660, 208).addBox(39.0F, -27.0F, -2.0F, 1.0F, 3.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(328, 219).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.5F, -37.280047391071406F, -11.526459469667696F, -2.6818551972416236F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(380, 219).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.5F, -38.16112455113704F, -9.542532937373895F, -2.7654438256685654F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(432, 219).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.5F, -38.873484783820615F, -7.491970978685589F, -2.8490324540955045F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(484, 219).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.5F, -39.41215368367204F, -5.389092650331454F, -2.932621082522443F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(536, 219).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.5F, -39.77336973034208F, -3.2485823338048823F, -3.016209710949384F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(588, 219).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.5F, -39.95461055524703F, -1.085387194452817F, -3.0997983393763233F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(640, 219).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.5F, -39.95461055524703F, 1.0853871944528155F, 3.0997983393763233F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(692, 219).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.5F, -39.77336973034208F, 3.2485823338048796F, 3.016209710949384F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(744, 219).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.5F, -39.41215368367204F, 5.3890926503314525F, 2.932621082522443F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(796, 219).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.5F, -38.873484783820615F, 7.491970978685588F, 2.849032454095504F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(848, 219).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.5F, -38.16112455113704F, 9.542532937373895F, 2.765443825668566F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(900, 219).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.5F, -37.280047391071406F, 11.526459469667696F, 2.6818551972416236F, 0.0F, 0.0F));
        g.addOrReplaceChild("numeroi", CubeListBuilder.create().texOffs(504, 208).addBox(0.0F, -7.0F, -0.5F, 21.0F, 7.0F, 1.0F), PartPose.offset(44.75F, -23.75F, -13.0F));
        g.addOrReplaceChild("numerod", CubeListBuilder.create().texOffs(548, 208).addBox(0.0F, -7.0F, -0.5F, 21.0F, 7.0F, 1.0F), PartPose.offset(44.75F, -23.75F, 13.0F));
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(932, 184).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(958, 208).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(638, 196).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(268, 219).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(72.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(982, 208).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(648, 196).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(72.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(0, 219).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(658, 196).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(72.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(932, 184).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(958, 208).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(638, 196).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(278, 219).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(90.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(982, 208).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(648, 196).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(90.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(0, 219).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(658, 196).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(90.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri2_0", CubeListBuilder.create().texOffs(932, 184).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(958, 208).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(638, 196).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 219).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(108.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri2_1", CubeListBuilder.create().texOffs(982, 208).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(648, 196).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(108.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri2_2", CubeListBuilder.create().texOffs(0, 219).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(658, 196).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(108.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(932, 184).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(958, 208).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(638, 196).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(298, 219).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(72.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(982, 208).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(648, 196).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(72.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(0, 219).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(658, 196).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(72.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(932, 184).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(958, 208).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(638, 196).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(308, 219).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(90.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(982, 208).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(648, 196).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(90.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(0, 219).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(658, 196).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(90.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd2_0", CubeListBuilder.create().texOffs(932, 184).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(958, 208).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(638, 196).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 219).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(108.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd2_1", CubeListBuilder.create().texOffs(982, 208).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(648, 196).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(108.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd2_2", CubeListBuilder.create().texOffs(0, 219).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(658, 196).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(108.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(860, 196).addBox(62.0F, -14.0F, 2.0F, 58.0F, 10.0F, 1.0F).texOffs(0, 208).addBox(62.0F, -14.0F, -3.0F, 58.0F, 10.0F, 1.0F).texOffs(164, 208).addBox(64.0F, -13.0F, 7.0F, 52.0F, 8.0F, 1.0F).texOffs(270, 208).addBox(64.0F, -13.0F, -8.0F, 52.0F, 8.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(204, 0).addBox(60.0F, -33.0F, -12.5F, 62.0F, 19.0F, 25.0F).texOffs(508, 134).addBox(60.0F, -36.0F, -9.5F, 62.0F, 3.0F, 19.0F).texOffs(694, 134).addBox(62.0F, -37.0F, -9.0F, 30.0F, 1.0F, 18.0F).texOffs(114, 134).addBox(122.0F, -14.0F, -11.0F, 2.0F, 7.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender_caja_cantoi_0", CubeListBuilder.create().texOffs(484, 248).addBox(-31.0F, -1.0F, -0.5F, 62.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -33.46352549156242F, -12.42658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_1", CubeListBuilder.create().texOffs(610, 248).addBox(-31.0F, -1.0F, -0.5F, 62.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -34.34520337000113F, -12.140110266005152F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_2", CubeListBuilder.create().texOffs(736, 248).addBox(-31.0F, -1.0F, -0.5F, 62.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -35.09520337000113F, -11.59520337000113F, -2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_3", CubeListBuilder.create().texOffs(862, 248).addBox(-31.0F, -1.0F, -0.5F, 62.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -35.64011026600515F, -10.845203370001132F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_4", CubeListBuilder.create().texOffs(0, 251).addBox(-31.0F, -1.0F, -0.5F, 62.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -35.92658477444273F, -9.963525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_0", CubeListBuilder.create().texOffs(126, 251).addBox(-31.0F, -1.0F, -0.5F, 62.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -33.46352549156242F, 12.42658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_1", CubeListBuilder.create().texOffs(252, 251).addBox(-31.0F, -1.0F, -0.5F, 62.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -34.34520337000113F, 12.140110266005152F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_2", CubeListBuilder.create().texOffs(378, 251).addBox(-31.0F, -1.0F, -0.5F, 62.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -35.09520337000113F, 11.59520337000113F, 2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_3", CubeListBuilder.create().texOffs(504, 251).addBox(-31.0F, -1.0F, -0.5F, 62.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -35.64011026600515F, 10.845203370001132F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_4", CubeListBuilder.create().texOffs(630, 251).addBox(-31.0F, -1.0F, -0.5F, 62.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -35.92658477444273F, 9.963525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 50.0F), PartPose.offset(60.0F, -33.0F, -12.5F));
        g.addOrReplaceChild("tender_caja_tapab", CubeListBuilder.create().texOffs(102, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 50.0F), PartPose.offset(121.0F, -33.0F, -12.5F));
        g.addOrReplaceChild("tope_ti_0", CubeListBuilder.create().texOffs(958, 99).addBox(124.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(438, 99).addBox(124.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("tope_ti_1", CubeListBuilder.create().texOffs(978, 99).addBox(124.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(496, 99).addBox(124.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ti_2", CubeListBuilder.create().texOffs(998, 99).addBox(124.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(554, 99).addBox(124.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_0", CubeListBuilder.create().texOffs(812, 196).addBox(127.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(462, 196).addBox(127.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("tope_tic_1", CubeListBuilder.create().texOffs(818, 196).addBox(127.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(484, 196).addBox(127.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_2", CubeListBuilder.create().texOffs(824, 196).addBox(127.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(506, 196).addBox(127.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_3", CubeListBuilder.create().texOffs(830, 196).addBox(127.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(528, 196).addBox(127.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_0", CubeListBuilder.create().texOffs(0, 134).addBox(124.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(612, 99).addBox(124.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("tope_td_1", CubeListBuilder.create().texOffs(20, 134).addBox(124.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(670, 99).addBox(124.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_2", CubeListBuilder.create().texOffs(40, 134).addBox(124.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(728, 99).addBox(124.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_0", CubeListBuilder.create().texOffs(836, 196).addBox(127.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(550, 196).addBox(127.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("tope_tdc_1", CubeListBuilder.create().texOffs(842, 196).addBox(127.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(572, 196).addBox(127.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_2", CubeListBuilder.create().texOffs(848, 196).addBox(127.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(594, 196).addBox(127.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_3", CubeListBuilder.create().texOffs(854, 196).addBox(127.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(616, 196).addBox(127.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "cil_i_0", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_i_1", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_i_2", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_i_3", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_i_a_0", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_a_1", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_a_2", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_a_3", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_b_0", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_b_1", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_b_2", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_b_3", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_0", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_d_1", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_d_2", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_d_3", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_d_a_0", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_a_1", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_a_2", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_a_3", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_b_0", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_b_1", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_b_2", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_b_3", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "tope_i_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_ic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_d_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_dc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "caja_humo_0", 1.0F, 0.46963177644022597F, 0.46963177644022597F);
        escalar(g0, "caja_humo_1", 1.0F, 0.46963177644022597F, 0.46963177644022597F);
        escalar(g0, "caja_humo_2", 1.0F, 0.46963177644022597F, 0.46963177644022597F);
        escalar(g0, "caja_humo_3", 1.0F, 0.46963177644022597F, 0.46963177644022597F);
        escalar(g0, "caja_humo_4", 1.0F, 0.46963177644022597F, 0.46963177644022597F);
        escalar(g0, "caja_humo_5", 1.0F, 0.46963177644022597F, 0.46963177644022597F);
        escalar(g0, "puerta_0", 1.0F, 0.4174504679468675F, 0.4174504679468675F);
        escalar(g0, "puerta_1", 1.0F, 0.4174504679468675F, 0.4174504679468675F);
        escalar(g0, "puerta_2", 1.0F, 0.4174504679468675F, 0.4174504679468675F);
        escalar(g0, "puerta_3", 1.0F, 0.4174504679468675F, 0.4174504679468675F);
        escalar(g0, "puerta_4", 1.0F, 0.4174504679468675F, 0.4174504679468675F);
        escalar(g0, "puerta_5", 1.0F, 0.4174504679468675F, 0.4174504679468675F);
        escalar(g0, "caldera_0", 0.9762166082448874F, 1.0F, 0.9572962706832818F);
        escalar(g0, "caldera_1", 0.9762166082448874F, 1.0F, 0.9740909420987787F);
        escalar(g0, "caldera_2", 0.9762166082448874F, 1.0F, 0.9908856135142744F);
        escalar(g0, "caldera_3", 0.9762166082448874F, 1.0F, 0.671786856619847F);
        escalar(g0, "caldera_4", 0.9762166082448874F, 1.0F, 0.9572962706832823F);
        escalar(g0, "caldera_5", 0.9762166082448874F, 1.0F, 0.9740909420987776F);
        escalar(g0, "caldera_6", 0.9762166082448874F, 1.0F, 0.9908856135142753F);
        escalar(g0, "caldera_7", 0.9762166082448874F, 1.0F, 0.6717868566198474F);
        escalar(g0, "caldera_8", 0.9762166082448874F, 1.0F, 0.9572962706832822F);
        escalar(g0, "caldera_9", 0.9762166082448873F, 1.0F, 0.9740909420987792F);
        escalar(g0, "caldera_10", 0.9762166082448873F, 1.0F, 0.990885613514273F);
        escalar(g0, "caldera_11", 0.9762166082448874F, 1.0F, 0.6717868566198479F);
        escalar(g0, "caldera_12", 0.9762166082448873F, 1.0F, 0.9572962706832829F);
        escalar(g0, "caldera_13", 0.9762166082448873F, 1.0F, 0.9740909420987762F);
        escalar(g0, "caldera_14", 0.9762166082448873F, 1.0F, 0.9908856135142745F);
        escalar(g0, "caldera_15", 0.9762166082448873F, 1.0F, 0.6717868566198454F);
        escalar(g0, "caldera_16", 0.9762166082448873F, 1.0F, 0.9572962706832827F);
        escalar(g0, "caldera_17", 0.9762166082448873F, 1.0F, 0.9740909420987778F);
        escalar(g0, "caldera_18", 0.9762166082448873F, 1.0F, 0.9908856135142758F);
        escalar(g0, "caldera_19", 0.9762166082448873F, 1.0F, 0.6717868566198474F);
        escalar(g0, "caldera_20", 0.9762166082448874F, 1.0F, 0.9572962706832824F);
        escalar(g0, "caldera_21", 0.9762166082448874F, 1.0F, 0.9740909420987801F);
        escalar(g0, "caldera_22", 0.9762166082448874F, 1.0F, 0.9908856135142748F);
        escalar(g0, "caldera_23", 0.9762166082448874F, 1.0F, 0.6717868566198484F);
        escalar(g0, "caldera_24", 0.9762166082448874F, 1.0F, 0.9572962706832822F);
        escalar(g0, "caldera_25", 0.9762166082448874F, 1.0F, 0.9740909420987783F);
        escalar(g0, "caldera_26", 0.9762166082448874F, 1.0F, 0.9908856135142743F);
        escalar(g0, "caldera_27", 0.9762166082448874F, 1.0F, 0.6717868566198469F);
        escalar(g0, "caldera_28", 0.9762166082448874F, 1.0F, 0.9572962706832822F);
        escalar(g0, "caldera_29", 0.9762166082448874F, 1.0F, 0.9740909420987783F);
        escalar(g0, "caldera_30", 0.9762166082448874F, 1.0F, 0.9908856135142743F);
        escalar(g0, "caldera_31", 0.9762166082448874F, 1.0F, 0.6717868566198469F);
        escalar(g0, "caldera_32", 0.9762166082448874F, 1.0F, 0.9572962706832823F);
        escalar(g0, "caldera_33", 0.9762166082448874F, 1.0F, 0.9740909420987783F);
        escalar(g0, "caldera_34", 0.9762166082448874F, 1.0F, 0.9908856135142746F);
        escalar(g0, "caldera_35", 0.9762166082448874F, 1.0F, 0.671786856619847F);
        escalar(g0, "caldera_36", 0.9762166082448873F, 1.0F, 0.9572962706832807F);
        escalar(g0, "caldera_37", 0.9762166082448873F, 1.0F, 0.9740909420987758F);
        escalar(g0, "caldera_38", 0.9762166082448873F, 1.0F, 0.9908856135142722F);
        escalar(g0, "caldera_39", 0.9762166082448874F, 1.0F, 0.671786856619846F);
        escalar(g0, "caldera_40", 0.9762166082448873F, 1.0F, 0.9572962706832848F);
        escalar(g0, "caldera_41", 0.9762166082448873F, 1.0F, 0.9740909420987806F);
        escalar(g0, "caldera_42", 0.9762166082448873F, 1.0F, 0.9908856135142766F);
        escalar(g0, "caldera_43", 0.9762166082448873F, 1.0F, 0.6717868566198485F);
        escalar(g0, "caldera_44", 0.9762166082448873F, 1.0F, 0.9572962706832812F);
        escalar(g0, "caldera_45", 0.9762166082448873F, 1.0F, 0.9740909420987782F);
        escalar(g0, "caldera_46", 0.9762166082448873F, 1.0F, 0.9908856135142737F);
        escalar(g0, "caldera_47", 0.9762166082448874F, 1.0F, 0.6717868566198472F);
        escalar(g0, "caldera_48", 0.9762166082448874F, 1.0F, 0.9572962706832804F);
        escalar(g0, "caldera_49", 0.9762166082448874F, 1.0F, 0.9740909420987762F);
        escalar(g0, "caldera_50", 0.9762166082448874F, 1.0F, 0.9908856135142731F);
        escalar(g0, "caldera_51", 0.9762166082448874F, 1.0F, 0.6717868566198456F);
        escalar(g0, "caldera_52", 0.9762166082448874F, 1.0F, 0.9572962706832842F);
        escalar(g0, "caldera_53", 0.9762166082448874F, 1.0F, 0.9740909420987801F);
        escalar(g0, "caldera_54", 0.9762166082448874F, 1.0F, 0.9908856135142765F);
        escalar(g0, "caldera_55", 0.9762166082448874F, 1.0F, 0.6717868566198485F);
        escalar(g0, "caldera_56", 0.9762166082448874F, 1.0F, 0.9572962706832822F);
        escalar(g0, "caldera_57", 0.9762166082448874F, 1.0F, 0.9740909420987783F);
        escalar(g0, "caldera_58", 0.9762166082448874F, 1.0F, 0.9908856135142745F);
        escalar(g0, "caldera_59", 0.9762166082448874F, 1.0F, 0.671786856619847F);
        escalar(g0, "caldera_60", 0.9762166082448874F, 1.0F, 0.9572962706832827F);
        escalar(g0, "caldera_61", 0.9762166082448874F, 1.0F, 0.974090942098778F);
        escalar(g0, "caldera_62", 0.9762166082448874F, 1.0F, 0.9908856135142747F);
        escalar(g0, "caldera_63", 0.9762166082448874F, 1.0F, 0.6717868566198474F);
        escalar(g0, "caldera_64", 0.9762166082448873F, 1.0F, 0.9572962706832803F);
        escalar(g0, "caldera_65", 0.9762166082448873F, 1.0F, 0.9740909420987763F);
        escalar(g0, "caldera_66", 0.9762166082448873F, 1.0F, 0.9908856135142724F);
        escalar(g0, "caldera_67", 0.9762166082448873F, 1.0F, 0.6717868566198458F);
        escalar(g0, "caldera_68", 0.9762166082448873F, 1.0F, 0.9572962706832839F);
        escalar(g0, "caldera_69", 0.9762166082448873F, 1.0F, 0.9740909420987797F);
        escalar(g0, "caldera_70", 0.9762166082448873F, 1.0F, 0.9908856135142757F);
        escalar(g0, "caldera_71", 0.9762166082448873F, 1.0F, 0.6717868566198485F);
        escalar(g0, "caldera_72", 0.9762166082448873F, 1.0F, 0.9572962706832789F);
        escalar(g0, "caldera_73", 0.9762166082448873F, 1.0F, 0.9740909420987758F);
        escalar(g0, "caldera_74", 0.9762166082448873F, 1.0F, 0.9908856135142724F);
        escalar(g0, "caldera_75", 0.9762166082448873F, 1.0F, 0.6717868566198438F);
        escalar(g0, "caldera_76", 0.9762166082448874F, 1.0F, 0.9572962706832809F);
        escalar(g0, "caldera_77", 0.9762166082448874F, 1.0F, 0.9740909420987769F);
        escalar(g0, "caldera_78", 0.9762166082448874F, 1.0F, 0.9908856135142733F);
        escalar(g0, "caldera_79", 0.9762166082448874F, 1.0F, 0.6717868566198475F);
        escalar(g0, "caldera_80", 0.9762166082448874F, 1.0F, 0.9572962706832875F);
        escalar(g0, "caldera_81", 0.9762166082448874F, 1.0F, 0.9740909420987838F);
        escalar(g0, "caldera_82", 0.9762166082448874F, 1.0F, 0.9908856135142797F);
        escalar(g0, "caldera_83", 0.9762166082448874F, 1.0F, 0.6717868566198506F);
        escalar(g0, "caldera_84", 0.9762166082448874F, 1.0F, 0.9572962706832822F);
        escalar(g0, "caldera_85", 0.9762166082448874F, 1.0F, 0.9740909420987783F);
        escalar(g0, "caldera_86", 0.9762166082448874F, 1.0F, 0.9908856135142743F);
        escalar(g0, "caldera_87", 0.9762166082448874F, 1.0F, 0.6717868566198469F);
        escalar(g0, "caldera_88", 0.9762166082448874F, 1.0F, 0.957296270683282F);
        escalar(g0, "caldera_89", 0.9762166082448874F, 1.0F, 0.9740909420987764F);
        escalar(g0, "caldera_90", 0.9762166082448874F, 1.0F, 0.9908856135142745F);
        escalar(g0, "caldera_91", 0.9762166082448874F, 1.0F, 0.671786856619846F);
        escalar(g0, "caldera_92", 0.9762166082448873F, 1.0F, 0.9572962706832829F);
        escalar(g0, "caldera_93", 0.9762166082448873F, 1.0F, 0.974090942098778F);
        escalar(g0, "caldera_94", 0.9762166082448873F, 1.0F, 0.9908856135142732F);
        escalar(g0, "caldera_95", 0.9762166082448873F, 1.0F, 0.6717868566198474F);
        escalar(g0, "caldera_96", 0.9762166082448873F, 1.0F, 0.9572962706832827F);
        escalar(g0, "caldera_97", 0.9762166082448873F, 1.0F, 0.9740909420987781F);
        escalar(g0, "caldera_98", 0.9762166082448873F, 1.0F, 0.9908856135142742F);
        escalar(g0, "caldera_99", 0.9762166082448873F, 1.0F, 0.671786856619847F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1) {
        escalar(g0, "caldera_100", 0.9762166082448874F, 1.0F, 0.9572962706832775F);
        escalar(g0, "caldera_101", 0.9762166082448873F, 1.0F, 0.9740909420987749F);
        escalar(g0, "caldera_102", 0.9762166082448874F, 1.0F, 0.9908856135142718F);
        escalar(g0, "caldera_103", 0.9762166082448873F, 1.0F, 0.6717868566198445F);
        escalar(g0, "caldera_104", 0.9762166082448874F, 1.0F, 0.9572962706832817F);
        escalar(g0, "caldera_105", 0.9762166082448874F, 1.0F, 0.9740909420987782F);
        escalar(g0, "caldera_106", 0.9762166082448874F, 1.0F, 0.9908856135142737F);
        escalar(g0, "caldera_107", 0.9762166082448874F, 1.0F, 0.6717868566198469F);
        escalar(g0, "caldera_108", 0.9762166082448874F, 1.0F, 0.957296270683286F);
        escalar(g0, "caldera_109", 0.9762166082448874F, 1.0F, 0.9740909420987823F);
        escalar(g0, "caldera_110", 0.9762166082448874F, 1.0F, 0.9908856135142785F);
        escalar(g0, "caldera_111", 0.9762166082448874F, 1.0F, 0.67178685661985F);
        escalar(g0, "chimenea55_0", 0.45116122898548594F, 1.0F, 0.45116122898548594F);
        escalar(g0, "chimenea55_1", 0.45116122898548594F, 1.0F, 0.45116122898548594F);
        escalar(g0, "chimenea55_2", 0.45116122898548594F, 1.0F, 0.45116122898548594F);
        escalar(g0, "chimenea55_3", 0.45116122898548594F, 1.0F, 0.45116122898548594F);
        escalar(g0, "copa55_0", 0.549239757025809F, 1.0F, 0.549239757025809F);
        escalar(g0, "copa55_1", 0.549239757025809F, 1.0F, 0.549239757025809F);
        escalar(g0, "copa55_2", 0.549239757025809F, 1.0F, 0.549239757025809F);
        escalar(g0, "copa55_3", 0.549239757025809F, 1.0F, 0.549239757025809F);
        escalar(g0, "chimenea50_0", 0.45116122898548594F, 1.0F, 0.45116122898548594F);
        escalar(g0, "chimenea50_1", 0.45116122898548594F, 1.0F, 0.45116122898548594F);
        escalar(g0, "chimenea50_2", 0.45116122898548594F, 1.0F, 0.45116122898548594F);
        escalar(g0, "chimenea50_3", 0.45116122898548594F, 1.0F, 0.45116122898548594F);
        escalar(g0, "copa50_0", 0.549239757025809F, 1.0F, 0.549239757025809F);
        escalar(g0, "copa50_1", 0.549239757025809F, 1.0F, 0.549239757025809F);
        escalar(g0, "copa50_2", 0.549239757025809F, 1.0F, 0.549239757025809F);
        escalar(g0, "copa50_3", 0.549239757025809F, 1.0F, 0.549239757025809F);
        escalar(g0, "domo_0", 0.46077024047273385F, 1.0F, 0.4548214943191063F);
        escalar(g0, "domo_1", 0.3436460754000971F, 1.0F, 0.4301268116601446F);
        escalar(g0, "domo_2", 0.48625682833037365F, 1.0F, 0.3813302477513303F);
        escalar(g0, "domo_3", 0.5054094675923216F, 1.0F, 0.46398545224678134F);
        escalar(g0, "domo_4", 0.37941189948349363F, 1.0F, 0.3213007394829664F);
        escalar(g0, "domo_5", 0.39165079753708665F, 1.0F, 0.2511516803787644F);
        escalar(g0, "domo_6", 0.4608136453534226F, 1.0F, 0.4335210580576002F);
        escalar(g0, "domo_7", 0.34416331054790766F, 1.0F, 0.4101837703998821F);
        escalar(g0, "domo_8", 0.4884723319366914F, 1.0F, 0.3640694119213791F);
        escalar(g0, "domo_9", 0.5094364242389564F, 1.0F, 0.2960207934320253F);
        escalar(g0, "domo_10", 0.3833187179098811F, 1.0F, 0.41225258898601846F);
        escalar(g0, "domo_11", 0.4607618819223695F, 1.0F, 0.4044453758789376F);
        escalar(g0, "domo_12", 0.34354618433385803F, 1.0F, 0.3827102460028414F);
        escalar(g0, "domo_13", 0.48582629087570106F, 1.0F, 0.33976174292983646F);
        escalar(g0, "domo_14", 0.504621463022698F, 1.0F, 0.276384816594275F);
        escalar(g0, "domo_15", 0.37864380359094096F, 1.0F, 0.3853235581996346F);
        escalar(g0, "domo_16", 0.4606012208066286F, 1.0F, 0.4381587466055038F);
        escalar(g0, "domo_17", 0.3416241453941968F, 1.0F, 0.4145659083213168F);
        escalar(g0, "domo_18", 0.4775216809266673F, 1.0F, 0.3679465831401175F);
        escalar(g0, "domo_19", 0.48937459469609523F, 1.0F, 0.29915281091480517F);
        escalar(g0, "domo_20", 0.36374776541227893F, 1.0F, 0.4165478779810182F);
        escalar(g0, "domo_21", 0.46035920667680347F, 1.0F, 0.3530070218498284F);
        escalar(g0, "domo_22", 0.5080652409009769F, 1.0F, 0.5008839355514942F);
        escalar(g0, "domo_23", 0.4647441148187919F, 1.0F, 0.44431792900720035F);
        escalar(g0, "domo_24", 0.4654908502098561F, 1.0F, 0.3608463438913997F);
        escalar(g0, "domo_25", 0.34010359578278376F, 1.0F, 0.5011551813291059F);
        escalar(g0, "domo_26", 0.46010998459317864F, 1.0F, 0.43629015529365134F);
        escalar(g0, "domo_27", 0.5035301691676325F, 1.0F, 0.4125247669462767F);
        escalar(g0, "domo_28", 0.4512477850345544F, 1.0F, 0.48741931165568203F);
        escalar(g0, "domo_29", 0.4396722489828956F, 1.0F, 0.3950234360868839F);
        escalar(g0, "domo_30", 0.47111209413857535F, 1.0F, 0.40944809543592564F);
        escalar(g0, "domo_31", 0.4229944164294861F, 1.0F, 0.31660417330670504F);
        escalar(g0, "domo_32", 0.46010998459317864F, 1.0F, 0.43629015530357196F);
        escalar(g0, "domo_33", 0.5035301691676325F, 1.0F, 0.4125247669556503F);
        escalar(g0, "domo_34", 0.4512477850345542F, 1.0F, 0.4874193116667413F);
        escalar(g0, "domo_35", 0.4396722489828956F, 1.0F, 0.3950234360958181F);
        escalar(g0, "domo_36", 0.47111209413857535F, 1.0F, 0.4094480954451148F);
        escalar(g0, "domo_37", 0.4229944164294861F, 1.0F, 0.3166041733135291F);
        escalar(g0, "domo_38", 0.46035920667680347F, 1.0F, 0.35300702184982896F);
        escalar(g0, "domo_39", 0.508065240900977F, 1.0F, 0.5008839355514956F);
        escalar(g0, "domo_40", 0.46474411481879174F, 1.0F, 0.4443179290072004F);
        escalar(g0, "domo_41", 0.46549085020985637F, 1.0F, 0.3608463438913984F);
        escalar(g0, "domo_42", 0.34010359578278376F, 1.0F, 0.5011551813291025F);
        escalar(g0, "domo_43", 0.4606012208066286F, 1.0F, 0.4381587466055034F);
        escalar(g0, "domo_44", 0.3416241453941969F, 1.0F, 0.4145659083213172F);
        escalar(g0, "domo_45", 0.4775216809266673F, 1.0F, 0.36794658314011836F);
        escalar(g0, "domo_46", 0.48937459469609557F, 1.0F, 0.2991528109148064F);
        escalar(g0, "domo_47", 0.36374776541227893F, 1.0F, 0.41654787798102133F);
        escalar(g0, "domo_48", 0.4607618819223695F, 1.0F, 0.4044453758789376F);
        escalar(g0, "domo_49", 0.34354618433385803F, 1.0F, 0.38271024600284115F);
        escalar(g0, "domo_50", 0.48582629087570084F, 1.0F, 0.33976174292983663F);
        escalar(g0, "domo_51", 0.5046214630226983F, 1.0F, 0.27638481659427516F);
        escalar(g0, "domo_52", 0.37864380359094096F, 1.0F, 0.3853235581996344F);
        escalar(g0, "domo_53", 0.4608136453534226F, 1.0F, 0.4335210580576004F);
        escalar(g0, "domo_54", 0.34416331054790783F, 1.0F, 0.41018377039988196F);
        escalar(g0, "domo_55", 0.48847233193669093F, 1.0F, 0.36406941192137876F);
        escalar(g0, "domo_56", 0.5094364242389567F, 1.0F, 0.29602079343202525F);
        escalar(g0, "domo_57", 0.38331871790988115F, 1.0F, 0.4122525889860185F);
        escalar(g0, "domo_58", 0.46077024047273385F, 1.0F, 0.45482149431076585F);
        escalar(g0, "domo_59", 0.3436460754000974F, 1.0F, 0.4301268116522638F);
        escalar(g0, "domo_60", 0.4862568283303731F, 1.0F, 0.3813302477443575F);
        escalar(g0, "domo_61", 0.505409467592322F, 1.0F, 0.4639854522383322F);
        escalar(g0, "domo_62", 0.37941189948349335F, 1.0F, 0.3213007394771728F);
        escalar(g0, "domo_63", 0.39165079753708665F, 1.0F, 0.2511516803744625F);
        escalar(g0, "domo_64", 0.46077024047273385F, 1.0F, 0.4548214943274466F);
        escalar(g0, "domo_65", 0.3436460754000974F, 1.0F, 0.4301268116680254F);
        escalar(g0, "domo_66", 0.4862568283303731F, 1.0F, 0.38133024775830293F);
        escalar(g0, "domo_67", 0.505409467592322F, 1.0F, 0.4639854522552301F);
        escalar(g0, "domo_68", 0.37941189948349335F, 1.0F, 0.3213007394887597F);
        escalar(g0, "domo_69", 0.39165079753708665F, 1.0F, 0.2511516803830662F);
        escalar(g0, "domo_70", 0.4608136453534226F, 1.0F, 0.4335210580576002F);
        escalar(g0, "domo_71", 0.34416331054790783F, 1.0F, 0.41018377039988174F);
        escalar(g0, "domo_72", 0.4884723319366909F, 1.0F, 0.36406941192137854F);
        escalar(g0, "domo_73", 0.5094364242389567F, 1.0F, 0.29602079343202503F);
        escalar(g0, "domo_74", 0.3833187179098811F, 1.0F, 0.41225258898601824F);
        escalar(g0, "domo_75", 0.46076188192236955F, 1.0F, 0.4044453758789379F);
        escalar(g0, "domo_76", 0.34354618433385803F, 1.0F, 0.3827102460028421F);
        escalar(g0, "domo_77", 0.48582629087570084F, 1.0F, 0.3397617429298374F);
        escalar(g0, "domo_78", 0.5046214630226983F, 1.0F, 0.2763848165942758F);
        escalar(g0, "domo_79", 0.3786438035909409F, 1.0F, 0.38532355819963526F);
        escalar(g0, "domo_80", 0.4606012208066286F, 1.0F, 0.4381587466055041F);
        escalar(g0, "domo_81", 0.3416241453941968F, 1.0F, 0.41456590832131635F);
        escalar(g0, "domo_82", 0.4775216809266673F, 1.0F, 0.36794658314011675F);
        escalar(g0, "domo_83", 0.4893745946960955F, 1.0F, 0.2991528109148047F);
        escalar(g0, "domo_84", 0.3637477654122789F, 1.0F, 0.41654787798101817F);
        escalar(g0, "domo_85", 0.46035920667680347F, 1.0F, 0.3530070218498273F);
        escalar(g0, "domo_86", 0.5080652409009769F, 1.0F, 0.5008839355514938F);
        escalar(g0, "domo_87", 0.46474411481879163F, 1.0F, 0.44431792900720035F);
        escalar(g0, "domo_88", 0.46549085020985637F, 1.0F, 0.3608463438913984F);
        escalar(g0, "domo_89", 0.34010359578278365F, 1.0F, 0.5011551813291024F);
        escalar(g0, "domo_90", 0.46010998459317864F, 1.0F, 0.43629015528790877F);
        escalar(g0, "domo_91", 0.5035301691676326F, 1.0F, 0.4125247669408504F);
        escalar(g0, "domo_92", 0.45124778503455415F, 1.0F, 0.4874193116492809F);
        escalar(g0, "domo_93", 0.4396722489828956F, 1.0F, 0.39502343608171353F);
        escalar(g0, "domo_94", 0.47111209413857535F, 1.0F, 0.409448095430608F);
        escalar(g0, "domo_95", 0.4229944164294864F, 1.0F, 0.3166041733027572F);
        escalar(g0, "domo_96", 0.46010998459317864F, 1.0F, 0.4362901553093149F);
        escalar(g0, "domo_97", 0.5035301691676325F, 1.0F, 0.4125247669610771F);
        escalar(g0, "domo_98", 0.4512477850345542F, 1.0F, 0.48741931167314306F);
        escalar(g0, "domo_99", 0.4396722489828956F, 1.0F, 0.39502343610098967F);
        escalar(g0, "domo_100", 0.47111209413857535F, 1.0F, 0.4094480954504342F);
        escalar(g0, "domo_101", 0.4229944164294861F, 1.0F, 0.3166041733174787F);
        escalar(g0, "domo_102", 0.46035920667680347F, 1.0F, 0.3530070218498283F);
        escalar(g0, "domo_103", 0.5080652409009769F, 1.0F, 0.5008839355514946F);
        escalar(g0, "domo_104", 0.46474411481879174F, 1.0F, 0.44431792900720035F);
        escalar(g0, "domo_105", 0.46549085020985637F, 1.0F, 0.36084634389139836F);
        escalar(g0, "domo_106", 0.34010359578278376F, 1.0F, 0.5011551813291024F);
        escalar(g0, "domo_107", 0.4606012208066286F, 1.0F, 0.438158746605505F);
        escalar(g0, "domo_108", 0.3416241453941968F, 1.0F, 0.414565908321318F);
        escalar(g0, "domo_109", 0.47752168092666736F, 1.0F, 0.3679465831401184F);
        escalar(g0, "domo_110", 0.4893745946960958F, 1.0F, 0.29915281091480606F);
        escalar(g0, "domo_111", 0.36374776541227866F, 1.0F, 0.41654787798102066F);
        escalar(g0, "domo_112", 0.4607618819223694F, 1.0F, 0.4044453758789375F);
        escalar(g0, "domo_113", 0.34354618433385803F, 1.0F, 0.3827102460028413F);
        escalar(g0, "domo_114", 0.48582629087570106F, 1.0F, 0.3397617429298364F);
        escalar(g0, "domo_115", 0.5046214630226983F, 1.0F, 0.27638481659427516F);
        escalar(g0, "domo_116", 0.37864380359094074F, 1.0F, 0.38532355819963504F);
        escalar(g0, "domo_117", 0.4608136453534226F, 1.0F, 0.43352105805759955F);
        escalar(g0, "domo_118", 0.34416331054790783F, 1.0F, 0.4101837703998812F);
        escalar(g0, "domo_119", 0.48847233193669115F, 1.0F, 0.3640694119213782F);
        escalar(g0, "domo_120", 0.5094364242389565F, 1.0F, 0.2960207934320248F);
        escalar(g0, "domo_121", 0.38331871790988115F, 1.0F, 0.4122525889860177F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1) {
        escalar(g0, "domo_122", 0.46077024047273385F, 1.0F, 0.45482149430555757F);
        escalar(g0, "domo_123", 0.34364607540009723F, 1.0F, 0.43012681164734246F);
        escalar(g0, "domo_124", 0.4862568283303734F, 1.0F, 0.38133024774000335F);
        escalar(g0, "domo_125", 0.5054094675923216F, 1.0F, 0.4639854522330563F);
        escalar(g0, "domo_126", 0.37941189948349363F, 1.0F, 0.3213007394735551F);
        escalar(g0, "domo_127", 0.39165079753708665F, 1.0F, 0.25115168037177615F);
        escalar(g0, "valvulas_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "valvulas_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "deflectori", 0.5F, 0.5F, 1.0F);
        escalar(g0, "deflectord", 0.5F, 0.5F, 1.0F);
        escalar(g0, "farol3_0", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol3_1", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol3_2", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol3_3", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol3_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "farol10_0", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol10_1", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol10_2", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol10_3", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol10_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "farol17_0", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol17_1", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol17_2", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol17_3", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol17_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "farol_alto_0", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol_alto_1", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol_alto_2", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol_alto_3", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol_alto_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "cabina_techo_0", 1.0008695652173913F, 1.0F, 0.7308905619357534F);
        escalar(g0, "cabina_techo_1", 1.0008695652173913F, 1.0F, 0.7308905619357519F);
        escalar(g0, "cabina_techo_2", 1.0008695652173913F, 1.0F, 0.7308905619357532F);
        escalar(g0, "cabina_techo_3", 1.0008695652173913F, 1.0F, 0.7308905619357526F);
        escalar(g0, "cabina_techo_4", 1.0008695652173913F, 1.0F, 0.7308905619357526F);
        escalar(g0, "cabina_techo_5", 1.0008695652173913F, 1.0F, 0.7308905619357532F);
        escalar(g0, "cabina_techo_6", 1.0008695652173913F, 1.0F, 0.7308905619357522F);
        escalar(g0, "cabina_techo_7", 1.0008695652173913F, 1.0F, 0.7308905619357531F);
        escalar(g0, "cabina_techo_8", 1.0008695652173913F, 1.0F, 0.7308905619357532F);
        escalar(g0, "cabina_techo_9", 1.0008695652173913F, 1.0F, 0.7308905619357526F);
        escalar(g0, "cabina_techo_10", 1.0008695652173913F, 1.0F, 0.7308905619357525F);
        escalar(g0, "cabina_techo_11", 1.0008695652173913F, 1.0F, 0.7308905619357534F);
        escalar(g0, "numeroi", 0.5F, 0.5F, 1.0F);
        escalar(g0, "numerod", 0.5F, 0.5F, 1.0F);
        escalar(g1, "tender_caja_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_cantoi_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g1, "tender_caja_cantoi_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g1, "tender_caja_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g1, "tender_caja_cantoi_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_cantod_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g1, "tender_caja_cantod_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g1, "tender_caja_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g1, "tender_caja_cantod_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tender_caja_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tope_ti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_ti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_ti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_tic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_td_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_td_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_td_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_tdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
    }
}
