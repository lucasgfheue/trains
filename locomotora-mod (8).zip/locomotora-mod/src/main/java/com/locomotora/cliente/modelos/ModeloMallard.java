package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "LNER A4 Mallard" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloMallard {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("mallard"), "main"),
            LocomotoraMod.id("textures/entity/mallard.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, -7.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, -7.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, -7.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, 13.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, 13.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, 13.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi2_0", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, 33.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi2_1", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, 33.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi2_2", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, 33.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 9.5F, 3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_i", DatosModelo.MOTRIZ, 9.5F, 3.0F, 0.0F, -30.0F, 13.0F, -12.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_i", DatosModelo.CRUCETA, 9.5F, 3.0F, 0.0F, -30.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, -7.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, -7.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, -7.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, 13.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, 13.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, 13.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd2_0", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, 33.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd2_1", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, 33.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd2_2", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, 33.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 9.5F, 3.0F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_d", DatosModelo.MOTRIZ, 9.5F, 3.0F, 1.5707963267948966F, -30.0F, 13.0F, -12.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_d", DatosModelo.CRUCETA, 9.5F, 3.0F, 1.5707963267948966F, -30.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -47.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -47.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -47.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -29.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -29.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -29.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -47.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -47.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -47.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -29.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -29.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -29.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 53.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 53.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 53.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 53.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 53.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 53.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 74.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 74.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 74.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 90.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 90.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 90.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 112.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 112.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 112.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri3_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 128.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri3_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 128.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri3_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 128.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 74.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 74.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 74.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 90.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 90.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 90.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 112.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 112.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 112.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd3_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 128.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd3_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 128.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd3_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 128.0F, -5.0F, 1.0471975511965976F, "tender")),
            ModeloMallard::crearCapa,
            16.0F,
            ModeloMallard::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -38.0F, 53.0F),
                new DatosModelo.Segmento("tender", 74.0F, 128.0F)));

    private ModeloMallard() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g0);
        piezas5(g0);
        piezas6(g0);
        piezas7(g1);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
        escalas1(g0, g1);
        escalas2(g0, g1);
        escalas3(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(898, 56).addBox(-9.5F, -9.5F, -6.0F, 19.0F, 19.0F, 2.0F).texOffs(216, 130).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(964, 56).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 207).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(836, 220).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-7.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(256, 130).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(978, 56).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-7.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(296, 130).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 56).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-7.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(898, 56).addBox(-9.5F, -9.5F, -6.0F, 19.0F, 19.0F, 2.0F).texOffs(216, 130).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(964, 56).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(340, 207).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(842, 220).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(13.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(256, 130).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(978, 56).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(13.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(296, 130).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 56).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(13.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi2_0", CubeListBuilder.create().texOffs(898, 56).addBox(-9.5F, -9.5F, -6.0F, 19.0F, 19.0F, 2.0F).texOffs(216, 130).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(964, 56).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(350, 207).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(848, 220).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(33.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmi2_1", CubeListBuilder.create().texOffs(256, 130).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(978, 56).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(33.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi2_2", CubeListBuilder.create().texOffs(296, 130).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 56).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(33.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(616, 225).addBox(-7.0F, -13.0F, -7.5F, 40.0F, 1.0F, 1.0F).texOffs(542, 216).addBox(-8.5F, -14.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(550, 216).addBox(11.5F, -14.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(558, 216).addBox(31.5F, -14.0F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_i", CubeListBuilder.create().texOffs(780, 225).addBox(-30.0F, -0.5F, -0.5F, 30.0F, 1.0F, 1.0F).texOffs(566, 216).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(13.0F, -12.5F, -8.5F));
        g.addOrReplaceChild("cruceta_i", CubeListBuilder.create().texOffs(360, 207).addBox(-18.3496231131986F, -11.0F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(0, 227).addBox(-26.8496231131986F, -10.0F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_i", CubeListBuilder.create().texOffs(904, 225).addBox(-23.8496231131986F, -8.0F, -9.0F, 14.0F, 1.0F, 1.0F).texOffs(934, 225).addBox(-23.8496231131986F, -12.0F, -9.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_i_0", CubeListBuilder.create().texOffs(620, 89).addBox(-35.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(268, 89).addBox(-35.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, -8.5F));
        g.addOrReplaceChild("cil_i_1", CubeListBuilder.create().texOffs(648, 89).addBox(-35.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(312, 89).addBox(-35.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_2", CubeListBuilder.create().texOffs(676, 89).addBox(-35.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(356, 89).addBox(-35.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_3", CubeListBuilder.create().texOffs(704, 89).addBox(-35.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(400, 89).addBox(-35.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_0", CubeListBuilder.create().texOffs(742, 108).addBox(-36.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(988, 89).addBox(-36.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, -8.5F));
        g.addOrReplaceChild("cil_i_a_1", CubeListBuilder.create().texOffs(748, 108).addBox(-36.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(0, 108).addBox(-36.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_2", CubeListBuilder.create().texOffs(754, 108).addBox(-36.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(22, 108).addBox(-36.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_3", CubeListBuilder.create().texOffs(760, 108).addBox(-36.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(44, 108).addBox(-36.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_0", CubeListBuilder.create().texOffs(766, 108).addBox(-24.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(66, 108).addBox(-24.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, -8.5F));
        g.addOrReplaceChild("cil_i_b_1", CubeListBuilder.create().texOffs(772, 108).addBox(-24.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(88, 108).addBox(-24.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_2", CubeListBuilder.create().texOffs(778, 108).addBox(-24.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(110, 108).addBox(-24.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_3", CubeListBuilder.create().texOffs(784, 108).addBox(-24.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(132, 108).addBox(-24.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(898, 56).addBox(-9.5F, -9.5F, 4.0F, 19.0F, 19.0F, 2.0F).texOffs(216, 130).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(964, 56).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 207).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(854, 220).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-7.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(256, 130).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(978, 56).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-7.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(296, 130).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 56).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-7.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(898, 56).addBox(-9.5F, -9.5F, 4.0F, 19.0F, 19.0F, 2.0F).texOffs(216, 130).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(964, 56).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(380, 207).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(860, 220).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(13.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(256, 130).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(978, 56).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(13.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(296, 130).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 56).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(13.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd2_0", CubeListBuilder.create().texOffs(898, 56).addBox(-9.5F, -9.5F, 4.0F, 19.0F, 19.0F, 2.0F).texOffs(216, 130).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(964, 56).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(390, 207).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(866, 220).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(33.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmd2_1", CubeListBuilder.create().texOffs(256, 130).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(978, 56).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(33.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd2_2", CubeListBuilder.create().texOffs(296, 130).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 56).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(33.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(698, 225).addBox(-7.0F, -13.0F, 6.5F, 40.0F, 1.0F, 1.0F).texOffs(574, 216).addBox(-8.5F, -14.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(582, 216).addBox(11.5F, -14.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(590, 216).addBox(31.5F, -14.0F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_d", CubeListBuilder.create().texOffs(842, 225).addBox(-30.0F, -0.5F, -0.5F, 30.0F, 1.0F, 1.0F).texOffs(598, 216).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(13.0F, -12.5F, 8.5F));
        g.addOrReplaceChild("cruceta_d", CubeListBuilder.create().texOffs(400, 207).addBox(-18.3496231131986F, -11.0F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(22, 227).addBox(-26.8496231131986F, -10.0F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_d", CubeListBuilder.create().texOffs(964, 225).addBox(-23.8496231131986F, -8.0F, 8.0F, 14.0F, 1.0F, 1.0F).texOffs(994, 225).addBox(-23.8496231131986F, -12.0F, 8.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_d_0", CubeListBuilder.create().texOffs(732, 89).addBox(-35.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(444, 89).addBox(-35.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, 8.5F));
        g.addOrReplaceChild("cil_d_1", CubeListBuilder.create().texOffs(760, 89).addBox(-35.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(488, 89).addBox(-35.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_2", CubeListBuilder.create().texOffs(788, 89).addBox(-35.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(532, 89).addBox(-35.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_3", CubeListBuilder.create().texOffs(816, 89).addBox(-35.849623113198604F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(576, 89).addBox(-35.849623113198604F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_0", CubeListBuilder.create().texOffs(790, 108).addBox(-36.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(154, 108).addBox(-36.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, 8.5F));
        g.addOrReplaceChild("cil_d_a_1", CubeListBuilder.create().texOffs(796, 108).addBox(-36.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(176, 108).addBox(-36.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_2", CubeListBuilder.create().texOffs(802, 108).addBox(-36.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(198, 108).addBox(-36.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_3", CubeListBuilder.create().texOffs(808, 108).addBox(-36.349623113198604F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(220, 108).addBox(-36.349623113198604F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_0", CubeListBuilder.create().texOffs(814, 108).addBox(-24.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(242, 108).addBox(-24.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, 8.5F));
        g.addOrReplaceChild("cil_d_b_1", CubeListBuilder.create().texOffs(820, 108).addBox(-24.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(264, 108).addBox(-24.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_2", CubeListBuilder.create().texOffs(826, 108).addBox(-24.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(286, 108).addBox(-24.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_3", CubeListBuilder.create().texOffs(832, 108).addBox(-24.3496231131986F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(308, 108).addBox(-24.3496231131986F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rbi0_0", CubeListBuilder.create().texOffs(934, 108).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(300, 212).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(956, 108).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(410, 207).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-47.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi0_1", CubeListBuilder.create().texOffs(322, 212).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(964, 108).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-47.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi0_2", CubeListBuilder.create().texOffs(344, 212).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(972, 108).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-47.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbi1_0", CubeListBuilder.create().texOffs(934, 108).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(300, 212).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(956, 108).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(420, 207).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-29.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi1_1", CubeListBuilder.create().texOffs(322, 212).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(964, 108).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-29.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi1_2", CubeListBuilder.create().texOffs(344, 212).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(972, 108).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-29.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd0_0", CubeListBuilder.create().texOffs(934, 108).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(300, 212).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(956, 108).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(430, 207).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-47.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd0_1", CubeListBuilder.create().texOffs(322, 212).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(964, 108).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-47.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd0_2", CubeListBuilder.create().texOffs(344, 212).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(972, 108).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-47.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd1_0", CubeListBuilder.create().texOffs(934, 108).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(300, 212).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(956, 108).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(440, 207).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-29.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd1_1", CubeListBuilder.create().texOffs(322, 212).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(964, 108).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-29.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd1_2", CubeListBuilder.create().texOffs(344, 212).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(972, 108).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-29.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti0_0", CubeListBuilder.create().texOffs(844, 89).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(0, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 207).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(53.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rti0_1", CubeListBuilder.create().texOffs(24, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(53.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti0_2", CubeListBuilder.create().texOffs(48, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(702, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(53.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd0_0", CubeListBuilder.create().texOffs(844, 89).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(0, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(460, 207).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(53.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rtd0_1", CubeListBuilder.create().texOffs(24, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(53.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd0_2", CubeListBuilder.create().texOffs(48, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(702, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(53.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(0, 120).addBox(-60.0F, -13.0F, 2.0F, 122.0F, 9.0F, 1.0F).texOffs(246, 120).addBox(-60.0F, -13.0F, -3.0F, 122.0F, 9.0F, 1.0F).texOffs(766, 212).addBox(-64.0F, -10.0F, -0.5F, 8.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tope_i_0", CubeListBuilder.create().texOffs(116, 56).addBox(-58.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(406, 0).addBox(-58.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.0F, -7.0F));
        g.addOrReplaceChild("tope_i_1", CubeListBuilder.create().texOffs(136, 56).addBox(-58.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(464, 0).addBox(-58.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -7.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_i_2", CubeListBuilder.create().texOffs(156, 56).addBox(-58.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(522, 0).addBox(-58.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -7.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_0", CubeListBuilder.create().texOffs(838, 108).addBox(-59.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(330, 108).addBox(-59.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.0F, -7.0F));
        g.addOrReplaceChild("tope_ic_1", CubeListBuilder.create().texOffs(844, 108).addBox(-59.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(352, 108).addBox(-59.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -7.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_2", CubeListBuilder.create().texOffs(850, 108).addBox(-59.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(374, 108).addBox(-59.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -7.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_3", CubeListBuilder.create().texOffs(856, 108).addBox(-59.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(396, 108).addBox(-59.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -7.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_0", CubeListBuilder.create().texOffs(176, 56).addBox(-58.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(580, 0).addBox(-58.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.0F, 7.0F));
        g.addOrReplaceChild("tope_d_1", CubeListBuilder.create().texOffs(196, 56).addBox(-58.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(638, 0).addBox(-58.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 7.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_2", CubeListBuilder.create().texOffs(216, 56).addBox(-58.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(696, 0).addBox(-58.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 7.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_0", CubeListBuilder.create().texOffs(862, 108).addBox(-59.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(418, 108).addBox(-59.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.0F, 7.0F));
        g.addOrReplaceChild("tope_dc_1", CubeListBuilder.create().texOffs(868, 108).addBox(-59.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(440, 108).addBox(-59.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 7.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_2", CubeListBuilder.create().texOffs(874, 108).addBox(-59.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(462, 108).addBox(-59.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 7.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_3", CubeListBuilder.create().texOffs(880, 108).addBox(-59.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(484, 108).addBox(-59.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 7.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_0", CubeListBuilder.create().texOffs(98, 151).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -11.990309920401792F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_1", CubeListBuilder.create().texOffs(402, 151).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -13.970929761205376F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_2", CubeListBuilder.create().texOffs(706, 151).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -15.95154960200896F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_3", CubeListBuilder.create().texOffs(0, 157).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -17.8820602935322F, -12.193694795084884F, -1.8857398913779189F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_4", CubeListBuilder.create().texOffs(304, 157).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -19.760946412553132F, -11.571820966753211F, -1.89510801340441F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_5", CubeListBuilder.create().texOffs(608, 157).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -21.638317108352112F, -10.9406837199201F, -1.895108013404411F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_6", CubeListBuilder.create().texOffs(0, 162).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -23.51568780415109F, -10.30954647308699F, -1.8951080134044096F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("carcasa_7", CubeListBuilder.create().texOffs(304, 162).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -25.393058499950065F, -9.678409226253876F, -1.8951080134044116F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_8", CubeListBuilder.create().texOffs(608, 162).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -27.27042919574904F, -9.047271979420763F, -1.89510801340441F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_9", CubeListBuilder.create().texOffs(0, 167).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -29.133904772382856F, -8.377596885175258F, -1.9364790203292457F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_10", CubeListBuilder.create().texOffs(304, 167).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -30.887503687084166F, -7.483138089106173F, -2.148550044306009F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_11", CubeListBuilder.create().texOffs(608, 167).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -32.40700517012902F, -6.234126736534502F, -2.369032750634915F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_12", CubeListBuilder.create().texOffs(0, 172).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -33.61678106503396F, -4.682756214781877F, -2.589514825398129F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_13", CubeListBuilder.create().texOffs(304, 172).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -34.45814042366431F, -2.904037353923046F, -2.8099962581673763F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_14", CubeListBuilder.create().texOffs(608, 172).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -34.89020834223379F, -0.9840149937426478F, -3.030477038537828F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_15", CubeListBuilder.create().texOffs(0, 177).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -34.89020834223379F, 0.984014993742661F, 3.0304770385378275F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_16", CubeListBuilder.create().texOffs(304, 177).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -34.45814042366431F, 2.904037353923055F, 2.8099962581673754F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_17", CubeListBuilder.create().texOffs(608, 177).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -33.61678106503396F, 4.682756214781881F, 2.589514825398128F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_18", CubeListBuilder.create().texOffs(0, 182).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -32.407005170129025F, 6.234126736534502F, 2.369032750634915F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_19", CubeListBuilder.create().texOffs(304, 182).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -30.88750368708417F, 7.483138089106172F, 2.148550044306009F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_20", CubeListBuilder.create().texOffs(608, 182).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -29.133904772382863F, 8.377596885175256F, 1.9364790203292461F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_21", CubeListBuilder.create().texOffs(0, 187).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -27.270429195749053F, 9.047271979420762F, 1.895108013404411F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_22", CubeListBuilder.create().texOffs(304, 187).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -25.393058499950072F, 9.678409226253873F, 1.89510801340441F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_23", CubeListBuilder.create().texOffs(608, 187).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -23.515687804151092F, 10.309546473086986F, 1.89510801340441F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_24", CubeListBuilder.create().texOffs(0, 192).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -21.638317108352112F, 10.9406837199201F, 1.8951080134044116F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_25", CubeListBuilder.create().texOffs(304, 192).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -19.760946412553135F, 11.571820966753211F, 1.8951080134044096F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_26", CubeListBuilder.create().texOffs(608, 192).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -17.8820602935322F, 12.193694795084884F, 1.8857398913779189F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_27", CubeListBuilder.create().texOffs(0, 197).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -15.95154960200896F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_28", CubeListBuilder.create().texOffs(304, 197).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -13.970929761205376F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_29", CubeListBuilder.create().texOffs(608, 197).addBox(-74.0F, -1.0F, -2.0F, 148.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -11.990309920401792F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("nariz_0", CubeListBuilder.create().texOffs(414, 138).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-37.067441585187815F, -12.722389982170665F, -12.434809450934385F, -1.63179581171503F, -0.0020291288801966463F, -1.591654649402072F));
        g.addOrReplaceChild("nariz_1", CubeListBuilder.create().texOffs(614, 138).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-37.07007230297951F, -15.911483400103325F, -12.373235047595761F, -1.6314423180506399F, -0.043609327829608927F, -1.591427409048258F));
        g.addOrReplaceChild("nariz_2", CubeListBuilder.create().texOffs(948, 145).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-37.0632667905478F, -17.769872308313076F, -12.165042934487358F, -1.6320825699494923F, -0.32654350801444776F, -1.5911141191007825F));
        g.addOrReplaceChild("nariz_3", CubeListBuilder.create().texOffs(692, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-37.03737544458615F, -18.560272288049905F, -11.900327073555344F, -1.6418013986678068F, -0.32479199149653926F, -1.563158634364678F));
        g.addOrReplaceChild("nariz_4", CubeListBuilder.create().texOffs(18, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-36.98867559620206F, -19.825976182638946F, -11.476926888371313F, -1.644443524711349F, -0.324597394986539F, -1.5591307862601629F));
        g.addOrReplaceChild("nariz_5", CubeListBuilder.create().texOffs(34, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-36.91867274243902F, -21.399882723580273F, -10.950998037599401F, -1.647802294784259F, -0.324463859318011F, -1.554986492047449F));
        g.addOrReplaceChild("nariz_6", CubeListBuilder.create().texOffs(50, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-36.832956164068335F, -23.115021168760133F, -10.378352493965046F, -1.6519642876179186F, -0.32441133133083866F, -1.5510509050500425F));
        g.addOrReplaceChild("nariz_7", CubeListBuilder.create().texOffs(242, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.736386989762266F, -24.86886265494532F, -9.793198809807105F, -1.6573913840585985F, -0.32435505784102914F, -1.5468214342543214F));
        g.addOrReplaceChild("nariz_8", CubeListBuilder.create().texOffs(256, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.63195897801844F, -26.6027860999382F, -9.215174887733488F, -1.6645882159429164F, -0.3242645652355255F, -1.542126133033307F));
        g.addOrReplaceChild("nariz_9", CubeListBuilder.create().texOffs(270, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.522620895121776F, -28.278852142058156F, -8.665463643496022F, -1.6735958257953516F, -0.3148678665245766F, -1.5376101700904656F));
        g.addOrReplaceChild("nariz_10", CubeListBuilder.create().texOffs(580, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.416529419687656F, -29.866171442582296F, -8.036417508953317F, -1.6991518465113942F, -0.44265319897824973F, -1.5049573100184905F));
        g.addOrReplaceChild("nariz_11", CubeListBuilder.create().texOffs(592, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.31509202632223F, -31.332954488427003F, -7.157374171929171F, -1.715972009534406F, -0.6330642610395335F, -1.4982289142699206F));
        g.addOrReplaceChild("nariz_12", CubeListBuilder.create().texOffs(652, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.21539638930468F, -32.63850695451688F, -5.977767923155087F, -1.7292048614077773F, -0.8299660926145105F, -1.4903800040369002F));
        g.addOrReplaceChild("nariz_13", CubeListBuilder.create().texOffs(662, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.12344472675433F, -33.72257582866538F, -4.502892113760448F, -1.7367592620582741F, -1.0360798304082885F, -1.4808457302087832F));
        g.addOrReplaceChild("nariz_14", CubeListBuilder.create().texOffs(440, 138).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-39.36102881167635F, -12.566026738927576F, -12.212323666956408F, -1.698404286386878F, -0.008609606214442683F, -1.6138144411769206F));
        g.addOrReplaceChild("nariz_15", CubeListBuilder.create().texOffs(636, 138).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-39.367826639195954F, -15.765720465490237F, -12.154612111338874F, -1.6972099940006753F, -0.04157642976033316F, -1.6130280503333965F));
        g.addOrReplaceChild("nariz_16", CubeListBuilder.create().texOffs(962, 145).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-39.3420822784732F, -17.62742797189955F, -11.9543329994635F, -1.6995680844450725F, -0.3376635847435136F, -1.6099197942746764F));
        g.addOrReplaceChild("nariz_17", CubeListBuilder.create().texOffs(708, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-39.26267087737432F, -18.42305611430576F, -11.691012986076588F, -1.7017621207819036F, -0.3383653235569576F, -1.6079603521299133F));
        g.addOrReplaceChild("nariz_18", CubeListBuilder.create().texOffs(260, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-39.11268026597467F, -19.698109683129573F, -11.27119795075507F, -1.7318178183595272F, -0.3282478129472521F, -1.524622263890255F));
        g.addOrReplaceChild("nariz_19", CubeListBuilder.create().texOffs(278, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-38.89665636935477F, -21.28466349914098F, -10.751216617413233F, -1.7398466227587093F, -0.3281586389711035F, -1.5129368316198086F));
        g.addOrReplaceChild("nariz_20", CubeListBuilder.create().texOffs(66, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-38.63217743955713F, -23.014288926482518F, -10.18620616192653F, -1.7494069340934366F, -0.3284588937469884F, -1.502276577315056F));
        g.addOrReplaceChild("nariz_21", CubeListBuilder.create().texOffs(82, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-38.33455423186389F, -24.783360716860383F, -9.609767382317273F, -1.7616843391297956F, -0.3288678483732979F, -1.49101847173188F));
        g.addOrReplaceChild("nariz_22", CubeListBuilder.create().texOffs(98, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-38.01310526189258F, -26.532642966076082F, -9.04139551012435F, -1.7778344198281957F, -0.3293359810352588F, -1.478655586415116F));
        g.addOrReplaceChild("nariz_23", CubeListBuilder.create().texOffs(284, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-37.676181945322845F, -28.223709285518495F, -8.502641601314F, -1.7979582532656104F, -0.32046410439942746F, -1.4663034408107385F));
        g.addOrReplaceChild("nariz_24", CubeListBuilder.create().texOffs(298, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-37.34640363512067F, -29.824609736028123F, -7.8889172975228F, -1.8343414430125744F, -0.4429223897272708F, -1.4464977216523094F));
        g.addOrReplaceChild("nariz_25", CubeListBuilder.create().texOffs(604, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-37.02767088810643F, -31.303426499379732F, -7.030903798725269F, -1.9166950750865892F, -0.6076997493308569F, -1.3473618988975138F));
        g.addOrReplaceChild("nariz_26", CubeListBuilder.create().texOffs(616, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.71200766679784F, -32.619866426614934F, -5.876911628084654F, -1.9622397504381353F, -0.8011665849704415F, -1.3218148297569425F));
        g.addOrReplaceChild("nariz_27", CubeListBuilder.create().texOffs(672, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.417120384508266F, -33.712973830243875F, -4.432341716099898F, -2.0012164333182674F, -1.0072515847159185F, -1.2890252734003493F));
        g.addOrReplaceChild("nariz_28", CubeListBuilder.create().texOffs(396, 130).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-41.848298762800745F, -12.298560378444881F, -11.826254312466135F, -1.7502466531093426F, -0.016630329589559255F, -1.631533685613202F));
        g.addOrReplaceChild("nariz_29", CubeListBuilder.create().texOffs(658, 138).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-41.79908352984254F, -15.526335496330999F, -11.773905922303339F, -1.7591672718461302F, -0.04247893135468865F, -1.6035214088257872F));
        g.addOrReplaceChild("nariz_30", CubeListBuilder.create().texOffs(976, 145).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-41.773750160149916F, -17.391887368709938F, -11.59436455596742F, -1.753142886879137F, -0.35550512041679727F, -1.6177858345142215F));
        g.addOrReplaceChild("nariz_31", CubeListBuilder.create().texOffs(724, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-41.671307546820785F, -18.192232823526084F, -11.327193689627181F, -1.75650439788122F, -0.35506656688223287F, -1.6153601113971467F));
        g.addOrReplaceChild("nariz_32", CubeListBuilder.create().texOffs(296, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-41.415850288812464F, -19.48282911562849F, -10.91346463173446F, -1.8043606705545006F, -0.33260105767445725F, -1.484640256431158F));
        g.addOrReplaceChild("nariz_33", CubeListBuilder.create().texOffs(314, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-41.04711385432029F, -21.09033300561112F, -10.403498358069495F, -1.8165293309620385F, -0.33264063996480425F, -1.4656483201340786F));
        g.addOrReplaceChild("nariz_34", CubeListBuilder.create().texOffs(332, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-40.59561092828648F, -22.84386018531508F, -9.851106658616306F, -1.8307072714712977F, -0.3336505461610422F, -1.4486980264718878F));
        g.addOrReplaceChild("nariz_35", CubeListBuilder.create().texOffs(114, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.08802085031168F, -24.63796497159652F, -9.288666783717485F, -1.8487882970395422F, -0.3350210697343879F, -1.4309462640243555F));
        g.addOrReplaceChild("nariz_36", CubeListBuilder.create().texOffs(130, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.54048309748645F, -26.41241685161635F, -8.735219037784079F, -1.8725070105104917F, -0.3367156734748132F, -1.4114902336735218F));
        g.addOrReplaceChild("nariz_37", CubeListBuilder.create().texOffs(312, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-38.96575832539232F, -28.128130279729312F, -8.212608105137525F, -1.9025318661873618F, -0.32939045395027733F, -1.3908888212215653F));
        g.addOrReplaceChild("nariz_38", CubeListBuilder.create().texOffs(326, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-38.398141009809166F, -29.75169770189745F, -7.622571175011839F, -1.9561282675830614F, -0.43931669804521595F, -1.361239459658117F));
        g.addOrReplaceChild("nariz_39", CubeListBuilder.create().texOffs(628, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-37.84427706922801F, -31.250935852007288F, -6.798843343994914F, -2.0864814973932195F, -0.5624600608180921F, -1.1987732304522798F));
        g.addOrReplaceChild("nariz_40", CubeListBuilder.create().texOffs(640, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-37.292753183549735F, -32.586025359315826F, -5.687406511607568F, -2.1625425342192504F, -0.7472462684652975F, -1.1567172781321813F));
        g.addOrReplaceChild("nariz_41", CubeListBuilder.create().texOffs(682, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.77251640302968F, -33.69489897452617F, -4.294344087629975F, -2.2349905294096444F, -0.9496317188232062F, -1.1016964348979368F));
        g.addOrReplaceChild("nariz_42", CubeListBuilder.create().texOffs(692, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.34060359889129F, -34.48657779681797F, -2.6857556810264027F, -2.300151576414792F, -1.172559424406787F, -1.0245328464084986F));
        g.addOrReplaceChild("nariz_43", CubeListBuilder.create().texOffs(424, 130).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-44.37797859496334F, -11.946680488885054F, -11.306789018982448F, -1.7958082691423456F, -0.023982398477538303F, -1.6477450420877007F));
        g.addOrReplaceChild("nariz_44", CubeListBuilder.create().texOffs(888, 130).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-44.26993462173128F, -15.215306186220925F, -11.242346604063858F, -1.8132400792931722F, -0.0588886876489488F, -1.5849421031544926F));
        g.addOrReplaceChild("nariz_45", CubeListBuilder.create().texOffs(132, 138).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-44.21163142215846F, -17.092974541723873F, -11.091505907900327F, -1.8137285087449142F, -0.29242304077623665F, -1.6323190526696043F));
        g.addOrReplaceChild("nariz_46", CubeListBuilder.create().texOffs(24, 138).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-44.11937114092716F, -17.895332818395175F, -10.835619829204838F, -1.8064962364763035F, -0.3741895538447955F, -1.6147436206285124F));
        g.addOrReplaceChild("nariz_47", CubeListBuilder.create().texOffs(350, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-43.758699481985715F, -19.20601927564051F, -10.430582384828053F, -1.8708213427323204F, -0.3366999676506805F, -1.4428584593420304F));
        g.addOrReplaceChild("nariz_48", CubeListBuilder.create().texOffs(368, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-43.237010154282736F, -20.840425898237925F, -9.934608881065461F, -1.8867191112366126F, -0.3369865251346565F, -1.4171125027358116F));
        g.addOrReplaceChild("nariz_49", CubeListBuilder.create().texOffs(834, 138).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-42.597848021517834F, -22.62448561730134F, -9.399526548516882F, -1.9050036197167102F, -0.33898248813146836F, -1.394383255482405F));
        g.addOrReplaceChild("nariz_50", CubeListBuilder.create().texOffs(712, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.879499895834066F, -24.450434429309368F, -8.855893785650846F, -1.9281992418710743F, -0.3416460079803686F, -1.3706975734914149F));
        g.addOrReplaceChild("nariz_51", CubeListBuilder.create().texOffs(730, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.10516729142081F, -26.256790969965483F, -8.321950238479882F, -1.958523897605079F, -0.34495418138643674F, -1.34473561837653F));
        g.addOrReplaceChild("nariz_52", CubeListBuilder.create().texOffs(340, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.29122357769329F, -28.003772459401148F, -7.8193614199365715F, -1.9977021034966762F, -0.34008180568522645F, -1.3157853807553428F));
        g.addOrReplaceChild("nariz_53", CubeListBuilder.create().texOffs(354, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.48193304502856F, -29.656404685348704F, -7.258954598703969F, -2.064081663709867F, -0.4343886372265705F, -1.2772819500866945F));
        g.addOrReplaceChild("nariz_54", CubeListBuilder.create().texOffs(652, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-38.68790644557895F, -31.182033612733356F, -6.479368698258089F, -2.226687839785958F, -0.5050307438392806F, -1.0681610679237599F));
        g.addOrReplaceChild("nariz_55", CubeListBuilder.create().texOffs(664, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-37.896226200014624F, -32.54118914027717F, -5.423161937989003F, -2.3235414688850904F, -0.6768798603717251F, -1.0156587884028099F));
        g.addOrReplaceChild("nariz_56", CubeListBuilder.create().texOffs(702, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.14685257373482F, -33.670472074719726F, -4.097287735840205F, -2.418246322203026F, -0.8715468733380699F, -0.9476552587693172F));
        g.addOrReplaceChild("nariz_57", CubeListBuilder.create().texOffs(712, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.518849923368755F, -34.476970859517564F, -2.565761612977459F, -2.5093474412169785F, -1.0981507904649315F, -0.8517639140544707F));
        g.addOrReplaceChild("nariz_58", CubeListBuilder.create().texOffs(452, 130).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-46.904441331850535F, -11.527706330683657F, -10.669317520648946F, -1.8389345315903127F, -0.02931488529757392F, -1.662419800908322F));
        g.addOrReplaceChild("nariz_59", CubeListBuilder.create().texOffs(912, 130).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-46.79928190134501F, -14.842756699358652F, -10.57597769079726F, -1.85922409026328F, -0.08444453329592795F, -1.5832940510360398F));
        g.addOrReplaceChild("nariz_60", CubeListBuilder.create().texOffs(990, 145).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-46.61536180277654F, -16.751517119997498F, -10.452663595997812F, -1.8583791013425566F, -0.18403750599676738F, -1.6663534588055808F));
        g.addOrReplaceChild("nariz_61", CubeListBuilder.create().texOffs(740, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-46.502227563794364F, -17.561000315922698F, -10.236829936372391F, -1.8620851268062324F, -0.3813407175740559F, -1.607433795757833F));
        g.addOrReplaceChild("nariz_62", CubeListBuilder.create().texOffs(386, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-46.10123497447152F, -18.885338119110425F, -9.835580066209657F, -1.9347414398701226F, -0.3399219152471034F, -1.4006151511674518F));
        g.addOrReplaceChild("nariz_63", CubeListBuilder.create().texOffs(854, 138).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-45.42816568171372F, -20.55113583967347F, -9.358056071085555F, -1.9540574210600132F, -0.34061211998663027F, -1.368697896513147F));
        g.addOrReplaceChild("nariz_64", CubeListBuilder.create().texOffs(874, 138).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-44.602697986114855F, -22.370615746314783F, -8.845437852347779F, -1.9760995185949515F, -0.3437948288430112F, -1.3406623700971572F));
        g.addOrReplaceChild("nariz_65", CubeListBuilder.create().texOffs(748, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.6747487260028F, -24.23335403521253F, -8.325889156673082F, -2.003929779288573F, -0.34790658114220796F, -1.311541462420912F));
        g.addOrReplaceChild("nariz_66", CubeListBuilder.create().texOffs(766, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.67470038609091F, -26.076448064916953F, -7.816537333139925F, -2.040152624401263F, -0.35289543675318424F, -1.2795915981224968F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("nariz_67", CubeListBuilder.create().texOffs(18, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.622184387680946F, -27.85940709027296F, -7.338111809705786F, -2.0879116752479554F, -0.3510080278865937F, -1.2424915455251018F));
        g.addOrReplaceChild("nariz_68", CubeListBuilder.create().texOffs(34, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.5698269301457F, -29.545745689444324F, -6.812684002254429F, -2.1629968436723193F, -0.42802365457513175F, -1.1963464903834098F));
        g.addOrReplaceChild("nariz_69", CubeListBuilder.create().texOffs(328, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-39.53342336186843F, -31.102111306975644F, -6.085800510376036F, -2.3425155112545535F, -0.4420431260543664F, -0.9581984276536094F));
        g.addOrReplaceChild("nariz_70", CubeListBuilder.create().texOffs(676, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-38.50091965856115F, -32.489109376386224F, -5.095836670931889F, -2.4506460636365266F, -0.5981975802650235F, -0.9007462573555027F));
        g.addOrReplaceChild("nariz_71", CubeListBuilder.create().texOffs(722, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.52307972807272F, -33.64190310771106F, -3.8505230212113473F, -2.5566408947429156F, -0.781506067078023F, -0.827489355304817F));
        g.addOrReplaceChild("nariz_72", CubeListBuilder.create().texOffs(732, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.700235892218856F, -34.46550003346036F, -2.411220061927037F, -2.6597383609060046F, -1.0084055596158978F, -0.7254270029156205F));
        g.addOrReplaceChild("nariz_73", CubeListBuilder.create().texOffs(480, 130).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-49.377978575022496F, -11.056449158129675F, -9.924352051374925F, -1.8857881365592841F, -0.03331784668569134F, -1.6701956235406077F));
        g.addOrReplaceChild("nariz_74", CubeListBuilder.create().texOffs(936, 130).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-49.28554063455627F, -14.428751588380246F, -9.804556709140003F, -1.9066879314911298F, -0.10944039486657688F, -1.5906775743934267F));
        g.addOrReplaceChild("nariz_75", CubeListBuilder.create().texOffs(148, 138).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-49.029242358276946F, -16.370600557453145F, -9.675730594606462F, -1.908491869538747F, -0.18684244881195214F, -1.6687590477984224F));
        g.addOrReplaceChild("nariz_76", CubeListBuilder.create().texOffs(42, 138).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-48.85929037533182F, -17.19433596769273F, -9.507765975687976F, -1.914181352767599F, -0.34891482790562006F, -1.6097837632970038F));
        g.addOrReplaceChild("nariz_77", CubeListBuilder.create().texOffs(404, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-48.41707264221294F, -18.534900015378582F, -9.135872998892733F, -1.9983192106192331F, -0.3418315529073199F, -1.358508524566631F));
        g.addOrReplaceChild("nariz_78", CubeListBuilder.create().texOffs(894, 138).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-47.595541235583724F, -20.235418689981387F, -8.681880844023086F, -2.020807479648424F, -0.34311615173964954F, -1.3209199374315765F));
        g.addOrReplaceChild("nariz_79", CubeListBuilder.create().texOffs(914, 138).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-46.586593778745005F, -22.09383332539832F, -8.19753312327599F, -2.046336794803158F, -0.3476055937696689F, -1.287946565343345F));
        g.addOrReplaceChild("nariz_80", CubeListBuilder.create().texOffs(784, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-45.45163494059771F, -23.996851994444924F, -7.708048432543924F, -2.078392965457729F, -0.35314591730655037F, -1.2537953385335854F));
        g.addOrReplaceChild("nariz_81", CubeListBuilder.create().texOffs(802, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-44.22828344363645F, -25.88004841571165F, -7.2291757069122875F, -2.1198528083463133F, -0.35958577550238563F, -1.2163173733470503F));
        g.addOrReplaceChild("nariz_82", CubeListBuilder.create().texOffs(50, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-42.93956723459955F, -27.702190139922642F, -6.779815165892137F, -2.175369937867094F, -0.36065427264901645F, -1.171572896731719F));
        g.addOrReplaceChild("nariz_83", CubeListBuilder.create().texOffs(66, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.6447096040946F, -29.42545909100529F, -6.294765527254641F, -2.2556709025559245F, -0.4200422456616498F, -1.1191822896014967F));
        g.addOrReplaceChild("nariz_84", CubeListBuilder.create().texOffs(342, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.36570917494947F, -31.015598319731716F, -5.628531283362789F, -2.4395409222911946F, -0.3783577396005742F, -0.8675883194154933F));
        g.addOrReplaceChild("nariz_85", CubeListBuilder.create().texOffs(356, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-39.09414112604127F, -32.43290576058091F, -4.715029622404977F, -2.5514989387139564F, -0.5174046571772062F, -0.8089260751139257F));
        g.addOrReplaceChild("nariz_86", CubeListBuilder.create().texOffs(484, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.891199486764556F, -33.611096415164724F, -3.5625507540600294F, -2.6607844652959796F, -0.6862614677892935F, -0.7351075167029854F));
        g.addOrReplaceChild("nariz_87", CubeListBuilder.create().texOffs(742, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.87756617868311F, -34.453076637432204F, -2.229175448445581F, -2.7668510146769196F, -0.9086290076786149F, -0.6335395460855506F));
        g.addOrReplaceChild("nariz_88", CubeListBuilder.create().texOffs(508, 130).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-51.78910034264921F, -10.540391547583127F, -9.067370151801281F, -1.9352334401389666F, -0.039148581882212055F, -1.6730215188261996F));
        g.addOrReplaceChild("nariz_89", CubeListBuilder.create().texOffs(732, 130).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-51.717151083232835F, -13.980566080196716F, -8.9265450939553F, -1.953135046577562F, -0.1264077163493578F, -1.6030807306632666F));
        g.addOrReplaceChild("nariz_90", CubeListBuilder.create().texOffs(164, 138).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-51.46802330725734F, -15.955401429789665F, -8.767892189401522F, -1.9532959859972157F, -0.23027809337709196F, -1.6534949382104507F));
        g.addOrReplaceChild("nariz_91", CubeListBuilder.create().texOffs(60, 138).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-51.23401602184102F, -16.79698054613622F, -8.646362317779465F, -1.9553252512353418F, -0.3095874780103539F, -1.6192003162387785F));
        g.addOrReplaceChild("nariz_92", CubeListBuilder.create().texOffs(422, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-50.682885188477925F, -18.166666797963742F, -8.33555728178023F, -2.0634686965654394F, -0.34207319088117016F, -1.3166179251857835F));
        g.addOrReplaceChild("nariz_93", CubeListBuilder.create().texOffs(934, 138).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-49.7171488077424F, -19.904221778166793F, -7.910848628542486F, -2.088935645095068F, -0.34414551335973753F, -1.2736877149472898F));
        g.addOrReplaceChild("nariz_94", CubeListBuilder.create().texOffs(954, 138).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-48.52901532420452F, -21.803901176643542F, -7.461297662015754F, -2.1177057737555884F, -0.3499633085085452F, -1.2360121695449366F));
        g.addOrReplaceChild("nariz_95", CubeListBuilder.create().texOffs(820, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-47.19111725868734F, -23.74945058724375F, -7.008644699108565F, -2.153558434850351F, -0.35673518905607154F, -1.1971476891880903F));
        g.addOrReplaceChild("nariz_96", CubeListBuilder.create().texOffs(838, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-45.748339741028204F, -25.674871726733652F, -6.567031290872443F, -2.199506110338927F, -0.36413713110889984F, -1.154589238597163F));
        g.addOrReplaceChild("nariz_97", CubeListBuilder.create().texOffs(82, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-44.227694097198835F, -27.53811626581627F, -6.152654149657892F, -2.2614421266994245F, -0.3675183841570832F, -1.1030586384834407F));
        g.addOrReplaceChild("nariz_98", CubeListBuilder.create().texOffs(98, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-42.69304092602604F, -29.30030364467583F, -5.7138093704464925F, -2.3441154227964156F, -0.4100156626322259F, -1.045853846919618F));
        g.addOrReplaceChild("nariz_99", CubeListBuilder.create().texOffs(370, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.17333696851692F, -30.92611419741258F, -5.115895851792734F, -2.5228582055455275F, -0.31691652596821857F, -0.7936198980605893F));
        g.addOrReplaceChild("nariz_100", CubeListBuilder.create().texOffs(384, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-39.66684969249597F, -32.37508714071053F, -4.288625624389454F, -2.6332662256032844F, -0.43849470651937605F, -0.7359357064458348F));
        g.addOrReplaceChild("nariz_101", CubeListBuilder.create().texOffs(496, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.24463146874005F, -33.57955950302951F, -3.2405369955429513F, -2.740475872051522F, -0.5905750615929265F, -0.6639650245635406F));
        g.addOrReplaceChild("nariz_102", CubeListBuilder.create().texOffs(752, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.04661476501547F, -34.44041344457968F, -2.0257869654076495F, -2.8441759975734966F, -0.8027594716896823F, -0.56582957884294F));
        g.addOrReplaceChild("nariz_103", CubeListBuilder.create().texOffs(536, 130).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-54.13407632951015F, -9.989975095558687F, -8.095404371532377F, -1.9881967033251606F, -0.04701583398002981F, -1.676376591763363F));
        g.addOrReplaceChild("nariz_104", CubeListBuilder.create().texOffs(758, 130).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-54.08823231633731F, -13.507569522383443F, -7.941103914063016F, -2.0014115113557205F, -0.1336926741668641F, -1.6126880416625882F));
        g.addOrReplaceChild("nariz_105", CubeListBuilder.create().texOffs(180, 138).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-53.8414882918225F, -15.52649191028905F, -7.7662355606217F, -2.0033940091306137F, -0.2723355438106952F, -1.6306622729470097F));
        g.addOrReplaceChild("nariz_106", CubeListBuilder.create().texOffs(756, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-53.49718893703074F, -16.396560668592635F, -7.696771647163752F, -2.064745757835481F, -0.19892569243745492F, -1.3981379716369613F));
        g.addOrReplaceChild("nariz_107", CubeListBuilder.create().texOffs(440, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-52.833238493870525F, -17.798810170818022F, -7.445993769617662F, -2.130812205996472F, -0.3434037302406242F, -1.2924580985899994F));
        g.addOrReplaceChild("nariz_108", CubeListBuilder.create().texOffs(974, 138).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-51.76945188875981F, -19.567395810007856F, -7.047837185280903F, -2.1605785931066195F, -0.3432614847662641F, -1.2264113782735848F));
        g.addOrReplaceChild("nariz_109", CubeListBuilder.create().texOffs(680, 138).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-50.40816532419158F, -21.50955353195033F, -6.6403411106021055F, -2.1923023556494834F, -0.3503004955105969F, -1.1841549993144749F));
        g.addOrReplaceChild("nariz_110", CubeListBuilder.create().texOffs(232, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-48.87325368324251F, -23.498725937582826F, -6.232093186929878F, -2.2314057291343707F, -0.35792024476279466F, -1.1408585550776076F));
        g.addOrReplaceChild("nariz_111", CubeListBuilder.create().texOffs(252, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-47.21688640006604F, -25.467339201148754F, -5.835418393573476F, -2.280881017634251F, -0.36557443793089256F, -1.0937388919334023F));
        g.addOrReplaceChild("nariz_112", CubeListBuilder.create().texOffs(784, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-45.474051219466965F, -27.372011077621284F, -5.461749483890793F, -2.346144757211587F, -0.3705748820360711F, -1.0379529914192984F));
        g.addOrReplaceChild("nariz_113", CubeListBuilder.create().texOffs(802, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-43.70498245277475F, -29.173949801403953F, -5.075584965892139F, -2.484215479069061F, -0.1656330747992038F, -0.7800970732798965F));
        g.addOrReplaceChild("nariz_114", CubeListBuilder.create().texOffs(398, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.946072836140935F, -30.836673381055363F, -4.5548738440706815F, -2.596656782367474F, -0.2591669987472247F, -0.7334704833749021F));
        g.addOrReplaceChild("nariz_115", CubeListBuilder.create().texOffs(412, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.21158720117219F, -32.31767168032114F, -3.8232364791446476F, -2.7017082033164472F, -0.3636479479682533F, -0.6778781728673023F));
        g.addOrReplaceChild("nariz_116", CubeListBuilder.create().texOffs(508, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.57855238099586F, -33.54845195002588F, -2.8903978961698136F, -2.803284526658263F, -0.4975155211279994F, -0.608785838534996F));
        g.addOrReplaceChild("nariz_117", CubeListBuilder.create().texOffs(762, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.20485690280735F, -34.428021271946754F, -1.8058649408488383F, -2.901389200043807F, -0.6939523132933489F, -0.5150915918492622F));
        g.addOrReplaceChild("nariz_118", CubeListBuilder.create().texOffs(336, 130).addBox(-4.5F, -1.0F, -3.0F, 9.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-56.368937734099376F, -9.423944867970565F, -7.016030113541914F, -2.048698455872195F, -0.05515568181784236F, -1.6768374890102957F));
        g.addOrReplaceChild("nariz_119", CubeListBuilder.create().texOffs(784, 130).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-56.352114621828235F, -13.026383655197964F, -6.857125910925718F, -2.05576446915185F, -0.13406418740620998F, -1.6229091737812087F));
        g.addOrReplaceChild("nariz_120", CubeListBuilder.create().texOffs(196, 138).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-56.11399588739696F, -15.096036067465352F, -6.675445969831351F, -2.062842508064679F, -0.3115582340256394F, -1.599101186134491F));
        g.addOrReplaceChild("nariz_121", CubeListBuilder.create().texOffs(772, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-55.66697628442995F, -15.995478029575613F, -6.635910310651111F, -2.1442470300531893F, -0.19145458109872232F, -1.3237990051695645F));
        g.addOrReplaceChild("nariz_122", CubeListBuilder.create().texOffs(458, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-54.88867349284675F, -17.432880753453432F, -6.442901491590964F, -2.196176783846787F, -0.3258674544043052F, -1.2671861478802133F));
        g.addOrReplaceChild("nariz_123", CubeListBuilder.create().texOffs(994, 138).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-53.7232450955829F, -19.23468499590619F, -6.095587941358611F, -2.2383721330439723F, -0.3397643914911307F, -1.1780541746836501F));
        g.addOrReplaceChild("nariz_124", CubeListBuilder.create().texOffs(272, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-52.19721929709742F, -21.219348058287054F, -5.738040251134475F, -2.2726239515967217F, -0.3477376516194428F, -1.1312802478149042F));
        g.addOrReplaceChild("nariz_125", CubeListBuilder.create().texOffs(292, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-50.47387424793049F, -23.25201780713781F, -5.382487289493881F, -2.314185507275746F, -0.3556178055642071F, -1.0838910520685046F));
        g.addOrReplaceChild("nariz_126", CubeListBuilder.create().texOffs(312, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-48.61265536189782F, -25.263582008933255F, -5.039221460574884F, -2.365868507480193F, -0.3626330672831437F, -1.03291739091245F));
        g.addOrReplaceChild("nariz_127", CubeListBuilder.create().texOffs(820, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-46.65730251851895F, -27.209234469332543F, -4.715685396592122F, -2.4314284329169897F, -0.36706592904158375F, -0.9748013016298307F));
        g.addOrReplaceChild("nariz_128", CubeListBuilder.create().texOffs(838, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-44.66289307128969F, -29.050569584323274F, -4.389320311340796F, -2.5600626820850305F, -0.12679814243452978F, -0.7281142882356784F));
        g.addOrReplaceChild("nariz_129", CubeListBuilder.create().texOffs(72, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.67338660115489F, -30.7499136539867F, -3.951878100117784F, -2.6642445302832F, -0.20562721117305377F, -0.6847454026037659F));
        g.addOrReplaceChild("nariz_130", CubeListBuilder.create().texOffs(426, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.72131351982089F, -32.262339167474984F, -3.3247525484233122F, -2.761192617338601F, -0.29382685940767866F, -0.631664295953517F));
        g.addOrReplaceChild("nariz_131", CubeListBuilder.create().texOffs(520, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.88893446427283F, -33.51867988751287F, -2.517140152750391F, -2.854709612980978F, -0.40887351447067366F, -0.5657021621380252F));
        g.addOrReplaceChild("nariz_132", CubeListBuilder.create().texOffs(772, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.35059654230755F, -34.416262950811436F, -1.5731160551134513F, -2.945118770308796F, -0.5847909013344318F, -0.47650205786423305F));
        g.addOrReplaceChild("nariz_133", CubeListBuilder.create().texOffs(302, 138).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-58.44949980050341F, -8.862339051358926F, -5.834979119837031F, -2.1209555086261624F, -0.06330809224507847F, -1.6736103088595025F));
        g.addOrReplaceChild("nariz_134", CubeListBuilder.create().texOffs(518, 138).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-58.46062484474959F, -12.553671443178896F, -5.681066192400301F, -2.1214123090601067F, -0.12846955414734387F, -1.6321022563366399F));
        g.addOrReplaceChild("nariz_135", CubeListBuilder.create().texOffs(1004, 145).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-58.23541489782383F, -14.678432605274578F, -5.50245114160188F, -2.1372965464933253F, -0.34567437673791285F, -1.5563820357976237F));
        g.addOrReplaceChild("nariz_136", CubeListBuilder.create().texOffs(788, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-57.73967082324057F, -15.59920139641658F, -5.465017351476178F, -2.226457306160952F, -0.20897994073955833F, -1.278799533476348F));
        g.addOrReplaceChild("nariz_137", CubeListBuilder.create().texOffs(0, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-56.84933385442633F, -17.07303420783365F, -5.326882130385716F, -2.27395147572354F, -0.2960196320040773F, -1.2175007914454818F));
        g.addOrReplaceChild("nariz_138", CubeListBuilder.create().texOffs(702, 138).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-55.53860454808883F, -18.91693141465437F, -5.059950193807322F, -2.325770551743431F, -0.3323728569000552F, -1.1271277818872734F));
        g.addOrReplaceChild("nariz_139", CubeListBuilder.create().texOffs(332, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-53.85973605967347F, -20.942699184433256F, -4.760540765531822F, -2.36181010643306F, -0.34075207743809266F, -1.0759741200334538F));
        g.addOrReplaceChild("nariz_140", CubeListBuilder.create().texOffs(352, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-51.96064430101838F, -23.017274260091F, -4.466302037747685F, -2.40458710363186F, -0.3480957138021941F, -1.025046726148152F));
        g.addOrReplaceChild("nariz_141", CubeListBuilder.create().texOffs(372, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-49.90790900652542F, -25.070096397643436F, -4.185255040669025F, -2.456595368309358F, -0.3534726109586959F, -0.9712737721377921F));
        g.addOrReplaceChild("nariz_142", CubeListBuilder.create().texOffs(856, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.7510812396347F, -27.055357673145735F, -3.9231728161178183F, -2.5624310059141786F, -0.08543553941831007F, -0.7236019834622003F));
        g.addOrReplaceChild("nariz_143", CubeListBuilder.create().texOffs(874, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-45.54583481193474F, -28.934367262776934F, -3.6638951040433803F, -2.635561249419398F, -0.09313557130367735F, -0.6873381789875522F));
        g.addOrReplaceChild("nariz_144", CubeListBuilder.create().texOffs(88, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.343305294143356F, -30.668319920988417F, -3.3137937688995893F, -2.728278975007681F, -0.15638695638541097F, -0.6456316851723605F));
        g.addOrReplaceChild("nariz_145", CubeListBuilder.create().texOffs(104, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.18860140019055F, -32.21057858030254F, -2.7990337395202363F, -2.8150226108371386F, -0.22932666436631993F, -0.5950183277557896F));
        g.addOrReplaceChild("nariz_146", CubeListBuilder.create().texOffs(532, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.17192099251516F, -33.49099075835398F, -2.1253226648258288F, -2.8987164642370495F, -0.3255684953760361F, -0.5319880127004009F));
        g.addOrReplaceChild("nariz_147", CubeListBuilder.create().texOffs(782, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.482449551683004F, -34.40540912139618F, -1.3305360214546134F, -2.979912822916097F, -0.47737181586897204F, -0.446867479132457F));
        g.addOrReplaceChild("nariz_148", CubeListBuilder.create().texOffs(330, 138).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-60.31153924338861F, -8.332539004927497F, -4.569319418403111F, -2.211434813770136F, -0.070781567695839F, -1.6654333971711446F));
        g.addOrReplaceChild("nariz_149", CubeListBuilder.create().texOffs(542, 138).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-60.34342279110095F, -12.111946323225148F, -4.430749053202944F, -2.206222964510251F, -0.1182249703212743F, -1.6374152539891078F));
        g.addOrReplaceChild("nariz_150", CubeListBuilder.create().texOffs(0, 151).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-60.13211380361632F, -14.292755959838695F, -4.264886183969998F, -2.2349206892447744F, -0.370385769905635F, -1.4984800187714513F));
        g.addOrReplaceChild("nariz_151", CubeListBuilder.create().texOffs(804, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-59.59654543563061F, -15.234062824021471F, -4.231893698487436F, -2.326131814027651F, -0.22029141179132125F, -1.2295974740884539F));
        g.addOrReplaceChild("nariz_152", CubeListBuilder.create().texOffs(20, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-58.60314646517624F, -16.743390773544796F, -4.1449792873320455F, -2.3720637518685157F, -0.2733179216966165F, -1.1602361534117014F));
        g.addOrReplaceChild("nariz_153", CubeListBuilder.create().texOffs(392, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-57.1587544792302F, -18.62747780763876F, -3.956588799498157F, -2.4272461468300888F, -0.3186241369981387F, -1.0718112763723093F));
        g.addOrReplaceChild("nariz_154", CubeListBuilder.create().texOffs(412, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-55.34419526219855F, -20.691056166069004F, -3.7228173680593533F, -2.4637206423530977F, -0.3265955032193204F, -1.0167300739963891F));
        g.addOrReplaceChild("nariz_155", CubeListBuilder.create().texOffs(144, 202).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-53.288530273667874F, -22.80398653005399F, -3.4976610533603587F, -2.505727399231272F, -0.33246113156222806F, -0.9632641615827899F));
        g.addOrReplaceChild("nariz_156", CubeListBuilder.create().texOffs(366, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.06494956882078F, -24.894440504185532F, -3.2866331007860223F, -2.590592263815158F, -0.06568402137801015F, -0.7334622907278913F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("nariz_157", CubeListBuilder.create().texOffs(386, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-48.728303772750635F, -26.915739167215254F, -3.093644011649883F, -2.6457967273124803F, -0.059065326103367545F, -0.6929226564798429F));
        g.addOrReplaceChild("nariz_158", CubeListBuilder.create().texOffs(406, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-46.33478533156555F, -28.828984448492193F, -2.907420695634492F, -2.7118181962446544F, -0.0623428178283686F, -0.6553917106638136F));
        g.addOrReplaceChild("nariz_159", CubeListBuilder.create().texOffs(120, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.94148358673242F, -30.594419982521224F, -2.649480659453041F, -2.791043614418374F, -0.11154184107547609F, -0.6148987473299609F));
        g.addOrReplaceChild("nariz_160", CubeListBuilder.create().texOffs(136, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.605035762129035F, -32.163813587029374F, -2.252817435924311F, -2.8658218220701404F, -0.17021421595744363F, -0.5663524094101876F));
        g.addOrReplaceChild("nariz_161", CubeListBuilder.create().texOffs(544, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.423389671807165F, -33.466052881313914F, -1.7196075373031392F, -2.938259906609483F, -0.24802819564688802F, -0.5057718424602548F));
        g.addOrReplaceChild("nariz_162", CubeListBuilder.create().texOffs(792, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.59903618206153F, -34.39568164550706F, -1.080795566773985F, -3.0089876618348685F, -0.3733566263181832F, -0.4240781716244595F));
        g.addOrReplaceChild("nariz_163", CubeListBuilder.create().texOffs(912, 197).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-61.86536989453157F, -7.871476446855182F, -3.2627889213271613F, -2.3328979215961905F, -0.0029947547478982803F, -1.5740319790887383F));
        g.addOrReplaceChild("nariz_164", CubeListBuilder.create().texOffs(166, 202).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-61.90354402090273F, -11.731417891250178F, -3.1513962945228187F, -2.3215968126539073F, -0.10414805224733038F, -1.6347850139393096F));
        g.addOrReplaceChild("nariz_165", CubeListBuilder.create().texOffs(306, 207).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-61.70199279308481F, -13.964575530591313F, -3.0077745758838716F, -2.3664592328860588F, -0.37705168918324156F, -1.4203317836360871F));
        g.addOrReplaceChild("nariz_166", CubeListBuilder.create().texOffs(146, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-61.1386813006248F, -14.923920699336618F, -2.9807670823524735F, -2.451001709749496F, -0.22087808720852928F, -1.173908576530877F));
        g.addOrReplaceChild("nariz_167", CubeListBuilder.create().texOffs(856, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-60.061661238396795F, -16.46425661175832F, -2.9388090186906384F, -2.4966156618230526F, -0.2510794960398934F, -1.0942951458236518F));
        g.addOrReplaceChild("nariz_168", CubeListBuilder.create().texOffs(432, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-58.50644044952854F, -18.383071086046762F, -2.823754004885625F, -2.5478127603018925F, -0.2938378835374475F, -1.0106708055023226F));
        g.addOrReplaceChild("nariz_169", CubeListBuilder.create().texOffs(452, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-56.58078939912069F, -20.478650681665233F, -2.6600842208680273F, -2.5823592080115F, -0.30041366696245103F, -0.9527783472231837F));
        g.addOrReplaceChild("nariz_170", CubeListBuilder.create().texOffs(426, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.39725887037398F, -22.623761703550834F, -2.5079911070968364F, -2.6461388151331815F, -0.04626401512603951F, -0.7533057775808149F));
        g.addOrReplaceChild("nariz_171", CubeListBuilder.create().texOffs(446, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.03429750358372F, -24.74564349190227F, -2.370463152893678F, -2.687438999754323F, -0.04034046630118401F, -0.7105916214337386F));
        g.addOrReplaceChild("nariz_172", CubeListBuilder.create().texOffs(466, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.55073048918494F, -26.79700637736229F, -2.249558349247681F, -2.735025450346611F, -0.034689835293829914F, -0.6702633450441162F));
        g.addOrReplaceChild("nariz_173", CubeListBuilder.create().texOffs(654, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-47.002618559815744F, -28.73889265125315F, -2.1376791094919776F, -2.790807328427217F, -0.03511567235347298F, -0.6318198252789833F));
        g.addOrReplaceChild("nariz_174", CubeListBuilder.create().texOffs(672, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-44.45063112519343F, -30.530920841760377F, -1.9721295376212338F, -2.854724073595724F, -0.071610012288337F, -0.5918226042370555F));
        g.addOrReplaceChild("nariz_175", CubeListBuilder.create().texOffs(152, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.96075228541085F, -32.12350211567783F, -1.695093430710576F, -2.915897500105696F, -0.11672085910567775F, -0.5446333408853119F));
        g.addOrReplaceChild("nariz_176", CubeListBuilder.create().texOffs(344, 227).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.63859875890548F, -33.44452076456349F, -1.3055228378517676F, -2.9757332850208464F, -0.17655008591819027F, -0.4858149109318794F));
        g.addOrReplaceChild("nariz_177", CubeListBuilder.create().texOffs(802, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.698760813227416F, -34.387286950556316F, -0.8266566508344529F, -3.034773551016807F, -0.2740810334583195F, -0.4067575884893935F));
        g.addOrReplaceChild("nariz_178", CubeListBuilder.create().texOffs(938, 197).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-63.00928714979203F, -7.521324911582101F, -2.0066368701735486F, -2.4910614034547685F, -0.0014784661192566526F, -1.5720292630262287F));
        g.addOrReplaceChild("nariz_179", CubeListBuilder.create().texOffs(486, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-63.03722012455729F, -11.44561878570999F, -1.934560699608732F, -2.4835404122511293F, -0.039561143293341504F, -1.5853075570457182F));
        g.addOrReplaceChild("nariz_180", CubeListBuilder.create().texOffs(522, 216).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-62.83622428315135F, -13.72194894984996F, -1.8230654568718565F, -2.5410606353334937F, -0.34963367112564026F, -1.3204211445183922F));
        g.addOrReplaceChild("nariz_181", CubeListBuilder.create().texOffs(368, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-62.25729512415605F, -14.695078895396174F, -1.802960263480683F, -2.608041929030858F, -0.20214741629840619F, -1.1109919251049127F));
        g.addOrReplaceChild("nariz_182", CubeListBuilder.create().texOffs(114, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-61.12706926250292F, -16.25771832411959F, -1.7934880662628485F, -2.6500782903023516F, -0.21782384703479124F, -1.022537236163053F));
        g.addOrReplaceChild("nariz_183", CubeListBuilder.create().texOffs(892, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.49668958402725F, -18.201613522120454F, -1.73862024695321F, -2.705360463628576F, -0.03675592114235718F, -0.842851990225581F));
        g.addOrReplaceChild("nariz_184", CubeListBuilder.create().texOffs(506, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-57.49260263910931F, -20.320638330235717F, -1.6423721090736432F, -2.7339884864071187F, -0.02954617318041094F, -0.7864461726119861F));
        g.addOrReplaceChild("nariz_185", CubeListBuilder.create().texOffs(526, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-55.22032942514867F, -22.488918475734796F, -1.5584542164167672F, -2.763695284584158F, -0.02400559165160589F, -0.738751137397531F));
        g.addOrReplaceChild("nariz_186", CubeListBuilder.create().texOffs(546, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.76121904788903F, -24.633262854064306F, -1.48797182003144F, -2.79601234899419F, -0.019241583932947406F, -0.6960390955907129F));
        g.addOrReplaceChild("nariz_187", CubeListBuilder.create().texOffs(690, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.17584060774821F, -26.706162980794787F, -1.4317411821337798F, -2.832478626204277F, -0.014699616202770478F, -0.6557337017319002F));
        g.addOrReplaceChild("nariz_188", CubeListBuilder.create().texOffs(708, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-47.5188146066983F, -28.668826192562275F, -1.3853005555144362F, -2.8747551561338334F, -0.013402622635140828F, -0.6164395864505386F));
        g.addOrReplaceChild("nariz_189", CubeListBuilder.create().texOffs(726, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-44.850928303075946F, -30.48070170890868F, -1.3030948470155252F, -2.921705751030489F, -0.03798766965295079F, -0.5760190991646965F));
        g.addOrReplaceChild("nariz_190", CubeListBuilder.create().texOffs(168, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.24419675798436F, -32.091198290548846F, -1.139539793606943F, -2.96763939982424F, -0.06967664606022113F, -0.5292493498874943F));
        g.addOrReplaceChild("nariz_191", CubeListBuilder.create().texOffs(358, 227).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.811824976392245F, -33.42709358819579F, -0.8908521642117291F, -3.0134094842115036F, -0.1117330025464613F, -0.4713603327237773F));
        g.addOrReplaceChild("nariz_192", CubeListBuilder.create().texOffs(812, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.77958039495204F, -34.38044643768242F, -0.5716264999306832F, -3.059360492735448F, -0.18083936111073626F, -0.3940560656198952F));
        g.addOrReplaceChild("nariz_193", CubeListBuilder.create().texOffs(156, 212).addBox(-4.5F, -1.0F, -1.5F, 9.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-63.68628791944102F, -7.3098354573037F, -0.9407344062112175F, -2.699957455174097F, -0.00031323694619167123F, -1.570997435240605F));
        g.addOrReplaceChild("nariz_194", CubeListBuilder.create().texOffs(614, 216).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-63.69574961027376F, -11.274748823281257F, -0.9161719839935359F, -2.6959526309218F, -0.013545610318647296F, -1.5759140225667267F));
        g.addOrReplaceChild("nariz_195", CubeListBuilder.create().texOffs(820, 220).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-63.48876369555195F, -13.579897889147114F, -0.8418833938433978F, -2.765404569659066F, -0.14735398650109735F, -1.1634093386828317F));
        g.addOrReplaceChild("nariz_196", CubeListBuilder.create().texOffs(688, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-62.90219312718375F, -14.561610330795283F, -0.8302532308861624F, -2.7963542722034274F, -0.15238519228481343F, -1.0477292680141053F));
        g.addOrReplaceChild("nariz_197", CubeListBuilder.create().texOffs(440, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-61.75016449010207F, -16.13594977138511F, -0.8346363904598612F, -2.8313213791167597F, 0.005215634628303813F, -0.9020413592017713F));
        g.addOrReplaceChild("nariz_198", CubeListBuilder.create().texOffs(184, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-60.08377320127747F, -18.093333566933563F, -0.8175321567633387F, -2.8577933524908943F, -0.01648619055945842F, -0.8352558019252819F));
        g.addOrReplaceChild("nariz_199", CubeListBuilder.create().texOffs(744, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-58.036777179844364F, -20.2258301511126F, -0.7756044426914279F, -2.8773931601380545F, -0.012084282006423166F, -0.779193546337209F));
        g.addOrReplaceChild("nariz_200", CubeListBuilder.create().texOffs(762, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-55.71809953569193F, -22.406994270092092F, -0.7427851932053029F, -2.8968349422434687F, -0.008618113109649533F, -0.7317310153520349F));
        g.addOrReplaceChild("nariz_201", CubeListBuilder.create().texOffs(780, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-53.20973208463028F, -24.563643197310288F, -0.7194524609225911F, -2.9173139612966414F, -0.005524537296455367F, -0.6891030085817657F));
        g.addOrReplaceChild("nariz_202", CubeListBuilder.create().texOffs(798, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.57200792253954F, -26.648381737926115F, -0.7061789224088479F, -2.9400121666690913F, -0.0023808794964356316F, -0.6487040359331422F));
        g.addOrReplaceChild("nariz_203", CubeListBuilder.create().texOffs(816, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-47.857116649165825F, -28.622757274639106F, -0.7015563192058456F, -2.966261052835133F, -0.00036237466179335915F, -0.6086407530292047F));
        g.addOrReplaceChild("nariz_204", CubeListBuilder.create().texOffs(834, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-45.12260322324915F, -30.44651326570822F, -0.6793408441794383F, -2.9950501111119636F, -0.013360621831706039F, -0.567073981306109F));
        g.addOrReplaceChild("nariz_205", CubeListBuilder.create().texOffs(852, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.44232054060648F, -32.06855163529914F, -0.61037348908804F, -3.0241604805621862F, -0.031220012682767907F, -0.5198346839394452F));
        g.addOrReplaceChild("nariz_206", CubeListBuilder.create().texOffs(372, 227).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.935881059421696F, -33.414578502918324F, -0.4893363393422943F, -3.05410804473555F, -0.055350542789291905F, -0.46203267044301916F));
        g.addOrReplaceChild("nariz_207", CubeListBuilder.create().texOffs(822, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.838622484127065F, -34.375436116787895F, -0.32168425891404895F, -3.085078813184075F, -0.09571934316098703F, -0.38555223270709543F));
        g.addOrReplaceChild("nariz_208", CubeListBuilder.create().texOffs(44, 227).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-63.95317377587999F, -7.225548972861892F, -0.23763371825224122F, -2.947033444552445F, 3.296151196502272e-05F, -1.5707859241208917F));
        g.addOrReplaceChild("nariz_209", CubeListBuilder.create().texOffs(84, 227).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-63.95310633286053F, -11.206251307517507F, -0.2378473392722656F, -2.9469311059885115F, 7.949030176475523e-05F, -1.5707712260039863F));
        g.addOrReplaceChild("nariz_210", CubeListBuilder.create().texOffs(10, 229).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-63.73836212348971F, -13.524959200493292F, -0.2099922791989264F, -2.9804884097020157F, -0.06747827597117992F, -1.123887267573773F));
        g.addOrReplaceChild("nariz_211", CubeListBuilder.create().texOffs(832, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-63.148585422539234F, -14.510288579154878F, -0.20657999468295254F, -2.9956589612615843F, -0.00019953960954152103F, -0.993556851699017F));
        g.addOrReplaceChild("nariz_212", CubeListBuilder.create().texOffs(556, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-61.992724855050405F, -16.088356676448136F, -0.20965355436819433F, -3.0093205410420505F, 0.0027646091380462215F, -0.9015256361348674F));
        g.addOrReplaceChild("nariz_213", CubeListBuilder.create().texOffs(386, 227).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-60.3165323586241F, -18.050259165277396F, -0.20724971208160473F, -3.0201525759361005F, -0.0039872051244656285F, -0.8325494779972629F));
        g.addOrReplaceChild("nariz_214", CubeListBuilder.create().texOffs(120, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-58.25447005450319F, -20.187802143662097F, -0.1975277863674329F, -3.0286412295847684F, -0.002623313040939711F, -0.7769006453674008F));
        g.addOrReplaceChild("nariz_215", CubeListBuilder.create().texOffs(136, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-55.920854396837754F, -22.373552476231275F, -0.19097768022356074F, -3.0367430998460776F, -0.001501592315657298F, -0.7296985086728023F));
        g.addOrReplaceChild("nariz_216", CubeListBuilder.create().texOffs(152, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-53.39752263188904F, -24.534442318108034F, -0.1877588946461313F, -3.0450425275135835F, -0.00044912851552108456F, -0.6871959994951347F));
        g.addOrReplaceChild("nariz_217", CubeListBuilder.create().texOffs(168, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-50.74423260206001F, -26.623227136194096F, -0.1882193642790699F, -3.0541225778630876F, 0.0007175244785584424F, -0.6467798424145494F));
        g.addOrReplaceChild("nariz_218", CubeListBuilder.create().texOffs(184, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-48.011513612795866F, -28.601710554008474F, -0.19241106448604253F, -3.0646706810502065F, 0.0017716871630018938F, -0.6063373254952948F));
        g.addOrReplaceChild("nariz_219", CubeListBuilder.create().texOffs(200, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-45.25333618097172F, -30.430047170207928F, -0.19234823297355533F, -3.0762978637291236F, -0.0018635827638667174F, -0.5637821947150232F));
        g.addOrReplaceChild("nariz_220", CubeListBuilder.create().texOffs(216, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.542409469565655F, -32.057103346514864F, -0.17816962215159132F, -3.088487951183996F, -0.007270467649210121F, -0.5158398443551422F));
        g.addOrReplaceChild("nariz_221", CubeListBuilder.create().texOffs(400, 227).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.00141709535964F, -33.407965508482256F, -0.14706531591994076F, -3.101501040339199F, -0.014822964450346629F, -0.4576680639353176F));
        g.addOrReplaceChild("nariz_222", CubeListBuilder.create().texOffs(64, 227).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-63.953173775880046F, -7.225548972861873F, 0.237633718252049F, 2.947033444552537F, -3.2961512064508436e-05F, -1.5707859241208613F));
        g.addOrReplaceChild("nariz_223", CubeListBuilder.create().texOffs(102, 227).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-63.95310633286071F, -11.206251307517462F, 0.23784733927170842F, 2.946931105988784F, -7.949030143461826e-05F, -1.5707712260040905F));
        g.addOrReplaceChild("nariz_224", CubeListBuilder.create().texOffs(16, 229).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-63.7383621234897F, -13.524959200493292F, 0.20999227919894503F, 2.980488409702002F, 0.06747827597116733F, -1.1238872675737777F));
        g.addOrReplaceChild("nariz_225", CubeListBuilder.create().texOffs(842, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-63.14858542253918F, -14.510288579154892F, 0.20657999468315502F, 2.9956589612615088F, 0.000199539609323372F, -0.9935568516989646F));
        g.addOrReplaceChild("nariz_226", CubeListBuilder.create().texOffs(568, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-61.992724855050355F, -16.088356676448146F, 0.20965355436835922F, 3.0093205410419923F, -0.002764609137866844F, -0.9015256361349063F));
        g.addOrReplaceChild("nariz_227", CubeListBuilder.create().texOffs(414, 227).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-60.31653235862406F, -18.050259165277403F, 0.2072497120817242F, 3.02015257593606F, 0.003987205124349189F, -0.8325494779972388F));
        g.addOrReplaceChild("nariz_228", CubeListBuilder.create().texOffs(232, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-58.25447005450306F, -20.18780214366212F, 0.19752778636784657F, 3.0286412295846223F, 0.0026233130408563187F, -0.776900645367386F));
        g.addOrReplaceChild("nariz_229", CubeListBuilder.create().texOffs(248, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-55.92085439683771F, -22.373552476231282F, 0.1909776802237257F, 3.0367430998460154F, 0.0015015923158881726F, -0.7296985086728411F));
        g.addOrReplaceChild("nariz_230", CubeListBuilder.create().texOffs(264, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-53.39752263188905F, -24.534442318108034F, 0.18775889464608286F, 3.045042527513588F, 0.00044912851542292615F, -0.6871959994951187F));
        g.addOrReplaceChild("nariz_231", CubeListBuilder.create().texOffs(280, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-50.74423260206002F, -26.623227136194092F, 0.18821936427900776F, 3.0541225778630956F, -0.0007175244784529436F, -0.6467798424145654F));
        g.addOrReplaceChild("nariz_232", CubeListBuilder.create().texOffs(296, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-48.011513612795866F, -28.601710554008474F, 0.1924110644860651F, 3.0646706810502127F, -0.0017716871631587453F, -0.6063373254952755F));
        g.addOrReplaceChild("nariz_233", CubeListBuilder.create().texOffs(312, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-45.25333618097166F, -30.43004717020794F, 0.19234823297384268F, 3.076297863729069F, 0.001863582763865942F, -0.5637821947150239F));
        g.addOrReplaceChild("nariz_234", CubeListBuilder.create().texOffs(328, 227).addBox(-3.5F, -1.0F, -0.5F, 7.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.54240946956563F, -32.057103346514864F, 0.1781696221516993F, 3.0884879511839727F, 0.007270467649328209F, -0.5158398443551523F));
        g.addOrReplaceChild("nariz_235", CubeListBuilder.create().texOffs(428, 227).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.00141709535965F, -33.40796550848225F, 0.14706531591988714F, 3.1015010403392056F, 0.014822964450332366F, -0.4576680639353165F));
        g.addOrReplaceChild("nariz_236", CubeListBuilder.create().texOffs(180, 212).addBox(-4.5F, -1.0F, -1.5F, 9.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-63.68628791944122F, -7.309835457303628F, 0.9407344062107996F, 2.699957455174204F, 0.00031323694591736716F, -1.5709974352404672F));
        g.addOrReplaceChild("nariz_237", CubeListBuilder.create().texOffs(634, 216).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-63.695749610274376F, -11.274748823281111F, 0.9161719839922792F, 2.6959526309221515F, 0.013545610319467221F, -1.5759140225671384F));
        g.addOrReplaceChild("nariz_238", CubeListBuilder.create().texOffs(828, 220).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-63.48876369555187F, -13.579897889147132F, 0.8418833938435333F, 2.765404569659032F, 0.14735398650109294F, -1.163409338682844F));
        g.addOrReplaceChild("nariz_239", CubeListBuilder.create().texOffs(700, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-62.90219312718345F, -14.561610330795343F, 0.8302532308867172F, 2.796354272203302F, 0.15238519228459899F, -1.0477292680140426F));
        g.addOrReplaceChild("nariz_240", CubeListBuilder.create().texOffs(454, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-61.75016449010187F, -16.13594977138515F, 0.8346363904602672F, 2.8313213791166576F, -0.005215634627824588F, -0.9020413592019354F));
        g.addOrReplaceChild("nariz_241", CubeListBuilder.create().texOffs(200, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-60.08377320127738F, -18.09333356693358F, 0.8175321567635438F, 2.8577933524908508F, 0.016486190559201433F, -0.8352558019252059F));
        g.addOrReplaceChild("nariz_242", CubeListBuilder.create().texOffs(870, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-58.0367771798439F, -20.225830151112675F, 0.7756044426923709F, 2.8773931601378675F, 0.012084282006177853F, -0.7791935463371376F));
        g.addOrReplaceChild("nariz_243", CubeListBuilder.create().texOffs(888, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-55.71809953569172F, -22.406994270092127F, 0.7427851932057232F, 2.896834942243379F, 0.008618113110203234F, -0.7317310153521781F));
        g.addOrReplaceChild("nariz_244", CubeListBuilder.create().texOffs(906, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-53.20973208463033F, -24.56364319731028F, 0.7194524609224802F, 2.9173139612966708F, 0.005524537296234032F, -0.6891030085817136F));
        g.addOrReplaceChild("nariz_245", CubeListBuilder.create().texOffs(924, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.57200792253962F, -26.6483817379261F, 0.7061789224086719F, 2.9400121666691175F, 0.0023808794966937957F, -0.6487040359331974F));
        g.addOrReplaceChild("nariz_246", CubeListBuilder.create().texOffs(942, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-47.85711664916584F, -28.6227572746391F, 0.701556319205869F, 2.966261052835138F, 0.0003623746614132637F, -0.608640753029136F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("nariz_247", CubeListBuilder.create().texOffs(960, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-45.12260322324894F, -30.446513265708244F, 0.6793408441800735F, 2.995050111111878F, 0.013360621831720465F, -0.567073981306114F));
        g.addOrReplaceChild("nariz_248", CubeListBuilder.create().texOffs(978, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.4423205406064F, -32.068551635299144F, 0.6103734890882919F, 3.0241604805621525F, 0.0312200126830074F, -0.5198346839394743F));
        g.addOrReplaceChild("nariz_249", CubeListBuilder.create().texOffs(442, 227).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.93588105942172F, -33.41457850291832F, 0.4893363393422133F, 3.054108044735562F, 0.055350542789270846F, -0.4620326704430167F));
        g.addOrReplaceChild("nariz_250", CubeListBuilder.create().texOffs(852, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.83862248412708F, -34.375436116787895F, 0.32168425891393543F, 3.085078813184097F, 0.09571934316104799F, -0.3855522327070975F));
        g.addOrReplaceChild("nariz_251", CubeListBuilder.create().texOffs(964, 197).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-63.009287149792314F, -7.521324911581997F, 2.006636870173156F, 2.4910614034548297F, 0.0014784661188940874F, -1.5720292630259514F));
        g.addOrReplaceChild("nariz_252", CubeListBuilder.create().texOffs(566, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-63.03722012455853F, -11.44561878570972F, 1.9345606996071911F, 2.483540412251355F, 0.03956114329446313F, -1.5853075570466157F));
        g.addOrReplaceChild("nariz_253", CubeListBuilder.create().texOffs(532, 216).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-62.83622428315116F, -13.72194894985F, 1.823065456872096F, 2.541060635333457F, 0.34963367112565563F, -1.3204211445184078F));
        g.addOrReplaceChild("nariz_254", CubeListBuilder.create().texOffs(382, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-62.257295124155554F, -14.695078895396273F, 1.802960263481328F, 2.6080419290307875F, 0.20214741629816463F, -1.1109919251048033F));
        g.addOrReplaceChild("nariz_255", CubeListBuilder.create().texOffs(130, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-61.12706926250264F, -16.25771832411965F, 1.7934880662632278F, 2.6500782903022633F, 0.2178238470350936F, -1.0225372361632303F));
        g.addOrReplaceChild("nariz_256", CubeListBuilder.create().texOffs(910, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.49668958402711F, -18.20161352212048F, 1.7386202469533893F, 2.7053604636285598F, 0.03675592114201349F, -0.8428519902254156F));
        g.addOrReplaceChild("nariz_257", CubeListBuilder.create().texOffs(586, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-57.49260263910844F, -20.320638330235862F, 1.642372109074792F, 2.7339884864069637F, 0.029546173180076848F, -0.7864461726118451F));
        g.addOrReplaceChild("nariz_258", CubeListBuilder.create().texOffs(606, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-55.22032942514828F, -22.488918475734863F, 1.5584542164172857F, 2.7636952845840796F, 0.024005591652319584F, -0.7387511373978188F));
        g.addOrReplaceChild("nariz_259", CubeListBuilder.create().texOffs(626, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.7612190478892F, -24.63326285406428F, 1.487971820031222F, 2.796012348994227F, 0.019241583932704205F, -0.6960390955906249F));
        g.addOrReplaceChild("nariz_260", CubeListBuilder.create().texOffs(996, 216).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.175840607748356F, -26.70616298079477F, 1.4317411821335453F, 2.8324786262043107F, 0.014699616203021392F, -0.6557337017319746F));
        g.addOrReplaceChild("nariz_261", CubeListBuilder.create().texOffs(0, 220).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-47.5188146066983F, -28.66882619256227F, 1.385300555514484F, 2.87475515613383F, 0.013402622634713928F, -0.616439586450425F));
        g.addOrReplaceChild("nariz_262", CubeListBuilder.create().texOffs(18, 220).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-44.85092830307559F, -30.48070170890872F, 1.3030948470162338F, 2.9217057510304127F, 0.03798766965297395F, -0.5760190991647072F));
        g.addOrReplaceChild("nariz_263", CubeListBuilder.create().texOffs(216, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.2441967579842F, -32.09119829054886F, 1.1395397936072662F, 2.9676393998242014F, 0.06967664606046345F, -0.5292493498875388F));
        g.addOrReplaceChild("nariz_264", CubeListBuilder.create().texOffs(456, 227).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.811824976392245F, -33.42709358819578F, 0.8908521642117224F, 3.013409484211503F, 0.11173300254644557F, -0.47136033272377603F));
        g.addOrReplaceChild("nariz_265", CubeListBuilder.create().texOffs(862, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.77958039495205F, -34.38044643768242F, 0.5716264999306823F, 3.059360492735447F, 0.18083936111075216F, -0.39405606561989703F));
        g.addOrReplaceChild("nariz_266", CubeListBuilder.create().texOffs(990, 197).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-61.865369894531916F, -7.871476446855054F, 3.2627889213268233F, 2.332897921596228F, 0.0029947547475144922F, -1.574031979088335F));
        g.addOrReplaceChild("nariz_267", CubeListBuilder.create().texOffs(188, 202).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-61.90354402090466F, -11.731417891249773F, 3.1513962945210876F, 2.32159681265403F, 0.10414805224797959F, -1.6347850139400237F));
        g.addOrReplaceChild("nariz_268", CubeListBuilder.create().texOffs(318, 207).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-61.70199279308454F, -13.964575530591368F, 3.0077745758841186F, 2.3664592328860286F, 0.3770516891832424F, -1.4203317836361036F));
        g.addOrReplaceChild("nariz_269", CubeListBuilder.create().texOffs(162, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-61.13868130062414F, -14.923920699336747F, 2.980767082353079F, 2.4510017097494727F, 0.22087808720830543F, -1.1739085765307065F));
        g.addOrReplaceChild("nariz_270", CubeListBuilder.create().texOffs(874, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-60.061661238396454F, -16.464256611758387F, 2.9388090186909492F, 2.4966156618229607F, 0.2510794960401851F, -1.0942951458238932F));
        g.addOrReplaceChild("nariz_271", CubeListBuilder.create().texOffs(472, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-58.50644044952833F, -18.383071086046797F, 2.8237540048858256F, 2.5478127603019134F, 0.2938378835372485F, -1.0106708055021871F));
        g.addOrReplaceChild("nariz_272", CubeListBuilder.create().texOffs(492, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-56.580789399119396F, -20.478650681665453F, 2.6600842208692925F, 2.5823592080113844F, 0.3004136669622939F, -0.9527783472231339F));
        g.addOrReplaceChild("nariz_273", CubeListBuilder.create().texOffs(646, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.397258870373406F, -22.623761703550933F, 2.5079911070973866F, 2.6461388151330913F, 0.046264015126862415F, -0.7533057775812645F));
        g.addOrReplaceChild("nariz_274", CubeListBuilder.create().texOffs(666, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.034297503584035F, -24.745643491902225F, 2.3704631528933673F, 2.6874389997543644F, 0.04034046630093693F, -0.7105916214336152F));
        g.addOrReplaceChild("nariz_275", CubeListBuilder.create().texOffs(686, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.55073048918514F, -26.797006377362262F, 2.2495583492474367F, 2.7350254503466322F, 0.03468983529403162F, -0.6702633450441995F));
        g.addOrReplaceChild("nariz_276", CubeListBuilder.create().texOffs(36, 220).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-47.0026185598157F, -28.738892651253153F, 2.13767910949207F, 2.7908073284272183F, 0.035115672353051706F, -0.6318198252788307F));
        g.addOrReplaceChild("nariz_277", CubeListBuilder.create().texOffs(54, 220).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-44.450631125192956F, -30.530920841760437F, 1.9721295376219583F, 2.8547240735956567F, 0.07161001228835409F, -0.5918226042370702F));
        g.addOrReplaceChild("nariz_278", CubeListBuilder.create().texOffs(232, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.960752285410635F, -32.12350211567785F, 1.6950934307109367F, 2.91589750010566F, 0.11672085910592969F, -0.5446333408853735F));
        g.addOrReplaceChild("nariz_279", CubeListBuilder.create().texOffs(470, 227).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.638598758905474F, -33.4445207645635F, 1.3055228378518082F, 2.975733285020849F, 0.17655008591817223F, -0.48581491093187856F));
        g.addOrReplaceChild("nariz_280", CubeListBuilder.create().texOffs(872, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.698760813227416F, -34.38728695055632F, 0.8266566508344767F, 3.034773551016808F, 0.2740810334583635F, -0.4067575884893976F));
        g.addOrReplaceChild("nariz_281", CubeListBuilder.create().texOffs(358, 138).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-60.311539243388836F, -8.332539004927407F, 4.569319418402928F, 2.2114348137701674F, 0.07078156769565437F, -1.665433397170898F));
        g.addOrReplaceChild("nariz_282", CubeListBuilder.create().texOffs(566, 138).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-60.34342279110319F, -12.111946323224696F, 4.430749053201352F, 2.206222964510267F, 0.11822497032193573F, -1.6374152539900275F));
        g.addOrReplaceChild("nariz_283", CubeListBuilder.create().texOffs(14, 151).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-60.132113803615795F, -14.292755959838807F, 4.264886183970374F, 2.23492068924475F, 0.37038576990565786F, -1.4984800187714484F));
        g.addOrReplaceChild("nariz_284", CubeListBuilder.create().texOffs(820, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-59.596545435629636F, -15.234062824021665F, 4.2318936984881415F, 2.326131814027607F, 0.22029141179119413F, -1.2295974740883753F));
        g.addOrReplaceChild("nariz_285", CubeListBuilder.create().texOffs(40, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-58.60314646517587F, -16.74339077354487F, 4.1449792873323155F, 2.372063751868414F, 0.2733179216969102F, -1.1602361534120025F));
        g.addOrReplaceChild("nariz_286", CubeListBuilder.create().texOffs(512, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-57.15875447922997F, -18.627477807638797F, 3.95658879949833F, 2.4272461468301305F, 0.3186241369979342F, -1.0718112763721297F));
        g.addOrReplaceChild("nariz_287", CubeListBuilder.create().texOffs(532, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-55.34419526219703F, -20.69105616606926F, 3.722817368060533F, 2.463720642353028F, 0.32659550321914693F, -1.0167300739962954F));
        g.addOrReplaceChild("nariz_288", CubeListBuilder.create().texOffs(210, 202).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-53.288530273667234F, -22.803986530054097F, 3.4976610533608454F, 2.505727399231116F, 0.3324611315626435F, -0.9632641615831347F));
        g.addOrReplaceChild("nariz_289", CubeListBuilder.create().texOffs(706, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.064949568821206F, -24.894440504185464F, 3.286633100785675F, 2.590592263815202F, 0.06568402137776544F, -0.733462290727738F));
        g.addOrReplaceChild("nariz_290", CubeListBuilder.create().texOffs(726, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-48.728303772750934F, -26.915739167215214F, 3.0936440116496016F, 2.645796727312504F, 0.059065326103563576F, -0.6929226564799419F));
        g.addOrReplaceChild("nariz_291", CubeListBuilder.create().texOffs(746, 212).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-46.33478533156554F, -28.828984448492193F, 2.9074206956345368F, 2.71181819624466F, 0.062342817827942903F, -0.6553917106636211F));
        g.addOrReplaceChild("nariz_292", CubeListBuilder.create().texOffs(248, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.941483586731856F, -30.5944199825213F, 2.649480659453737F, 2.7910436144183146F, 0.11154184107545433F, -0.6148987473299636F));
        g.addOrReplaceChild("nariz_293", CubeListBuilder.create().texOffs(264, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.60503576212872F, -32.16381358702941F, 2.252817435924734F, 2.8658218220700915F, 0.17021421595769037F, -0.5663524094102644F));
        g.addOrReplaceChild("nariz_294", CubeListBuilder.create().texOffs(580, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.423389671807115F, -33.466052881313914F, 1.719607537303228F, 2.9382599066094657F, 0.2480281956469128F, -0.5057718424602627F));
        g.addOrReplaceChild("nariz_295", CubeListBuilder.create().texOffs(882, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.599036182061525F, -34.39568164550706F, 1.0807955667739975F, 3.0089876618348517F, 0.37335662631823985F, -0.42407817162446687F));
        g.addOrReplaceChild("nariz_296", CubeListBuilder.create().texOffs(386, 138).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-58.44949980050309F, -8.862339051358992F, 5.834979119837214F, 2.120955508626166F, 0.06330809224493279F, -1.6736103088592762F));
        g.addOrReplaceChild("nariz_297", CubeListBuilder.create().texOffs(590, 138).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-58.46062484475169F, -12.553671443178496F, 5.681066192399061F, 2.1214123090600463F, 0.12846955414797415F, -1.6321022563376906F));
        g.addOrReplaceChild("nariz_298", CubeListBuilder.create().texOffs(28, 151).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-58.235414897822636F, -14.678432605274814F, 5.502451141602571F, 2.13729654649328F, 0.3456743767379142F, -1.5563820357976386F));
        g.addOrReplaceChild("nariz_299", CubeListBuilder.create().texOffs(836, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-57.73967082323935F, -15.59920139641682F, 5.4650173514769165F, 2.2264573061607984F, 0.20897994073980883F, -1.2787995334767817F));
        g.addOrReplaceChild("nariz_300", CubeListBuilder.create().texOffs(60, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-56.849333854426476F, -17.07303420783363F, 5.326882130385648F, 2.273951475723476F, 0.2960196320042966F, -1.2175007914457365F));
        g.addOrReplaceChild("nariz_301", CubeListBuilder.create().texOffs(724, 138).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-55.53860454808867F, -18.916931414654396F, 5.059950193807428F, 2.325770551743521F, 0.33237285689980783F, -1.1271277818869883F));
        g.addOrReplaceChild("nariz_302", CubeListBuilder.create().texOffs(552, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-53.8597360596717F, -20.94269918443355F, 4.760540765532953F, 2.3618101064330186F, 0.3407520774379174F, -1.075974120033322F));
        g.addOrReplaceChild("nariz_303", CubeListBuilder.create().texOffs(572, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-51.960644301017766F, -23.017274260091106F, 4.466302037748058F, 2.4045871036316657F, 0.3480957138026358F, -1.0250467261486087F));
        g.addOrReplaceChild("nariz_304", CubeListBuilder.create().texOffs(592, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-49.90790900652592F, -25.070096397643358F, 4.185255040668685F, 2.4565953683094564F, 0.3534726109585199F, -0.9712737721376092F));
        g.addOrReplaceChild("nariz_305", CubeListBuilder.create().texOffs(928, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.751081239635035F, -27.055357673145693F, 3.9231728161175274F, 2.5624310059141737F, 0.0854355394186342F, -0.7236019834624118F));
        g.addOrReplaceChild("nariz_306", CubeListBuilder.create().texOffs(946, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-45.54583481193484F, -28.934367262776917F, 3.6638951040433327F, 2.635561249419444F, 0.09313557130316136F, -0.687338178987261F));
        g.addOrReplaceChild("nariz_307", CubeListBuilder.create().texOffs(280, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.34330529414268F, -30.6683199209885F, 3.3137937689002905F, 2.728278975007618F, 0.15638695638536332F, -0.6456316851723558F));
        g.addOrReplaceChild("nariz_308", CubeListBuilder.create().texOffs(296, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.18860140019014F, -32.21057858030258F, 2.799033739520712F, 2.8150226108370737F, 0.22932666436657953F, -0.5950183277558893F));
        g.addOrReplaceChild("nariz_309", CubeListBuilder.create().texOffs(592, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.171920992515055F, -33.490990758353995F, 2.125322664825994F, 2.8987164642370415F, 0.3255684953760574F, -0.5319880127004094F));
        g.addOrReplaceChild("nariz_310", CubeListBuilder.create().texOffs(892, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.48244955168295F, -34.40540912139619F, 1.3305360214547093F, 2.9799128229160936F, 0.47737181586903765F, -0.44686747913247093F));
        g.addOrReplaceChild("nariz_311", CubeListBuilder.create().texOffs(366, 130).addBox(-4.5F, -1.0F, -3.0F, 9.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-56.3689377340991F, -9.423944867970627F, 7.0160301135420795F, 2.0486984558721932F, 0.055155681817745016F, -1.6768374890101154F));
        g.addOrReplaceChild("nariz_312", CubeListBuilder.create().texOffs(810, 130).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-56.35211462182965F, -13.026383655197705F, 6.857125910924987F, 2.055764469151777F, 0.13406418740663015F, -1.6229091737819694F));
        g.addOrReplaceChild("nariz_313", CubeListBuilder.create().texOffs(212, 138).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-56.11399588739499F, -15.096036067465732F, 6.675445969832355F, 2.0628425080646133F, 0.31155823402556565F, -1.5991011861345477F));
        g.addOrReplaceChild("nariz_314", CubeListBuilder.create().texOffs(852, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-55.666976284429F, -15.9954780295758F, 6.635910310651611F, 2.144247030052953F, 0.19145458109935407F, -1.3237990051706208F));
        g.addOrReplaceChild("nariz_315", CubeListBuilder.create().texOffs(476, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-54.888673492847644F, -17.432880753453272F, 6.442901491590505F, 2.1961767838467963F, 0.3258674544043492F, -1.2671861478802613F));
        g.addOrReplaceChild("nariz_316", CubeListBuilder.create().texOffs(80, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-53.72324509558255F, -19.234684995906242F, 6.095587941358792F, 2.2383721330441095F, 0.33976439149080506F, -1.1780541746832096F));
        g.addOrReplaceChild("nariz_317", CubeListBuilder.create().texOffs(612, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-52.19721929709528F, -21.219348058287398F, 5.738040251135638F, 2.2726239515966653F, 0.3477376516193166F, -1.13128024781482F));
        g.addOrReplaceChild("nariz_318", CubeListBuilder.create().texOffs(632, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-50.473874247929906F, -23.25201780713791F, 5.382487289494184F, 2.3141855072755413F, 0.35561780556466055F, -1.083891052069038F));
        g.addOrReplaceChild("nariz_319", CubeListBuilder.create().texOffs(652, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-48.61265536189832F, -25.26358200893318F, 5.039221460574602F, 2.3658685074802954F, 0.3626330672829292F, -1.0329173909122145F));
        g.addOrReplaceChild("nariz_320", CubeListBuilder.create().texOffs(964, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-46.657302518519344F, -27.209234469332493F, 4.715685396591826F, 2.4314284329169533F, 0.3670659290418029F, -0.9748013016300064F));
        g.addOrReplaceChild("nariz_321", CubeListBuilder.create().texOffs(982, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-44.662893071289936F, -29.050569584323235F, 4.389320311340663F, 2.5600626820850914F, 0.1267981424339246F, -0.7281142882352757F));
        g.addOrReplaceChild("nariz_322", CubeListBuilder.create().texOffs(312, 220).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.67338660115424F, -30.749913653986773F, 3.951878100118369F, 2.6642445302831366F, 0.205627211173063F, -0.684745402603788F));
        g.addOrReplaceChild("nariz_323", CubeListBuilder.create().texOffs(468, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.721313519820484F, -32.262339167475034F, 3.3247525484237266F, 2.7611926173385544F, 0.2938268594078478F, -0.6316642959535949F));
        g.addOrReplaceChild("nariz_324", CubeListBuilder.create().texOffs(604, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.88893446427265F, -33.51867988751289F, 2.5171401527506165F, 2.8547096129809466F, 0.408873514470701F, -0.5657021621380417F));
        g.addOrReplaceChild("nariz_325", CubeListBuilder.create().texOffs(902, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.35059654230747F, -34.41626295081144F, 1.573116055113587F, 2.9451187703087607F, 0.5847909013345315F, -0.4765020578642604F));
        g.addOrReplaceChild("nariz_326", CubeListBuilder.create().texOffs(564, 130).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-54.13407632951028F, -9.989975095558645F, 8.095404371532318F, 1.9881967033251722F, 0.04701583397995656F, -1.676376591763199F));
        g.addOrReplaceChild("nariz_327", CubeListBuilder.create().texOffs(836, 130).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-54.08823231633816F, -13.507569522383292F, 7.941103914062644F, 2.001411511355678F, 0.13369267416706734F, -1.6126880416630338F));
        g.addOrReplaceChild("nariz_328", CubeListBuilder.create().texOffs(228, 138).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-53.8414882918201F, -15.526491910289497F, 7.76623556062278F, 2.0033940091305573F, 0.27233554381064734F, -1.6306622729470401F));
        g.addOrReplaceChild("nariz_329", CubeListBuilder.create().texOffs(868, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-53.49718893703006F, -16.39656066859277F, 7.696771647164065F, 2.0647457578351776F, 0.19892569243824276F, -1.3981379716384614F));
        g.addOrReplaceChild("nariz_330", CubeListBuilder.create().texOffs(494, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-52.83323849387175F, -17.798810170817813F, 7.445993769617116F, 2.130812205996545F, 0.3434037302405675F, -1.292458098589896F));
        g.addOrReplaceChild("nariz_331", CubeListBuilder.create().texOffs(100, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-51.76945188875924F, -19.567395810007945F, 7.047837185281173F, 2.1605785931067922F, 0.3432614847659053F, -1.2264113782730248F));
        g.addOrReplaceChild("nariz_332", CubeListBuilder.create().texOffs(746, 138).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-50.40816532418927F, -21.509553531950697F, 6.640341110603188F, 2.1923023556494146F, 0.3503004955105413F, -1.1841549993144587F));
        g.addOrReplaceChild("nariz_333", CubeListBuilder.create().texOffs(672, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-48.87325368324194F, -23.49872593758292F, 6.232093186930126F, 2.231405729134152F, 0.3579202447631984F, -1.1408585550781776F));
        g.addOrReplaceChild("nariz_334", CubeListBuilder.create().texOffs(692, 202).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-47.216886400066564F, -25.467339201148675F, 5.835418393573218F, 2.2808810176343584F, 0.36557443793071565F, -1.093738891933163F));
        g.addOrReplaceChild("nariz_335", CubeListBuilder.create().texOffs(1000, 212).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-45.47405121946746F, -27.372011077621217F, 5.4617494838904745F, 2.346144757211541F, 0.3705748820362809F, -1.0379529914194987F));
        g.addOrReplaceChild("nariz_336", CubeListBuilder.create().texOffs(0, 216).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-43.70498245277507F, -29.173949801403904F, 5.075584965891968F, 2.484215479069158F, 0.16563307479860775F, -0.7800970732794246F));
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("nariz_337", CubeListBuilder.create().texOffs(482, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.9460728361404F, -30.836673381055427F, 4.554873844071098F, 2.596656782367425F, 0.2591669987472755F, -0.7334704833749472F));
        g.addOrReplaceChild("nariz_338", CubeListBuilder.create().texOffs(496, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.21158720117182F, -32.317671680321176F, 3.8232364791449953F, 2.7017082033164046F, 0.36364794796829086F, -0.6778781728673329F));
        g.addOrReplaceChild("nariz_339", CubeListBuilder.create().texOffs(616, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.57855238099563F, -33.5484519500259F, 2.890397896170064F, 2.8032845266582167F, 0.49751552112809005F, -0.6087858385350402F));
        g.addOrReplaceChild("nariz_340", CubeListBuilder.create().texOffs(912, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.204856902807286F, -34.42802127194676F, 1.8058649408489247F, 2.90138920004377F, 0.6939523132934807F, -0.5150915918493072F));
        g.addOrReplaceChild("nariz_341", CubeListBuilder.create().texOffs(592, 130).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-51.78910034264934F, -10.54039154758309F, 9.067370151801232F, 1.9352334401389728F, 0.0391485818821596F, -1.67302151882607F));
        g.addOrReplaceChild("nariz_342", CubeListBuilder.create().texOffs(862, 130).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-51.717151083233794F, -13.98056608019655F, 8.926545093954928F, 1.953135046577522F, 0.12640771634953937F, -1.6030807306637096F));
        g.addOrReplaceChild("nariz_343", CubeListBuilder.create().texOffs(244, 138).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-51.468023307254846F, -15.955401429790104F, 8.76789218940251F, 1.9532959859971666F, 0.2302780933770453F, -1.6534949382104713F));
        g.addOrReplaceChild("nariz_344", CubeListBuilder.create().texOffs(78, 138).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-51.2340160218403F, -16.796980546136353F, 8.64636231777977F, 1.955325251235331F, 0.3095874780103626F, -1.6192003162387751F));
        g.addOrReplaceChild("nariz_345", CubeListBuilder.create().texOffs(512, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-50.68288518847918F, -18.166666797963533F, 8.335557281779755F, 2.063468696565501F, 0.34207319088113114F, -1.3166179251856849F));
        g.addOrReplaceChild("nariz_346", CubeListBuilder.create().texOffs(120, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-49.71714880774181F, -19.90422177816688F, 7.91084862854273F, 2.0889356450952703F, 0.3441455133593851F, -1.2736877149466463F));
        g.addOrReplaceChild("nariz_347", CubeListBuilder.create().texOffs(140, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-48.52901532420212F, -21.803901176643905F, 7.461297662016733F, 2.11770577375553F, 0.3499633085084891F, -1.2360121695449062F));
        g.addOrReplaceChild("nariz_348", CubeListBuilder.create().texOffs(892, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-47.191117258686745F, -23.749450587243846F, 7.008644699108791F, 2.1535584348501016F, 0.356735189056467F, -1.1971476891887505F));
        g.addOrReplaceChild("nariz_349", CubeListBuilder.create().texOffs(910, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-45.748339741028744F, -25.674871726733578F, 6.567031290872212F, 2.199506110339046F, 0.3641371311087247F, -1.1545892385968852F));
        g.addOrReplaceChild("nariz_350", CubeListBuilder.create().texOffs(146, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-44.22769409719936F, -27.538116265816207F, 6.152654149657593F, 2.261442126699362F, 0.36751838415729876F, -1.1030586384836865F));
        g.addOrReplaceChild("nariz_351", CubeListBuilder.create().texOffs(162, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-42.69304092602639F, -29.300303644675786F, 5.713809370446329F, 2.3441154227965653F, 0.41001566263193384F, -1.0458538469192784F));
        g.addOrReplaceChild("nariz_352", CubeListBuilder.create().texOffs(510, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.17333696851637F, -30.926114197412645F, 5.115895851793116F, 2.522858205545471F, 0.3169165259682704F, -0.7936198980606429F));
        g.addOrReplaceChild("nariz_353", CubeListBuilder.create().texOffs(524, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-39.666849692495575F, -32.37508714071056F, 4.288625624389776F, 2.633266225603235F, 0.4384947065194159F, -0.7359357064458723F));
        g.addOrReplaceChild("nariz_354", CubeListBuilder.create().texOffs(628, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.24463146873981F, -33.57955950302953F, 3.2405369955431857F, 2.7404758720514666F, 0.5905750615930189F, -0.663965024563596F));
        g.addOrReplaceChild("nariz_355", CubeListBuilder.create().texOffs(922, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0466147650154F, -34.44041344457968F, 2.025786965407737F, 2.844175997573441F, 0.802759471689812F, -0.5658295788430029F));
        g.addOrReplaceChild("nariz_356", CubeListBuilder.create().texOffs(620, 130).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-49.37797857502233F, -11.056449158129698F, 9.924352051374967F, 1.8857881365592835F, 0.0333178466856636F, -1.6701956235405253F));
        g.addOrReplaceChild("nariz_357", CubeListBuilder.create().texOffs(960, 130).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-49.28554063455739F, -14.428751588380063F, 9.804556709139614F, 1.906687931491088F, 0.10944039486676392F, -1.5906775743939603F));
        g.addOrReplaceChild("nariz_358", CubeListBuilder.create().texOffs(260, 138).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-49.02924235827512F, -16.37060055745345F, 9.675730594607115F, 1.908491869538714F, 0.18684244881190876F, -1.6687590477984349F));
        g.addOrReplaceChild("nariz_359", CubeListBuilder.create().texOffs(96, 138).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-48.859290375331625F, -17.194335967692766F, 9.507765975688079F, 1.9141813527675964F, 0.34891482790563144F, -1.609783763296999F));
        g.addOrReplaceChild("nariz_360", CubeListBuilder.create().texOffs(530, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-48.4170726422139F, -18.534900015378426F, 9.135872998892417F, 1.9983192106193917F, 0.3418315529071778F, -1.358508524566238F));
        g.addOrReplaceChild("nariz_361", CubeListBuilder.create().texOffs(160, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-47.595541235582964F, -20.2354186899815F, 8.681880844023343F, 2.020807479648535F, 0.34311615173943605F, -1.3209199374311706F));
        g.addOrReplaceChild("nariz_362", CubeListBuilder.create().texOffs(180, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-46.58659377874319F, -22.093833325398585F, 8.197533123276646F, 2.046336794803114F, 0.34760559376963235F, -1.2879465653433277F));
        g.addOrReplaceChild("nariz_363", CubeListBuilder.create().texOffs(928, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-45.451634940597F, -23.996851994445024F, 7.708048432544171F, 2.078392965457571F, 0.35314591730679046F, -1.2537953385340237F));
        g.addOrReplaceChild("nariz_364", CubeListBuilder.create().texOffs(946, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-44.22828344363644F, -25.880048415711645F, 7.229175706912285F, 2.119852808346363F, 0.3595857755022752F, -1.2163173733468813F));
        g.addOrReplaceChild("nariz_365", CubeListBuilder.create().texOffs(178, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-42.939567234599835F, -27.70219013992261F, 6.779815165891974F, 2.175369937867018F, 0.3606542726492098F, -1.1715728967319898F));
        g.addOrReplaceChild("nariz_366", CubeListBuilder.create().texOffs(194, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.644709604095226F, -29.425459091005223F, 6.294765527254343F, 2.2556709025559964F, 0.42004224566152193F, -1.1191822896013306F));
        g.addOrReplaceChild("nariz_367", CubeListBuilder.create().texOffs(538, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.365709174949316F, -31.015598319731737F, 5.628531283362914F, 2.439540922291291F, 0.378357739600323F, -0.8675883194152566F));
        g.addOrReplaceChild("nariz_368", CubeListBuilder.create().texOffs(552, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-39.09414112604088F, -32.43290576058095F, 4.715029622405253F, 2.5514989387138858F, 0.517404657177279F, -0.8089260751139967F));
        g.addOrReplaceChild("nariz_369", CubeListBuilder.create().texOffs(640, 227).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.89119948676434F, -33.611096415164745F, 3.562550754060214F, 2.66078446529592F, 0.6862614677893705F, -0.7351075167030446F));
        g.addOrReplaceChild("nariz_370", CubeListBuilder.create().texOffs(932, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.877566178683054F, -34.45307663743222F, 2.2291754484456376F, 2.7668510146768415F, 0.9086290076787319F, -0.6335395460856289F));
        g.addOrReplaceChild("nariz_371", CubeListBuilder.create().texOffs(648, 130).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-46.90444133185F, -11.527706330683746F, 10.669317520649091F, 1.8389345315903074F, 0.02931488529754366F, -1.6624198009082054F));
        g.addOrReplaceChild("nariz_372", CubeListBuilder.create().texOffs(984, 130).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-46.79928190134582F, -14.84275669935853F, 10.575977690796996F, 1.8592240902632455F, 0.08444453329611383F, -1.5832940510366338F));
        g.addOrReplaceChild("nariz_373", CubeListBuilder.create().texOffs(42, 151).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-46.61536180277559F, -16.751517119997644F, 10.452663595998093F, 1.8583791013425308F, 0.1840375059968255F, -1.6663534588055637F));
        g.addOrReplaceChild("nariz_374", CubeListBuilder.create().texOffs(884, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-46.502227563794236F, -17.561000315922715F, 10.23682993637242F, 1.862085126806219F, 0.38134071757406235F, -1.6074337957578364F));
        g.addOrReplaceChild("nariz_375", CubeListBuilder.create().texOffs(548, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-46.10123497447201F, -18.88533811911035F, 9.83558006620952F, 1.9347414398702611F, 0.3399219152469478F, -1.4006151511670526F));
        g.addOrReplaceChild("nariz_376", CubeListBuilder.create().texOffs(200, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-45.42816568171327F, -20.551135839673535F, 9.358056071085695F, 1.9540574210600359F, 0.34061211998658614F, -1.3686978965130465F));
        g.addOrReplaceChild("nariz_377", CubeListBuilder.create().texOffs(220, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-44.60269798611405F, -22.37061574631489F, 8.845437852348029F, 1.9760995185949515F, 0.34379482884298135F, -1.3406623700971003F));
        g.addOrReplaceChild("nariz_378", CubeListBuilder.create().texOffs(964, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.674748726001894F, -24.233354035212642F, 8.325889156673366F, 2.0039297792885433F, 0.3479065811422111F, -1.311541462420933F));
        g.addOrReplaceChild("nariz_379", CubeListBuilder.create().texOffs(982, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.67470038609014F, -26.076448064917045F, 7.81653733314019F, 2.0401526244012143F, 0.35289543675317975F, -1.2795915981225396F));
        g.addOrReplaceChild("nariz_380", CubeListBuilder.create().texOffs(210, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.62218438768084F, -27.859407090272974F, 7.338111809705808F, 2.0879116752478692F, 0.35100802788672736F, -1.242491545525349F));
        g.addOrReplaceChild("nariz_381", CubeListBuilder.create().texOffs(226, 216).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.56982693014648F, -29.545745689444246F, 6.812684002254066F, 2.162996843672311F, 0.4280236545752282F, -1.1963464903835286F));
        g.addOrReplaceChild("nariz_382", CubeListBuilder.create().texOffs(566, 220).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-39.53342336186884F, -31.1021113069756F, 6.08580051037586F, 2.3425155112548133F, 0.44204312605387813F, -0.9581984276530494F));
        g.addOrReplaceChild("nariz_383", CubeListBuilder.create().texOffs(712, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-38.500919658560875F, -32.489109376386246F, 5.09583667093207F, 2.4506460636365186F, 0.5981975802649981F, -0.9007462573554812F));
        g.addOrReplaceChild("nariz_384", CubeListBuilder.create().texOffs(942, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.52307972807252F, -33.64190310771107F, 3.8505230212114876F, 2.556640894742809F, 0.7815060670781239F, -0.827489355304922F));
        g.addOrReplaceChild("nariz_385", CubeListBuilder.create().texOffs(952, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.70023589221882F, -34.46550003346036F, 2.4112200619270574F, 2.6597383609059397F, 1.008405559615976F, -0.7254270029156966F));
        g.addOrReplaceChild("nariz_386", CubeListBuilder.create().texOffs(676, 130).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-44.37797859496269F, -11.946680488885145F, 11.306789018982593F, 1.7958082691423383F, 0.023982398477500236F, -1.6477450420875368F));
        g.addOrReplaceChild("nariz_387", CubeListBuilder.create().texOffs(0, 138).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-44.26993462173171F, -15.215306186220875F, 11.242346604063737F, 1.8132400792931473F, 0.058888687649091026F, -1.5849421031550546F));
        g.addOrReplaceChild("nariz_388", CubeListBuilder.create().texOffs(276, 138).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-44.21163142215766F, -17.09297454172398F, 11.091505907900505F, 1.8137285087449027F, 0.2924230407762831F, -1.63231905266959F));
        g.addOrReplaceChild("nariz_389", CubeListBuilder.create().texOffs(114, 138).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-44.119371140926546F, -17.895332818395257F, 10.835619829204974F, 1.8064962364762907F, 0.37418955384478836F, -1.6147436206285137F));
        g.addOrReplaceChild("nariz_390", CubeListBuilder.create().texOffs(566, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-43.75869948198605F, -19.206019275640468F, 10.43058238482798F, 1.8708213427323555F, 0.3366999676506606F, -1.442858459341948F));
        g.addOrReplaceChild("nariz_391", CubeListBuilder.create().texOffs(584, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-43.23701015428276F, -20.840425898237918F, 9.934608881065458F, 1.8867191112366426F, 0.3369865251346291F, -1.4171125027357256F));
        g.addOrReplaceChild("nariz_392", CubeListBuilder.create().texOffs(240, 145).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-42.597848021517414F, -22.624485617301392F, 9.399526548516988F, 1.9050036197167435F, 0.33898248813142107F, -1.3943832554822742F));
        g.addOrReplaceChild("nariz_393", CubeListBuilder.create().texOffs(1000, 202).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.87949989583308F, -24.45043442930948F, 8.855893785651112F, 1.9281992418710883F, 0.34164600798030786F, -1.3706975734912827F));
        g.addOrReplaceChild("nariz_394", CubeListBuilder.create().texOffs(0, 207).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.105167291419804F, -26.256790969965593F, 8.321950238480174F, 1.9585238976049968F, 0.34495418138646683F, -1.3447356183766637F));
        g.addOrReplaceChild("nariz_395", CubeListBuilder.create().texOffs(396, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.291223577693025F, -28.003772459401176F, 7.819361419936648F, 1.9977021034965916F, 0.340081805685318F, -1.3157853807555706F));
        g.addOrReplaceChild("nariz_396", CubeListBuilder.create().texOffs(410, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.48193304502923F, -29.656404685348647F, 7.258954598703706F, 2.0640816637098163F, 0.43438863722670107F, -1.2772819500869181F));
        g.addOrReplaceChild("nariz_397", CubeListBuilder.create().texOffs(724, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-38.68790644557951F, -31.182033612733303F, 6.479368698257868F, 2.2266878397862753F, 0.505030743838909F, -1.0681610679231897F));
        g.addOrReplaceChild("nariz_398", CubeListBuilder.create().texOffs(736, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-37.89622620001443F, -32.54118914027718F, 5.423161937989109F, 2.3235414688851934F, 0.6768798603715752F, -1.0156587884026131F));
        g.addOrReplaceChild("nariz_399", CubeListBuilder.create().texOffs(962, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.14685257373459F, -33.67047207471974F, 4.097287735840333F, 2.418246322202856F, 0.8715468733381986F, -0.9476552587695048F));
        g.addOrReplaceChild("nariz_400", CubeListBuilder.create().texOffs(972, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.518849923368734F, -34.47697085951757F, 2.565761612977475F, 2.509347441216904F, 1.0981507904649812F, -0.8517639140545527F));
        g.addOrReplaceChild("nariz_401", CubeListBuilder.create().texOffs(704, 130).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-41.848298762799786F, -12.298560378444991F, 11.826254312466304F, 1.7502466531093293F, 0.016630329589520175F, -1.6315336856129845F));
        g.addOrReplaceChild("nariz_402", CubeListBuilder.create().texOffs(768, 138).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-41.799083529842505F, -15.526335496331003F, 11.773905922303324F, 1.7591672718461149F, 0.04247893135479972F, -1.603521408826373F));
        g.addOrReplaceChild("nariz_403", CubeListBuilder.create().texOffs(56, 151).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-41.77375016014923F, -17.391887368710016F, 11.594364555967545F, 1.753142886879122F, 0.35550512041678434F, -1.6177858345142229F));
        g.addOrReplaceChild("nariz_404", CubeListBuilder.create().texOffs(900, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-41.6713075468204F, -18.192232823526133F, 11.327193689627254F, 1.7565043978812116F, 0.35506656688222876F, -1.6153601113971472F));
        g.addOrReplaceChild("nariz_405", CubeListBuilder.create().texOffs(602, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-41.41585028881283F, -19.482829115628455F, 10.913464631734396F, 1.8043606705545774F, 0.33260105767442066F, -1.484640256430951F));
        g.addOrReplaceChild("nariz_406", CubeListBuilder.create().texOffs(620, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-41.04711385432033F, -21.090333005611118F, 10.403498358069486F, 1.8165293309620347F, 0.33264063996480014F, -1.465648320134086F));
        g.addOrReplaceChild("nariz_407", CubeListBuilder.create().texOffs(638, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-40.59561092828618F, -22.843860185315112F, 9.851106658616374F, 1.8307072714713497F, 0.3336505461609935F, -1.448698026471698F));
        g.addOrReplaceChild("nariz_408", CubeListBuilder.create().texOffs(178, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.08802085031079F, -24.63796497159661F, 9.28866678371768F, 1.8487882970395442F, 0.3350210697343455F, -1.4309462640242485F));
        g.addOrReplaceChild("nariz_409", CubeListBuilder.create().texOffs(194, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.54048309748554F, -26.412416851616435F, 8.735219037784294F, 1.8725070105104176F, 0.3367156734748299F, -1.4114902336736264F));
        g.addOrReplaceChild("nariz_410", CubeListBuilder.create().texOffs(424, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-38.965758325392066F, -28.128130279729334F, 8.212608105137585F, 1.9025318661872685F, 0.32939045395035094F, -1.3908888212218096F));
        g.addOrReplaceChild("nariz_411", CubeListBuilder.create().texOffs(438, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-38.39814100980978F, -29.751697701897402F, 7.622571175011647F, 1.956128267583015F, 0.43931669804531603F, -1.3612394596583384F));
        g.addOrReplaceChild("nariz_412", CubeListBuilder.create().texOffs(748, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-37.84427706922854F, -31.250935852007245F, 6.798843343994747F, 2.086481497393574F, 0.5624600608178192F, -1.1987732304517005F));
        g.addOrReplaceChild("nariz_413", CubeListBuilder.create().texOffs(760, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-37.29275318354958F, -32.58602535931584F, 5.687406511607642F, 2.1625425342194067F, 0.7472462684651651F, -1.1567172781319182F));
        g.addOrReplaceChild("nariz_414", CubeListBuilder.create().texOffs(982, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.772516403029385F, -33.694898974526176F, 4.294344087630106F, 2.234990529409502F, 0.9496317188232555F, -1.1016964348980525F));
        g.addOrReplaceChild("nariz_415", CubeListBuilder.create().texOffs(992, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.340603598891185F, -34.48657779681797F, 2.6857556810264502F, 2.3001515764145166F, 1.172559424406874F, -1.0245328464087646F));
        g.addOrReplaceChild("nariz_416", CubeListBuilder.create().texOffs(466, 138).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-39.361028811675624F, -12.56602673892765F, 12.212323666956515F, 1.6984042863868598F, 0.00860960621442075F, -1.6138144411768613F));
        g.addOrReplaceChild("nariz_417", CubeListBuilder.create().texOffs(790, 138).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-39.36782663919582F, -15.765720465490254F, 12.154612111338906F, 1.697209994000658F, 0.04157642976038794F, -1.613028050333676F));
        g.addOrReplaceChild("nariz_418", CubeListBuilder.create().texOffs(70, 151).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-39.342082278472986F, -17.62742797189957F, 11.954332999463535F, 1.6995680844450651F, 0.33766358474346F, -1.6099197942746823F));
        g.addOrReplaceChild("nariz_419", CubeListBuilder.create().texOffs(916, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-39.26267087737444F, -18.423056114305755F, 11.69101298607658F, 1.7017621207819098F, 0.33836532355698434F, -1.6079603521299086F));
        g.addOrReplaceChild("nariz_420", CubeListBuilder.create().texOffs(656, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-39.11268026597506F, -19.698109683129545F, 11.271197950755024F, 1.7318178183596074F, 0.328247812947214F, -1.5246222638900406F));
        g.addOrReplaceChild("nariz_421", CubeListBuilder.create().texOffs(674, 145).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-38.89665636935501F, -21.284663499140965F, 10.751216617413206F, 1.7398466227586848F, 0.328158638971122F, -1.512936831619912F));
        g.addOrReplaceChild("nariz_422", CubeListBuilder.create().texOffs(210, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-38.63217743955717F, -23.014288926482518F, 10.186206161926533F, 1.7494069340935048F, 0.32845889374694975F, -1.5022765773148483F));
        g.addOrReplaceChild("nariz_423", CubeListBuilder.create().texOffs(226, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-38.33455423186352F, -24.783360716860415F, 9.609767382317344F, 1.761684339129784F, 0.32886784837328753F, -1.4910184717318646F));
        g.addOrReplaceChild("nariz_424", CubeListBuilder.create().texOffs(242, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-38.01310526189215F, -26.532642966076114F, 9.041395510124435F, 1.7778344198281828F, 0.3293359810352552F, -1.478655586415095F));
        g.addOrReplaceChild("nariz_425", CubeListBuilder.create().texOffs(452, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-37.67618194532269F, -28.223709285518506F, 8.502641601314028F, 1.797958253265547F, 0.3204641043994711F, -1.4663034408109203F));
        g.addOrReplaceChild("nariz_426", CubeListBuilder.create().texOffs(466, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-37.34640363512105F, -29.8246097360281F, 7.88891729752271F, 1.8343414430125549F, 0.4429223897273174F, -1.4464977216524424F));
    }

    private static void piezas6(PartDefinition g) {
        g.addOrReplaceChild("nariz_427", CubeListBuilder.create().texOffs(772, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-37.02767088810676F, -31.30342649937971F, 7.030903798725189F, 1.9166950750868306F, 0.6076997493307452F, -1.3473618988971499F));
        g.addOrReplaceChild("nariz_428", CubeListBuilder.create().texOffs(784, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.712007666797774F, -32.619866426614934F, 5.87691162808468F, 1.9622397504382483F, 0.8011665849703826F, -1.3218148297567618F));
        g.addOrReplaceChild("nariz_429", CubeListBuilder.create().texOffs(1002, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.41712038450808F, -33.71297383024389F, 4.43234171609997F, 2.001216433318224F, 1.0072515847159134F, -1.2890252734003436F));
        g.addOrReplaceChild("nariz_430", CubeListBuilder.create().texOffs(492, 138).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-37.067441585187716F, -12.722389982170673F, 12.434809450934393F, 1.6317958117150269F, 0.00202912888020617F, -1.5916546494021455F));
        g.addOrReplaceChild("nariz_431", CubeListBuilder.create().texOffs(812, 138).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-37.07007230297961F, -15.911483400103318F, 12.373235047595752F, 1.631442318050644F, 0.0436093278296059F, -1.591427409048237F));
        g.addOrReplaceChild("nariz_432", CubeListBuilder.create().texOffs(84, 151).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-37.06326679054786F, -17.76987230831307F, 12.165042934487353F, 1.632082569949495F, 0.32654350801445897F, -1.591114119100782F));
        g.addOrReplaceChild("nariz_433", CubeListBuilder.create().texOffs(932, 145).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-37.037375444586345F, -18.56027228804989F, 11.900327073555324F, 1.6418013986677988F, 0.3247919914965471F, -1.5631586343647277F));
        g.addOrReplaceChild("nariz_434", CubeListBuilder.create().texOffs(258, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-36.98867559620225F, -19.825976182638936F, 11.476926888371295F, 1.6444435247113705F, 0.32459739498653317F, -1.5591307862601194F));
        g.addOrReplaceChild("nariz_435", CubeListBuilder.create().texOffs(274, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-36.91867274243923F, -21.399882723580262F, 10.95099803759938F, 1.6478022947842534F, 0.3244638593180199F, -1.554986492047499F));
        g.addOrReplaceChild("nariz_436", CubeListBuilder.create().texOffs(290, 207).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-36.83295616406847F, -23.115021168760123F, 10.378352493965032F, 1.6519642876179523F, 0.32441133133082495F, -1.5510509050499577F));
        g.addOrReplaceChild("nariz_437", CubeListBuilder.create().texOffs(480, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.736386989762295F, -24.86886265494532F, 9.7931988098071F, 1.6573913840585939F, 0.3243550578410338F, -1.5468214342543438F));
        g.addOrReplaceChild("nariz_438", CubeListBuilder.create().texOffs(494, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.6319589780184F, -26.602786099938204F, 9.215174887733493F, 1.6645882159429306F, 0.32426456523551367F, -1.5421261330332503F));
        g.addOrReplaceChild("nariz_439", CubeListBuilder.create().texOffs(508, 216).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.52262089512174F, -28.27885214205816F, 8.665463643496027F, 1.6735958257953318F, 0.31486786652458865F, -1.5376101700905211F));
        g.addOrReplaceChild("nariz_440", CubeListBuilder.create().texOffs(796, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.416529419687755F, -29.86617144258229F, 8.0364175089533F, 1.6991518465113862F, 0.4426531989782601F, -1.504957310018548F));
        g.addOrReplaceChild("nariz_441", CubeListBuilder.create().texOffs(808, 220).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.315092026322304F, -31.332954488427F, 7.157374171929157F, 1.7159720095344762F, 0.6330642610395185F, -1.4982289142698273F));
        g.addOrReplaceChild("nariz_442", CubeListBuilder.create().texOffs(1012, 227).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.215396389304686F, -32.63850695451688F, 5.977767923155086F, 1.7292048614077895F, 0.8299660926145082F, -1.4903800040368858F));
        g.addOrReplaceChild("nariz_443", CubeListBuilder.create().texOffs(0, 229).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.12344472675432F, -33.72257582866537F, 4.502892113760449F, 1.7367592620582757F, 1.036079830408288F, -1.4808457302087796F));
        g.addOrReplaceChild("chimenea_0", CubeListBuilder.create().texOffs(204, 212).addBox(-5.0F, -35.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(868, 89).addBox(-1.0F, -35.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offset(-37.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_1", CubeListBuilder.create().texOffs(228, 212).addBox(-5.0F, -35.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(892, 89).addBox(-1.0F, -35.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-37.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_2", CubeListBuilder.create().texOffs(252, 212).addBox(-5.0F, -35.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(916, 89).addBox(-1.0F, -35.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-37.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_3", CubeListBuilder.create().texOffs(276, 212).addBox(-5.0F, -35.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(940, 89).addBox(-1.0F, -35.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-37.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("silbato_0", CubeListBuilder.create().texOffs(148, 130).addBox(-6.0F, -37.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(200, 89).addBox(-2.5F, -37.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(31.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("silbato_1", CubeListBuilder.create().texOffs(182, 130).addBox(-6.0F, -37.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(234, 89).addBox(-2.5F, -37.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(31.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("farol", CubeListBuilder.create().texOffs(606, 216).addBox(-61.0F, -16.0F, -1.0F, 2.0F, 2.0F, 2.0F).texOffs(22, 229).addBox(-62.0F, -15.5F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(100, 89).addBox(36.0F, -34.0F, 11.5F, 24.0F, 17.0F, 1.0F).texOffs(150, 89).addBox(36.0F, -34.0F, -12.5F, 24.0F, 17.0F, 1.0F).texOffs(624, 56).addBox(41.0F, -18.0F, -11.5F, 19.0F, 1.0F, 23.0F).texOffs(940, 56).addBox(41.0F, -29.0F, -5.0F, 2.0F, 11.0F, 10.0F).texOffs(292, 138).addBox(43.0F, -23.0F, -2.0F, 1.0F, 3.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_cuna_0", CubeListBuilder.create().texOffs(428, 56).addBox(-12.0F, -1.0F, -12.5F, 24.0F, 1.0F, 25.0F), PartPose.offsetAndRotation(38.80392156862745F, -32.2F, -6.25F, 3.141592653589793F, 0.0F, -1.0762705044059184F));
        g.addOrReplaceChild("cabina_cuna_1", CubeListBuilder.create().texOffs(526, 56).addBox(-12.0F, -1.0F, -12.5F, 24.0F, 1.0F, 25.0F), PartPose.offsetAndRotation(38.80392156862745F, -32.2F, 6.25F, 3.141592653589793F, 0.0F, -1.0762705044059184F));
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(550, 207).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -34.280047391071406F, -11.526459469667696F, -2.6818551972416236F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(602, 207).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -35.16112455113704F, -9.542532937373895F, -2.7654438256685654F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(654, 207).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -35.873484783820615F, -7.491970978685589F, -2.8490324540955045F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(706, 207).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -36.41215368367204F, -5.389092650331454F, -2.932621082522443F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(758, 207).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -36.77336973034208F, -3.2485823338048823F, -3.016209710949384F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(810, 207).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -36.95461055524703F, -1.085387194452817F, -3.0997983393763233F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(862, 207).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -36.95461055524703F, 1.0853871944528155F, 3.0997983393763233F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(914, 207).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -36.77336973034208F, 3.2485823338048796F, 3.016209710949384F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(966, 207).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -36.41215368367204F, 5.3890926503314525F, 2.932621082522443F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(0, 212).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -35.873484783820615F, 7.491970978685588F, 2.849032454095504F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(52, 212).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -35.16112455113704F, 9.542532937373895F, 2.765443825668566F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(104, 212).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.5F, -34.280047391071406F, 11.526459469667696F, 2.6818551972416236F, 0.0F, 0.0F));
    }

    private static void piezas7(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(964, 89).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(72, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 207).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(74.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(96, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(722, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(74.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(120, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(732, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(74.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(964, 89).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(72, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 207).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(90.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(96, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(722, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(90.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(120, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(732, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(90.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri2_0", CubeListBuilder.create().texOffs(964, 89).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(72, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 207).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(112.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri2_1", CubeListBuilder.create().texOffs(96, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(722, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(112.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri2_2", CubeListBuilder.create().texOffs(120, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(732, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(112.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri3_0", CubeListBuilder.create().texOffs(964, 89).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(72, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(500, 207).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(128.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri3_1", CubeListBuilder.create().texOffs(96, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(722, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(128.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri3_2", CubeListBuilder.create().texOffs(120, 202).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(732, 108).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(128.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(964, 89).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(72, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 207).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(74.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(96, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(722, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(74.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(120, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(732, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(74.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(964, 89).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(72, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(520, 207).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(90.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(96, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(722, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(90.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(120, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(732, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(90.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd2_0", CubeListBuilder.create().texOffs(964, 89).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(72, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(530, 207).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(112.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd2_1", CubeListBuilder.create().texOffs(96, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(722, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(112.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd2_2", CubeListBuilder.create().texOffs(120, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(732, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(112.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd3_0", CubeListBuilder.create().texOffs(964, 89).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(72, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(540, 207).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(128.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd3_1", CubeListBuilder.create().texOffs(96, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(722, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(128.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd3_2", CubeListBuilder.create().texOffs(120, 202).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(732, 108).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(128.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(492, 120).addBox(64.0F, -13.0F, 2.0F, 76.0F, 9.0F, 1.0F).texOffs(646, 120).addBox(64.0F, -13.0F, -3.0F, 76.0F, 9.0F, 1.0F).texOffs(800, 120).addBox(66.0F, -12.0F, 6.0F, 72.0F, 6.0F, 2.0F).texOffs(0, 130).addBox(66.0F, -12.0F, -8.0F, 72.0F, 6.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(204, 0).addBox(64.0F, -32.0F, -12.5F, 76.0F, 19.0F, 25.0F).texOffs(708, 56).addBox(64.0F, -35.0F, -9.5F, 76.0F, 3.0F, 19.0F).texOffs(0, 89).addBox(66.0F, -36.0F, -9.0F, 32.0F, 1.0F, 18.0F).texOffs(404, 56).addBox(140.0F, -33.0F, -5.0F, 2.0F, 18.0F, 10.0F).texOffs(356, 56).addBox(140.0F, -13.0F, -11.0F, 2.0F, 7.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender_caja_cantoi_0", CubeListBuilder.create().texOffs(0, 223).addBox(-38.0F, -1.0F, -0.5F, 76.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(102.0F, -32.46352549156242F, -12.42658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_1", CubeListBuilder.create().texOffs(154, 223).addBox(-38.0F, -1.0F, -0.5F, 76.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(102.0F, -33.34520337000113F, -12.140110266005152F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_2", CubeListBuilder.create().texOffs(308, 223).addBox(-38.0F, -1.0F, -0.5F, 76.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(102.0F, -34.09520337000113F, -11.59520337000113F, -2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_3", CubeListBuilder.create().texOffs(462, 223).addBox(-38.0F, -1.0F, -0.5F, 76.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(102.0F, -34.64011026600515F, -10.845203370001132F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_4", CubeListBuilder.create().texOffs(616, 223).addBox(-38.0F, -1.0F, -0.5F, 76.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(102.0F, -34.92658477444273F, -9.963525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_0", CubeListBuilder.create().texOffs(770, 223).addBox(-38.0F, -1.0F, -0.5F, 76.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(102.0F, -32.46352549156242F, 12.42658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_1", CubeListBuilder.create().texOffs(0, 225).addBox(-38.0F, -1.0F, -0.5F, 76.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(102.0F, -33.34520337000113F, 12.140110266005152F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_2", CubeListBuilder.create().texOffs(154, 225).addBox(-38.0F, -1.0F, -0.5F, 76.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(102.0F, -34.09520337000113F, 11.59520337000113F, 2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_3", CubeListBuilder.create().texOffs(308, 225).addBox(-38.0F, -1.0F, -0.5F, 76.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(102.0F, -34.64011026600515F, 10.845203370001132F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_4", CubeListBuilder.create().texOffs(462, 225).addBox(-38.0F, -1.0F, -0.5F, 76.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(102.0F, -34.92658477444273F, 9.963525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 50.0F), PartPose.offset(64.0F, -32.0F, -12.5F));
        g.addOrReplaceChild("tender_caja_tapab", CubeListBuilder.create().texOffs(102, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 50.0F), PartPose.offset(139.0F, -32.0F, -12.5F));
        g.addOrReplaceChild("tope_ti_0", CubeListBuilder.create().texOffs(236, 56).addBox(142.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(754, 0).addBox(142.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.0F, -8.0F));
        g.addOrReplaceChild("tope_ti_1", CubeListBuilder.create().texOffs(256, 56).addBox(142.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(812, 0).addBox(142.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ti_2", CubeListBuilder.create().texOffs(276, 56).addBox(142.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(870, 0).addBox(142.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_0", CubeListBuilder.create().texOffs(886, 108).addBox(145.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(506, 108).addBox(145.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.0F, -8.0F));
        g.addOrReplaceChild("tope_tic_1", CubeListBuilder.create().texOffs(892, 108).addBox(145.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(528, 108).addBox(145.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_2", CubeListBuilder.create().texOffs(898, 108).addBox(145.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(550, 108).addBox(145.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_3", CubeListBuilder.create().texOffs(904, 108).addBox(145.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(572, 108).addBox(145.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_0", CubeListBuilder.create().texOffs(296, 56).addBox(142.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(928, 0).addBox(142.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.0F, 8.0F));
        g.addOrReplaceChild("tope_td_1", CubeListBuilder.create().texOffs(316, 56).addBox(142.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(0, 56).addBox(142.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_2", CubeListBuilder.create().texOffs(336, 56).addBox(142.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(58, 56).addBox(142.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_0", CubeListBuilder.create().texOffs(910, 108).addBox(145.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(594, 108).addBox(145.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.0F, 8.0F));
        g.addOrReplaceChild("tope_tdc_1", CubeListBuilder.create().texOffs(916, 108).addBox(145.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(616, 108).addBox(145.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_2", CubeListBuilder.create().texOffs(922, 108).addBox(145.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(638, 108).addBox(145.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_3", CubeListBuilder.create().texOffs(928, 108).addBox(145.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(660, 108).addBox(145.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 1.1780972450961724F, 0.0F, 0.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "cil_i_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "tope_i_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_ic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_d_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_dc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "carcasa_0", 0.5F, 1.0F, 0.495154960200896F);
        escalar(g0, "carcasa_1", 0.5F, 1.0F, 0.495154960200896F);
        escalar(g0, "carcasa_2", 0.5F, 1.0F, 0.495154960200896F);
        escalar(g0, "carcasa_3", 0.5F, 1.0F, 0.4944189439573119F);
        escalar(g0, "carcasa_4", 0.5F, 1.0F, 0.49515496020089594F);
        escalar(g0, "carcasa_5", 0.5F, 1.0F, 0.49515496020089605F);
        escalar(g0, "carcasa_6", 0.5F, 1.0F, 0.4951549602008968F);
        escalar(g0, "carcasa_7", 0.5F, 1.0F, 0.4951549602008952F);
        escalar(g0, "carcasa_8", 0.5F, 1.0F, 0.49515496020089594F);
        escalar(g0, "carcasa_9", 0.5F, 1.0F, 0.49513340622639856F);
        escalar(g0, "carcasa_10", 0.5F, 1.0F, 0.4946980072040766F);
        escalar(g0, "carcasa_11", 0.5F, 1.0F, 0.49478635716684144F);
        escalar(g0, "carcasa_12", 0.5F, 1.0F, 0.49487622828318667F);
        escalar(g0, "carcasa_13", 0.5F, 1.0F, 0.4949676197245289F);
        escalar(g0, "carcasa_14", 0.5F, 1.0F, 0.49506053064888156F);
        escalar(g0, "carcasa_15", 0.5F, 1.0F, 0.49506053064888106F);
        escalar(g0, "carcasa_16", 0.5F, 1.0F, 0.49496761972452724F);
        escalar(g0, "carcasa_17", 0.5F, 1.0F, 0.4948762282831859F);
        escalar(g0, "carcasa_18", 0.5F, 1.0F, 0.49478635716684016F);
        escalar(g0, "carcasa_19", 0.5F, 1.0F, 0.4946980072040766F);
        escalar(g0, "carcasa_20", 0.5F, 1.0F, 0.49513340622639673F);
        escalar(g0, "carcasa_21", 0.5F, 1.0F, 0.49515496020089605F);
        escalar(g0, "carcasa_22", 0.5F, 1.0F, 0.49515496020089594F);
        escalar(g0, "carcasa_23", 0.5F, 1.0F, 0.4951549602008987F);
        escalar(g0, "carcasa_24", 0.5F, 1.0F, 0.4951549602008952F);
        escalar(g0, "carcasa_25", 0.5F, 1.0F, 0.4951549602008968F);
        escalar(g0, "carcasa_26", 0.5F, 1.0F, 0.4944189439573119F);
        escalar(g0, "carcasa_27", 0.5F, 1.0F, 0.495154960200896F);
        escalar(g0, "carcasa_28", 0.5F, 1.0F, 0.495154960200896F);
        escalar(g0, "carcasa_29", 0.5F, 1.0F, 0.495154960200896F);
        escalar(g0, "nariz_0", 0.4428474701035695F, 1.0F, 0.428172253176763F);
        escalar(g0, "nariz_1", 0.4730037716541779F, 1.0F, 0.42914860286086276F);
        escalar(g0, "nariz_2", 0.27428443892468574F, 1.0F, 0.4263652273526681F);
        escalar(g0, "nariz_3", 0.37338303994924393F, 1.0F, 0.4159984436674561F);
        escalar(g0, "nariz_4", 0.38817729935838086F, 1.0F, 0.49562060811412245F);
        escalar(g0, "nariz_5", 0.4430284844047916F, 1.0F, 0.46058020805530897F);
        escalar(g0, "nariz_6", 0.46310697834051595F, 1.0F, 0.41768073952904494F);
        escalar(g0, "nariz_7", 0.4638521724148779F, 1.0F, 0.49248092884979533F);
        escalar(g0, "nariz_8", 0.45299011205138573F, 1.0F, 0.4228283184244816F);
        escalar(g0, "nariz_9", 0.43235365444308027F, 1.0F, 0.3499142603627626F);
        escalar(g0, "nariz_10", 0.4264882023077197F, 1.0F, 0.41868509071406795F);
        escalar(g0, "nariz_11", 0.43542162258768513F, 1.0F, 0.3170500425260677F);
        escalar(g0, "nariz_12", 0.4514559102217227F, 1.0F, 0.4341422723808831F);
        escalar(g0, "nariz_13", 0.47096663243075765F, 1.0F, 0.24942785930817102F);
        escalar(g0, "nariz_14", 0.44528621455067785F, 1.0F, 0.4964473104521666F);
        escalar(g0, "nariz_15", 0.47319425907491347F, 1.0F, 0.49664308429293386F);
        escalar(g0, "nariz_16", 0.27653992673270905F, 1.0F, 0.49147967279212396F);
        escalar(g0, "nariz_17", 0.3771720875042903F, 1.0F, 0.4803851186171054F);
        escalar(g0, "nariz_18", 0.393022856797218F, 1.0F, 0.45925344349065134F);
        escalar(g0, "nariz_19", 0.4495975479411961F, 1.0F, 0.4287133964410826F);
        escalar(g0, "nariz_20", 0.4709079541635557F, 1.0F, 0.48920637912885634F);
        escalar(g0, "nariz_21", 0.4726404125445416F, 1.0F, 0.43685120054782367F);
        escalar(g0, "nariz_22", 0.4625937010938671F, 1.0F, 0.38052475058962903F);
        escalar(g0, "nariz_23", 0.4425346347769695F, 1.0F, 0.4286294367746539F);
        escalar(g0, "nariz_24", 0.43405649300342963F, 1.0F, 0.3501386616081324F);
        escalar(g0, "nariz_25", 0.44119272279622745F, 1.0F, 0.40866090982448605F);
        escalar(g0, "nariz_26", 0.45436831881643686F, 1.0F, 0.29128143419447194F);
        escalar(g0, "nariz_27", 0.4699942858784979F, 1.0F, 0.3570337063904628F);
        escalar(g0, "nariz_28", 0.44965561288436356F, 1.0F, 0.4304564376745354F);
        escalar(g0, "nariz_29", 0.477400267450739F, 1.0F, 0.49292178250384905F);
        escalar(g0, "nariz_30", 0.2772792144565416F, 1.0F, 0.4966946440780918F);
        escalar(g0, "nariz_31", 0.38411759986933874F, 1.0F, 0.498776907492959F);
        escalar(g0, "nariz_32", 0.40205009721508145F, 1.0F, 0.47743688263234585F);
        escalar(g0, "nariz_33", 0.4619735118488102F, 1.0F, 0.44650135248529177F);
        escalar(g0, "nariz_34", 0.48570018817154836F, 1.0F, 0.4086691661744258F);
        escalar(g0, "nariz_35", 0.48939328084945166F, 1.0F, 0.4579142685766041F);
        escalar(g0, "nariz_36", 0.48099579978511303F, 1.0F, 0.4011825733406573F);
        escalar(g0, "nariz_37", 0.4624214576007355F, 1.0F, 0.4555980855672359F);
        escalar(g0, "nariz_38", 0.44998322367511434F, 1.0F, 0.37550586979600425F);
        escalar(g0, "nariz_39", 0.45442144837279264F, 1.0F, 0.44298763393534063F);
        escalar(g0, "nariz_40", 0.4628516045499713F, 1.0F, 0.32161394108371266F);
        escalar(g0, "nariz_41", 0.47139799099572477F, 1.0F, 0.40838204617055973F);
        escalar(g0, "nariz_42", 0.4580445201718008F, 1.0F, 0.20211773473948164F);
        escalar(g0, "nariz_43", 0.4558834059069588F, 1.0F, 0.43866568930383365F);
        escalar(g0, "nariz_44", 0.4839275325271804F, 1.0F, 0.4384011740637998F);
        escalar(g0, "nariz_45", 0.27269826055796026F, 1.0F, 0.42227931763602794F);
        escalar(g0, "nariz_46", 0.3936673715870465F, 1.0F, 0.4227889855948801F);
        escalar(g0, "nariz_47", 0.4145760988952514F, 1.0F, 0.48609670080684103F);
        escalar(g0, "nariz_48", 0.4792442482539112F, 1.0F, 0.45517617017710404F);
        escalar(g0, "nariz_49", 0.40511924579905473F, 1.0F, 0.41732100637886305F);
        escalar(g0, "nariz_50", 0.4102909697572061F, 1.0F, 0.46873390092624756F);
        escalar(g0, "nariz_51", 0.40542435751914335F, 1.0F, 0.4121286770322862F);
        escalar(g0, "nariz_52", 0.49062261278191566F, 1.0F, 0.47046058451029F);
        escalar(g0, "nariz_53", 0.47386556649657785F, 1.0F, 0.38984131987753007F);
        escalar(g0, "nariz_54", 0.4751651111351497F, 1.0F, 0.46267245746655405F);
        escalar(g0, "nariz_55", 0.4776982661271391F, 1.0F, 0.33968425301739624F);
        escalar(g0, "nariz_56", 0.4769114944598939F, 1.0F, 0.44117275795122735F);
        escalar(g0, "nariz_57", 0.45153150902035677F, 1.0F, 0.2301232354749809F);
        escalar(g0, "nariz_58", 0.4640707894237286F, 1.0F, 0.4413750754328558F);
        escalar(g0, "nariz_59", 0.48940010783433197F, 1.0F, 0.4425747540407124F);
        escalar(g0, "nariz_60", 0.2759294838722577F, 1.0F, 0.49788953918616674F);
        escalar(g0, "nariz_61", 0.39151760012012726F, 1.0F, 0.4848447804262211F);
        escalar(g0, "nariz_62", 0.42991780436549154F, 1.0F, 0.4894144254331948F);
        escalar(g0, "nariz_63", 0.4003683772242594F, 1.0F, 0.458742275329805F);
        escalar(g0, "nariz_64", 0.4254841280267422F, 1.0F, 0.42112095625496176F);
        escalar(g0, "nariz_65", 0.4333732747971258F, 1.0F, 0.4738041215472548F);
        escalar(g0, "nariz_66", 0.4307411323840319F, 1.0F, 0.41760821529752257F);
        escalar(g0, "nariz_67", 0.4203255705944291F, 1.0F, 0.47856542811704594F);
        escalar(g0, "nariz_68", 0.40377692752485206F, 1.0F, 0.3980945866770956F);
        escalar(g0, "nariz_69", 0.40210171095051306F, 1.0F, 0.47428017612887086F);
        escalar(g0, "nariz_70", 0.498573937155431F, 1.0F, 0.35087317073218716F);
        escalar(g0, "nariz_71", 0.486941708516025F, 1.0F, 0.4627006543002623F);
        escalar(g0, "nariz_72", 0.4466676357436924F, 1.0F, 0.24937458680823937F);
        escalar(g0, "nariz_73", 0.4743304226533601F, 1.0F, 0.4343148861594497F);
        escalar(g0, "nariz_74", 0.4949606601535023F, 1.0F, 0.4363678996637632F);
        escalar(g0, "nariz_75", 0.2878920930468023F, 1.0F, 0.44013856572230764F);
        escalar(g0, "nariz_76", 0.3851137239266505F, 1.0F, 0.4277486388098522F);
        escalar(g0, "nariz_77", 0.4473939610241771F, 1.0F, 0.48864277494332004F);
        escalar(g0, "nariz_78", 0.4197371261265392F, 1.0F, 0.45841436525515283F);
        escalar(g0, "nariz_79", 0.44874485892708404F, 1.0F, 0.42124937989936395F);
        escalar(g0, "nariz_80", 0.45971945155351757F, 1.0F, 0.4745492335634689F);
        escalar(g0, "nariz_81", 0.4595810797029962F, 1.0F, 0.4189962672597371F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1) {
        escalar(g0, "nariz_82", 0.4519866770657626F, 1.0F, 0.4816623017043291F);
        escalar(g0, "nariz_83", 0.4330586216441418F, 1.0F, 0.4019466645113601F);
        escalar(g0, "nariz_84", 0.42851506703527137F, 1.0F, 0.48022047506810245F);
        escalar(g0, "nariz_85", 0.4197119396051828F, 1.0F, 0.357325338576847F);
        escalar(g0, "nariz_86", 0.4010207206664484F, 1.0F, 0.4764051154518487F);
        escalar(g0, "nariz_87", 0.4439740304213654F, 1.0F, 0.2620263434573644F);
        escalar(g0, "nariz_88", 0.4853009425019735F, 1.0F, 0.43621805329355096F);
        escalar(g0, "nariz_89", 0.43083318395409337F, 1.0F, 0.43855759097369634F);
        escalar(g0, "nariz_90", 0.29851389125868744F, 1.0F, 0.4384522668164827F);
        escalar(g0, "nariz_91", 0.391583009922289F, 1.0F, 0.4249176032717883F);
        escalar(g0, "nariz_92", 0.46633145445652546F, 1.0F, 0.4840607620560034F);
        escalar(g0, "nariz_93", 0.4407647140785397F, 1.0F, 0.4544728745720086F);
        escalar(g0, "nariz_94", 0.47403450066026204F, 1.0F, 0.4179824151495678F);
        escalar(g0, "nariz_95", 0.48835213796531746F, 1.0F, 0.4713373545806073F);
        escalar(g0, "nariz_96", 0.4908689015225093F, 1.0F, 0.416717022454527F);
        escalar(g0, "nariz_97", 0.4861161002919293F, 1.0F, 0.4803670781565865F);
        escalar(g0, "nariz_98", 0.46587202055996607F, 1.0F, 0.40205259596107884F);
        escalar(g0, "nariz_99", 0.4583053135487477F, 1.0F, 0.481551083153683F);
        escalar(g0, "nariz_100", 0.4438293605513161F, 1.0F, 0.36011745115508326F);
        escalar(g0, "nariz_101", 0.4154788511111109F, 1.0F, 0.48434450335371537F);
        escalar(g0, "nariz_102", 0.443685241349416F, 1.0F, 0.27004314253694844F);
        escalar(g0, "nariz_103", 0.49619138939521323F, 1.0F, 0.43001709575615027F);
        escalar(g0, "nariz_104", 0.4403770546088596F, 1.0F, 0.4321063112269002F);
        escalar(g0, "nariz_105", 0.3100025283440285F, 1.0F, 0.43231206732885274F);
        escalar(g0, "nariz_106", 0.42139760582303976F, 1.0F, 0.4852057740993597F);
        escalar(g0, "nariz_107", 0.47415906973220423F, 1.0F, 0.45874858129563895F);
        escalar(g0, "nariz_108", 0.4627322522724109F, 1.0F, 0.44652708119908996F);
        escalar(g0, "nariz_109", 0.41709691310094144F, 1.0F, 0.4109942564378001F);
        escalar(g0, "nariz_110", 0.43194759403984445F, 1.0F, 0.4638647142910449F);
        escalar(g0, "nariz_111", 0.43632229792853305F, 1.0F, 0.41059291985419133F);
        escalar(g0, "nariz_112", 0.43376824956402577F, 1.0F, 0.47679443117809317F);
        escalar(g0, "nariz_113", 0.4183441383580962F, 1.0F, 0.4006816951710463F);
        escalar(g0, "nariz_114", 0.4903322645876235F, 1.0F, 0.4786451481727434F);
        escalar(g0, "nariz_115", 0.47020499039072483F, 1.0F, 0.3597974242412225F);
        escalar(g0, "nariz_116", 0.4322944172007964F, 1.0F, 0.4877729502738086F);
        escalar(g0, "nariz_117", 0.44587437521649714F, 1.0F, 0.2748030792123416F);
        escalar(g0, "nariz_118", 0.45108106024012784F, 1.0F, 0.4190218062272138F);
        escalar(g0, "nariz_119", 0.4514934828793193F, 1.0F, 0.4202710437154069F);
        escalar(g0, "nariz_120", 0.3218121153719198F, 1.0F, 0.4203811119634489F);
        escalar(g0, "nariz_121", 0.45607320585935973F, 1.0F, 0.4945346044998994F);
        escalar(g0, "nariz_122", 0.48352758233945037F, 1.0F, 0.46819116420136464F);
        escalar(g0, "nariz_123", 0.4848929286725602F, 1.0F, 0.43339692558827353F);
        escalar(g0, "nariz_124", 0.43943485356277484F, 1.0F, 0.4990434692961614F);
        escalar(g0, "nariz_125", 0.45725441957105967F, 1.0F, 0.4510317779471172F);
        escalar(g0, "nariz_126", 0.4639018250658742F, 1.0F, 0.39978222767254723F);
        escalar(g0, "nariz_127", 0.4623816649734655F, 1.0F, 0.46279712970653525F);
        escalar(g0, "nariz_128", 0.4494369132519267F, 1.0F, 0.3900212173221352F);
        escalar(g0, "nariz_129", 0.4361424612131328F, 1.0F, 0.47130269936846525F);
        escalar(g0, "nariz_130", 0.49775047516840915F, 1.0F, 0.3565004294997133F);
        escalar(g0, "nariz_131", 0.4507083273961686F, 1.0F, 0.4873437243505873F);
        escalar(g0, "nariz_132", 0.4504440493032845F, 1.0F, 0.2771320377918228F);
        escalar(g0, "nariz_133", 0.461112719864895F, 1.0F, 0.48091954026878103F);
        escalar(g0, "nariz_134", 0.46368918387586155F, 1.0F, 0.4805152313568746F);
        escalar(g0, "nariz_135", 0.333138416439397F, 1.0F, 0.4799675901018562F);
        escalar(g0, "nariz_136", 0.47610857900824727F, 1.0F, 0.4712894776518974F);
        escalar(g0, "nariz_137", 0.40639360172153954F, 1.0F, 0.4461449007162825F);
        escalar(g0, "nariz_138", 0.4220027619716767F, 1.0F, 0.4127500184251243F);
        escalar(g0, "nariz_139", 0.46119854638140745F, 1.0F, 0.4757604908844436F);
        escalar(g0, "nariz_140", 0.4819243134135571F, 1.0F, 0.4306295347229912F);
        escalar(g0, "nariz_141", 0.4907538247629182F, 1.0F, 0.3825568348110915F);
        escalar(g0, "nariz_142", 0.4907304494627794F, 1.0F, 0.44438005569897854F);
        escalar(g0, "nariz_143", 0.4792888493438749F, 1.0F, 0.3766945948685261F);
        escalar(g0, "nariz_144", 0.46337037038201395F, 1.0F, 0.4587744907738986F);
        escalar(g0, "nariz_145", 0.4377387651226165F, 1.0F, 0.35000553747329455F);
        escalar(g0, "nariz_146", 0.4698625579913621F, 1.0F, 0.48318235713915825F);
        escalar(g0, "nariz_147", 0.45711024144566215F, 1.0F, 0.2774408469025875F);
        escalar(g0, "nariz_148", 0.4706853826510604F, 1.0F, 0.4453090914756162F);
        escalar(g0, "nariz_149", 0.4761783976579289F, 1.0F, 0.4417500288370647F);
        escalar(g0, "nariz_150", 0.342892934943803F, 1.0F, 0.4397624604539424F);
        escalar(g0, "nariz_151", 0.49449620834659863F, 1.0F, 0.43298209623343464F);
        escalar(g0, "nariz_152", 0.427602431033974F, 1.0F, 0.4108049174173279F);
        escalar(g0, "nariz_153", 0.4385154468829218F, 1.0F, 0.4757714533005354F);
        escalar(g0, "nariz_154", 0.48128449920849264F, 1.0F, 0.43946143420248784F);
        escalar(g0, "nariz_155", 0.43258278881079754F, 1.0F, 0.3989333012065519F);
        escalar(g0, "nariz_156", 0.44184332262230736F, 1.0F, 0.4746749226584002F);
        escalar(g0, "nariz_157", 0.4429596913022494F, 1.0F, 0.41629572052084923F);
        escalar(g0, "nariz_158", 0.43446771975585274F, 1.0F, 0.3564759610253772F);
        escalar(g0, "nariz_159", 0.48893764523174665F, 1.0F, 0.4396497767917946F);
        escalar(g0, "nariz_160", 0.4595895782586515F, 1.0F, 0.3396811755581306F);
        escalar(g0, "nariz_161", 0.488803480248211F, 1.0F, 0.4749037691765272F);
        escalar(g0, "nariz_162", 0.4653969852498798F, 1.0F, 0.27578879185599847F);
        escalar(g0, "nariz_163", 0.4791249539609122F, 1.0F, 0.486175836122685F);
        escalar(g0, "nariz_164", 0.4878557717081581F, 1.0F, 0.4764156333552873F);
        escalar(g0, "nariz_165", 0.35013112441440697F, 1.0F, 0.4708492690488268F);
        escalar(g0, "nariz_166", 0.38210033446019676F, 1.0F, 0.465321798100787F);
        escalar(g0, "nariz_167", 0.4469825880085846F, 1.0F, 0.4446251691138057F);
        escalar(g0, "nariz_168", 0.4525166883492881F, 1.0F, 0.4144707834023773F);
        escalar(g0, "nariz_169", 0.4982148097071941F, 1.0F, 0.38406944633979284F);
        escalar(g0, "nariz_170", 0.44895258630830465F, 1.0F, 0.4678038690587993F);
        escalar(g0, "nariz_171", 0.459600868224161F, 1.0F, 0.4215418093386865F);
        escalar(g0, "nariz_172", 0.4616885051365093F, 1.0F, 0.3747230205563183F);
        escalar(g0, "nariz_173", 0.45449501807867076F, 1.0F, 0.4902742347095442F);
        escalar(g0, "nariz_174", 0.43819406204217703F, 1.0F, 0.41167197022356405F);
        escalar(g0, "nariz_175", 0.4791180940644561F, 1.0F, 0.3242997617285095F);
        escalar(g0, "nariz_176", 0.422053797893516F, 1.0F, 0.4613606641249668F);
        escalar(g0, "nariz_177", 0.4746311300310093F, 1.0F, 0.27183598126526004F);
        escalar(g0, "nariz_178", 0.48559120448701404F, 1.0F, 0.383934888859357F);
        escalar(g0, "nariz_179", 0.49738027097350124F, 1.0F, 0.49359666131581365F);
        escalar(g0, "nariz_180", 0.35503336010349096F, 1.0F, 0.4810318139256289F);
        escalar(g0, "nariz_181", 0.38965906743162815F, 1.0F, 0.4765501389486768F);
        escalar(g0, "nariz_182", 0.46044548077878866F, 1.0F, 0.46229314358114887F);
        escalar(g0, "nariz_183", 0.4628293451940821F, 1.0F, 0.4372130423080601F);
        escalar(g0, "nariz_184", 0.437460973183499F, 1.0F, 0.4076838388783168F);
        escalar(g0, "nariz_185", 0.46055049312730933F, 1.0F, 0.37718697590492994F);
        escalar(g0, "nariz_186", 0.47214675645446297F, 1.0F, 0.3464768061016192F);
        escalar(g0, "nariz_187", 0.47502693305770965F, 1.0F, 0.4740069925865257F);
        escalar(g0, "nariz_188", 0.4691020720024116F, 1.0F, 0.4271731744752983F);
        escalar(g0, "nariz_189", 0.45296598343274663F, 1.0F, 0.371357876336078F);
        escalar(g0, "nariz_190", 0.49496698415179324F, 1.0F, 0.3014927883873529F);
        escalar(g0, "nariz_191", 0.4346945311024915F, 1.0F, 0.43985148300016286F);
        escalar(g0, "nariz_192", 0.483914215467152F, 1.0F, 0.2644666257709621F);
        escalar(g0, "nariz_193", 0.489481800667927F, 1.0F, 0.34636944354323457F);
        escalar(g0, "nariz_194", 0.4406552737257854F, 1.0F, 0.4913792234483971F);
        escalar(g0, "nariz_195", 0.3586536027700129F, 1.0F, 0.4721423051040532F);
        escalar(g0, "nariz_196", 0.3934738090685378F, 1.0F, 0.4664567012120926F);
        escalar(g0, "nariz_197", 0.4663520643078812F, 1.0F, 0.46285857793761986F);
        escalar(g0, "nariz_198", 0.4688159105641713F, 1.0F, 0.4476660114401401F);
        escalar(g0, "nariz_199", 0.44316457984359686F, 1.0F, 0.4216228517319303F);
        escalar(g0, "nariz_200", 0.46669033982252595F, 1.0F, 0.3980364306958504F);
        escalar(g0, "nariz_201", 0.47871362088254205F, 1.0F, 0.37695433565830117F);
        escalar(g0, "nariz_202", 0.4821015942531143F, 1.0F, 0.35815491693674706F);
        escalar(g0, "nariz_203", 0.4772163333659698F, 1.0F, 0.3398867965741892F);
        escalar(g0, "nariz_204", 0.4621677123155114F, 1.0F, 0.3119080976356477F);
        escalar(g0, "nariz_205", 0.4335291686153373F, 1.0F, 0.2653742829239356F);
        escalar(g0, "nariz_206", 0.4440950600256743F, 1.0F, 0.402652398340978F);
        escalar(g0, "nariz_207", 0.49202453201870144F, 1.0F, 0.25011103520998734F);
        escalar(g0, "nariz_208", 0.4910040559101731F, 1.0F, 0.485322859068438F);
        escalar(g0, "nariz_209", 0.4427960245037352F, 1.0F, 0.48552525498065546F);
        escalar(g0, "nariz_210", 0.36081940413651425F, 1.0F, 0.4289555637360659F);
        escalar(g0, "nariz_211", 0.3946841829275153F, 1.0F, 0.4219526010146293F);
        escalar(g0, "nariz_212", 0.4674927091286271F, 1.0F, 0.42799624784380264F);
        escalar(g0, "nariz_213", 0.471087921755071F, 1.0F, 0.4228692245979945F);
        escalar(g0, "nariz_214", 0.44513313365136853F, 1.0F, 0.4028701079232365F);
        escalar(g0, "nariz_215", 0.46866371405902474F, 1.0F, 0.38924222285453713F);
        escalar(g0, "nariz_216", 0.48073611062721555F, 1.0F, 0.38228439284121185F);
        escalar(g0, "nariz_217", 0.4842693854863362F, 1.0F, 0.3826481698773224F);
        escalar(g0, "nariz_218", 0.479856389822821F, 1.0F, 0.39034283192363206F);
        escalar(g0, "nariz_219", 0.4658272218868243F, 1.0F, 0.3892467207171768F);
        escalar(g0, "nariz_220", 0.4378039659075639F, 1.0F, 0.3596346127765891F);
        escalar(g0, "nariz_221", 0.449010725117438F, 1.0F, 0.2960860359601065F);
        escalar(g0, "nariz_222", 0.49100405591017826F, 1.0F, 0.4853228590680357F);
        escalar(g0, "nariz_223", 0.4427960245037236F, 1.0F, 0.4855252549794914F);
        escalar(g0, "nariz_224", 0.3608194041365145F, 1.0F, 0.4289555637361053F);
        escalar(g0, "nariz_225", 0.3946841829275356F, 1.0F, 0.42195260101505205F);
        escalar(g0, "nariz_226", 0.467492709128605F, 1.0F, 0.4279962478441467F);
        escalar(g0, "nariz_227", 0.4710879217550854F, 1.0F, 0.4228692245982435F);
        escalar(g0, "nariz_228", 0.4451331336513776F, 1.0F, 0.4028701079240996F);
        escalar(g0, "nariz_229", 0.4686637140589963F, 1.0F, 0.3892422228548817F);
        escalar(g0, "nariz_230", 0.48073611062722893F, 1.0F, 0.3822843928411125F);
        escalar(g0, "nariz_231", 0.48426938548632165F, 1.0F, 0.3826481698771952F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1) {
        escalar(g0, "nariz_232", 0.47985638982283957F, 1.0F, 0.3903428319236759F);
        escalar(g0, "nariz_233", 0.46582722188682324F, 1.0F, 0.3892467207177651F);
        escalar(g0, "nariz_234", 0.43780396590755366F, 1.0F, 0.35963461277680947F);
        escalar(g0, "nariz_235", 0.4490107251174402F, 1.0F, 0.2960860359599975F);
        escalar(g0, "nariz_236", 0.4894818006679492F, 1.0F, 0.34636944354319016F);
        escalar(g0, "nariz_237", 0.4406552737257491F, 1.0F, 0.49137922344814955F);
        escalar(g0, "nariz_238", 0.35865360277001285F, 1.0F, 0.472142305104172F);
        escalar(g0, "nariz_239", 0.39347380906861107F, 1.0F, 0.4664567012123003F);
        escalar(g0, "nariz_240", 0.46635206430779014F, 1.0F, 0.46285857793773577F);
        escalar(g0, "nariz_241", 0.4688159105642154F, 1.0F, 0.44766601144011675F);
        escalar(g0, "nariz_242", 0.44316457984363955F, 1.0F, 0.4216228517321169F);
        escalar(g0, "nariz_243", 0.46669033982242397F, 1.0F, 0.398036430695978F);
        escalar(g0, "nariz_244", 0.47871362088258324F, 1.0F, 0.37695433565827685F);
        escalar(g0, "nariz_245", 0.48210159425306603F, 1.0F, 0.358154916936683F);
        escalar(g0, "nariz_246", 0.47721633336603336F, 1.0F, 0.33988679657416265F);
        escalar(g0, "nariz_247", 0.4621677123155064F, 1.0F, 0.31190809763573135F);
        escalar(g0, "nariz_248", 0.43352916861530977F, 1.0F, 0.2653742829239806F);
        escalar(g0, "nariz_249", 0.4440950600256787F, 1.0F, 0.4026523983410288F);
        escalar(g0, "nariz_250", 0.4920245320187005F, 1.0F, 0.2501110352101563F);
        escalar(g0, "nariz_251", 0.48559120448705684F, 1.0F, 0.3839348888593759F);
        escalar(g0, "nariz_252", 0.49738027097342785F, 1.0F, 0.4935966613155882F);
        escalar(g0, "nariz_253", 0.3550333601034939F, 1.0F, 0.48103181392564887F);
        escalar(g0, "nariz_254", 0.389659067431734F, 1.0F, 0.4765501389486662F);
        escalar(g0, "nariz_255", 0.4604454807786311F, 1.0F, 0.4622931435810851F);
        escalar(g0, "nariz_256", 0.46282934519417324F, 1.0F, 0.4372130423080774F);
        escalar(g0, "nariz_257", 0.4374609731835802F, 1.0F, 0.4076838388784583F);
        escalar(g0, "nariz_258", 0.46055049312711294F, 1.0F, 0.37718697590496486F);
        escalar(g0, "nariz_259", 0.4721467564545299F, 1.0F, 0.34647680610153014F);
        escalar(g0, "nariz_260", 0.4750269330576481F, 1.0F, 0.47400699258650425F);
        escalar(g0, "nariz_261", 0.4691020720025106F, 1.0F, 0.4271731744753525F);
        escalar(g0, "nariz_262", 0.45296598343273675F, 1.0F, 0.37135787633612094F);
        escalar(g0, "nariz_263", 0.4949669841517499F, 1.0F, 0.30149278838740323F);
        escalar(g0, "nariz_264", 0.43469453110249306F, 1.0F, 0.4398514830002661F);
        escalar(g0, "nariz_265", 0.48391421546714947F, 1.0F, 0.264466625771017F);
        escalar(g0, "nariz_266", 0.4791249539609711F, 1.0F, 0.4861758361226618F);
        escalar(g0, "nariz_267", 0.4878557717080537F, 1.0F, 0.4764156333551457F);
        escalar(g0, "nariz_268", 0.3501311244144112F, 1.0F, 0.47084926904884206F);
        escalar(g0, "nariz_269", 0.3821003344603269F, 1.0F, 0.4653217981008354F);
        escalar(g0, "nariz_270", 0.44698258800838353F, 1.0F, 0.4446251691138482F);
        escalar(g0, "nariz_271", 0.4525166883494238F, 1.0F, 0.414470783402397F);
        escalar(g0, "nariz_272", 0.49821480970732646F, 1.0F, 0.3840694463398743F);
        escalar(g0, "nariz_273", 0.44895258630802054F, 1.0F, 0.46780386905886157F);
        escalar(g0, "nariz_274", 0.45960086822424817F, 1.0F, 0.42154180933866786F);
        escalar(g0, "nariz_275", 0.4616885051364465F, 1.0F, 0.3747230205563052F);
        escalar(g0, "nariz_276", 0.45449501807879117F, 1.0F, 0.4902742347095429F);
        escalar(g0, "nariz_277", 0.4381940620421635F, 1.0F, 0.4116719702235991F);
        escalar(g0, "nariz_278", 0.479118094064404F, 1.0F, 0.3242997617285218F);
        escalar(g0, "nariz_279", 0.42205379789351793F, 1.0F, 0.4613606641249632F);
        escalar(g0, "nariz_280", 0.474631130031006F, 1.0F, 0.27183598126525876F);
        escalar(g0, "nariz_281", 0.47068538265112664F, 1.0F, 0.44530909147571673F);
        escalar(g0, "nariz_282", 0.47617839765779785F, 1.0F, 0.4417500288371164F);
        escalar(g0, "nariz_283", 0.342892934943942F, 1.0F, 0.43976246045404804F);
        escalar(g0, "nariz_284", 0.49449620834668884F, 1.0F, 0.43298209623352263F);
        escalar(g0, "nariz_285", 0.4276024310337528F, 1.0F, 0.410804917417289F);
        escalar(g0, "nariz_286", 0.43851544688308036F, 1.0F, 0.4757714533005106F);
        escalar(g0, "nariz_287", 0.4812844992086414F, 1.0F, 0.4394614342024601F);
        escalar(g0, "nariz_288", 0.43258278881047046F, 1.0F, 0.3989333012065077F);
        escalar(g0, "nariz_289", 0.4418433226224042F, 1.0F, 0.4746749226583413F);
        escalar(g0, "nariz_290", 0.4429596913021837F, 1.0F, 0.41629572052080227F);
        escalar(g0, "nariz_291", 0.43446771975598664F, 1.0F, 0.35647596102533674F);
        escalar(g0, "nariz_292", 0.48893764523174F, 1.0F, 0.43964977679178585F);
        escalar(g0, "nariz_293", 0.4595895782585957F, 1.0F, 0.3396811755582227F);
        escalar(g0, "nariz_294", 0.488803480248208F, 1.0F, 0.4749037691766498F);
        escalar(g0, "nariz_295", 0.4653969852498804F, 1.0F, 0.2757887918559815F);
        escalar(g0, "nariz_296", 0.46111271986494995F, 1.0F, 0.48091954026895084F);
        escalar(g0, "nariz_297", 0.4636891838757036F, 1.0F, 0.480515231356941F);
        escalar(g0, "nariz_298", 0.3331384164398262F, 1.0F, 0.4799675901020404F);
        escalar(g0, "nariz_299", 0.4761085790079426F, 1.0F, 0.471289477651899F);
        escalar(g0, "nariz_300", 0.40639360172137795F, 1.0F, 0.4461449007160736F);
        escalar(g0, "nariz_301", 0.4220027619718901F, 1.0F, 0.4127500184251069F);
        escalar(g0, "nariz_302", 0.4611985463815608F, 1.0F, 0.4757604908845663F);
        escalar(g0, "nariz_303", 0.48192431341310954F, 1.0F, 0.43062953472299276F);
        escalar(g0, "nariz_304", 0.49075382476309953F, 1.0F, 0.3825568348111097F);
        escalar(g0, "nariz_305", 0.4907304494626385F, 1.0F, 0.4443800556989999F);
        escalar(g0, "nariz_306", 0.479288849344075F, 1.0F, 0.37669459486846785F);
        escalar(g0, "nariz_307", 0.4633703703820122F, 1.0F, 0.4587744907739879F);
        escalar(g0, "nariz_308", 0.43773876512255844F, 1.0F, 0.350005537473308F);
        escalar(g0, "nariz_309", 0.4698625579913546F, 1.0F, 0.4831823571392327F);
        escalar(g0, "nariz_310", 0.4571102414456596F, 1.0F, 0.27744084690279314F);
        escalar(g0, "nariz_311", 0.45108106024016753F, 1.0F, 0.41902180622705704F);
        escalar(g0, "nariz_312", 0.4514934828791971F, 1.0F, 0.42027104371563934F);
        escalar(g0, "nariz_313", 0.321812115372309F, 1.0F, 0.42038111196358247F);
        escalar(g0, "nariz_314", 0.4560732058586577F, 1.0F, 0.49453460449975745F);
        escalar(g0, "nariz_315", 0.48352758233941123F, 1.0F, 0.46819116420123147F);
        escalar(g0, "nariz_316", 0.48489292867290723F, 1.0F, 0.43339692558836995F);
        escalar(g0, "nariz_317", 0.43943485356287054F, 1.0F, 0.49904346929620497F);
        escalar(g0, "nariz_318", 0.4572544195705952F, 1.0F, 0.4510317779470898F);
        escalar(g0, "nariz_319", 0.46390182506609207F, 1.0F, 0.3997822276725457F);
        escalar(g0, "nariz_320", 0.4623816649732701F, 1.0F, 0.4627971297064796F);
        escalar(g0, "nariz_321", 0.44943691325215784F, 1.0F, 0.39002121732208384F);
        escalar(g0, "nariz_322", 0.4361424612131171F, 1.0F, 0.4713026993682695F);
        escalar(g0, "nariz_323", 0.4977504751683628F, 1.0F, 0.3565004294996467F);
        escalar(g0, "nariz_324", 0.4507083273961607F, 1.0F, 0.48734372435068807F);
        escalar(g0, "nariz_325", 0.45044404930328186F, 1.0F, 0.2771320377917158F);
        escalar(g0, "nariz_326", 0.49619138939525165F, 1.0F, 0.4300170957561485F);
        escalar(g0, "nariz_327", 0.44037705460878296F, 1.0F, 0.4321063112268937F);
        escalar(g0, "nariz_328", 0.31000252834422665F, 1.0F, 0.4323120673288607F);
        escalar(g0, "nariz_329", 0.4213976058223576F, 1.0F, 0.4852057740993702F);
        escalar(g0, "nariz_330", 0.4741590697322576F, 1.0F, 0.45874858129563867F);
        escalar(g0, "nariz_331", 0.46273225227279174F, 1.0F, 0.4465270811990932F);
        escalar(g0, "nariz_332", 0.41709691310096847F, 1.0F, 0.41099425643781196F);
        escalar(g0, "nariz_333", 0.43194759403942945F, 1.0F, 0.4638647142910498F);
        escalar(g0, "nariz_334", 0.43632229792871574F, 1.0F, 0.41059291985418855F);
        escalar(g0, "nariz_335", 0.4337682495638459F, 1.0F, 0.4767944311780852F);
        escalar(g0, "nariz_336", 0.4183441383583122F, 1.0F, 0.4006816951710399F);
        escalar(g0, "nariz_337", 0.4903322645875968F, 1.0F, 0.47864514817274484F);
        escalar(g0, "nariz_338", 0.47020499039070707F, 1.0F, 0.3597974242412239F);
        escalar(g0, "nariz_339", 0.43229441720078465F, 1.0F, 0.48777295027380985F);
        escalar(g0, "nariz_340", 0.4458743752164988F, 1.0F, 0.2748030792123482F);
        escalar(g0, "nariz_341", 0.4853009425020014F, 1.0F, 0.4362180532935542F);
        escalar(g0, "nariz_342", 0.43083318395401354F, 1.0F, 0.4385575909736674F);
        escalar(g0, "nariz_343", 0.29851389125887573F, 1.0F, 0.43845226681648924F);
        escalar(g0, "nariz_344", 0.3915830099218213F, 1.0F, 0.42491760327178985F);
        escalar(g0, "nariz_345", 0.4663314544565758F, 1.0F, 0.4840607620560017F);
        escalar(g0, "nariz_346", 0.4407647140789063F, 1.0F, 0.45447287457200974F);
        escalar(g0, "nariz_347", 0.4740345006602924F, 1.0F, 0.4179824151495741F);
        escalar(g0, "nariz_348", 0.48835213796483934F, 1.0F, 0.47133735458061105F);
        escalar(g0, "nariz_349", 0.490868901522719F, 1.0F, 0.41671702245452835F);
        escalar(g0, "nariz_350", 0.48611610029171803F, 1.0F, 0.4803670781565856F);
        escalar(g0, "nariz_351", 0.4658720205602135F, 1.0F, 0.40205259596107473F);
        escalar(g0, "nariz_352", 0.4583053135487229F, 1.0F, 0.4815510831536818F);
        escalar(g0, "nariz_353", 0.4438293605513003F, 1.0F, 0.3601174511550841F);
        escalar(g0, "nariz_354", 0.4154788511111002F, 1.0F, 0.4843445033537182F);
        escalar(g0, "nariz_355", 0.44368524134941745F, 1.0F, 0.27004314253695105F);
        escalar(g0, "nariz_356", 0.47433042265337366F, 1.0F, 0.4343148861595501F);
        escalar(g0, "nariz_357", 0.49496066015338025F, 1.0F, 0.4363678996637401F);
        escalar(g0, "nariz_358", 0.2878920930469087F, 1.0F, 0.44013856572204935F);
        escalar(g0, "nariz_359", 0.38511372392636894F, 1.0F, 0.42774863880965586F);
        escalar(g0, "nariz_360", 0.44739396102434004F, 1.0F, 0.4886427749434558F);
        escalar(g0, "nariz_361", 0.4197371261267408F, 1.0F, 0.45841436525521473F);
        escalar(g0, "nariz_362", 0.44874485892709737F, 1.0F, 0.4212493798990865F);
        escalar(g0, "nariz_363", 0.45971945155324684F, 1.0F, 0.47454923356352285F);
        escalar(g0, "nariz_364", 0.45958107970310913F, 1.0F, 0.41899626726003214F);
        escalar(g0, "nariz_365", 0.4519866770655797F, 1.0F, 0.4816623017045127F);
        escalar(g0, "nariz_366", 0.4330586216442506F, 1.0F, 0.40194666451115774F);
        escalar(g0, "nariz_367", 0.4285150670353236F, 1.0F, 0.4802204750676221F);
        escalar(g0, "nariz_368", 0.41971193960516473F, 1.0F, 0.3573253385768129F);
        escalar(g0, "nariz_369", 0.4010207206664414F, 1.0F, 0.47640511545173303F);
        escalar(g0, "nariz_370", 0.44397403042137457F, 1.0F, 0.26202634345729975F);
        escalar(g0, "nariz_371", 0.4640707894237425F, 1.0F, 0.44137507543288734F);
        escalar(g0, "nariz_372", 0.4894001078341925F, 1.0F, 0.44257475404084784F);
        escalar(g0, "nariz_373", 0.27592948387219446F, 1.0F, 0.49788953918609347F);
        escalar(g0, "nariz_374", 0.3915176001199261F, 1.0F, 0.4848447804264211F);
        escalar(g0, "nariz_375", 0.42991780436564386F, 1.0F, 0.4894144254332614F);
        escalar(g0, "nariz_376", 0.40036837722429686F, 1.0F, 0.4587422753296081F);
        escalar(g0, "nariz_377", 0.42548412802676394F, 1.0F, 0.42112095625480067F);
        escalar(g0, "nariz_378", 0.43337327479711096F, 1.0F, 0.4738041215472974F);
        escalar(g0, "nariz_379", 0.43074113238401673F, 1.0F, 0.4176082152976394F);
        escalar(g0, "nariz_380", 0.4203255705943043F, 1.0F, 0.47856542811715724F);
        escalar(g0, "nariz_381", 0.4037769275248043F, 1.0F, 0.3980945866771837F);
    }

    private static void escalas3(ModelPart g0, ModelPart g1) {
        escalar(g0, "nariz_382", 0.40210171095061636F, 1.0F, 0.47428017612870754F);
        escalar(g0, "nariz_383", 0.4985739371554244F, 1.0F, 0.35087317073207736F);
        escalar(g0, "nariz_384", 0.4869417085160216F, 1.0F, 0.4627006543003025F);
        escalar(g0, "nariz_385", 0.44666763574370383F, 1.0F, 0.2493745868082236F);
        escalar(g0, "nariz_386", 0.4558834059069774F, 1.0F, 0.43866568930383587F);
        escalar(g0, "nariz_387", 0.4839275325270623F, 1.0F, 0.43840117406380524F);
        escalar(g0, "nariz_388", 0.2726982605578697F, 1.0F, 0.4222793176360324F);
        escalar(g0, "nariz_389", 0.3936673715868393F, 1.0F, 0.42278898559488187F);
        escalar(g0, "nariz_390", 0.41457609889527414F, 1.0F, 0.48609670080684264F);
        escalar(g0, "nariz_391", 0.47924424825394135F, 1.0F, 0.4551761701771021F);
        escalar(g0, "nariz_392", 0.4051192457990963F, 1.0F, 0.4173210063788598F);
        escalar(g0, "nariz_393", 0.41029096975724977F, 1.0F, 0.4687339009262438F);
        escalar(g0, "nariz_394", 0.4054243575190961F, 1.0F, 0.41212867703228206F);
        escalar(g0, "nariz_395", 0.49062261278181407F, 1.0F, 0.470460584510289F);
        escalar(g0, "nariz_396", 0.4738655664964969F, 1.0F, 0.3898413198775379F);
        escalar(g0, "nariz_397", 0.47516511113523413F, 1.0F, 0.4626724574665618F);
        escalar(g0, "nariz_398", 0.4776982661271487F, 1.0F, 0.3396842530173893F);
        escalar(g0, "nariz_399", 0.4769114944598922F, 1.0F, 0.4411727579512122F);
        escalar(g0, "nariz_400", 0.45153150902036554F, 1.0F, 0.23012323547497782F);
        escalar(g0, "nariz_401", 0.44965561288438405F, 1.0F, 0.4304564376746372F);
        escalar(g0, "nariz_402", 0.4774002674506585F, 1.0F, 0.492921782504031F);
        escalar(g0, "nariz_403", 0.2772792144565852F, 1.0F, 0.49669464407803365F);
        escalar(g0, "nariz_404", 0.38411759986918365F, 1.0F, 0.49877690749286446F);
        escalar(g0, "nariz_405", 0.4020500972151173F, 1.0F, 0.4774368826323343F);
        escalar(g0, "nariz_406", 0.4619735118488125F, 1.0F, 0.4465013524852859F);
        escalar(g0, "nariz_407", 0.48570018817159755F, 1.0F, 0.4086691661743826F);
        escalar(g0, "nariz_408", 0.4893932808494843F, 1.0F, 0.4579142685765524F);
        escalar(g0, "nariz_409", 0.4809957997850768F, 1.0F, 0.40118257334060325F);
        escalar(g0, "nariz_410", 0.4624214576006621F, 1.0F, 0.4555980855672283F);
        escalar(g0, "nariz_411", 0.4499832236750617F, 1.0F, 0.3755058697960472F);
        escalar(g0, "nariz_412", 0.4544214483728437F, 1.0F, 0.4429876339353763F);
        escalar(g0, "nariz_413", 0.46285160454997465F, 1.0F, 0.3216139410836785F);
        escalar(g0, "nariz_414", 0.4713979909957234F, 1.0F, 0.4083820461706947F);
        escalar(g0, "nariz_415", 0.45804452017181513F, 1.0F, 0.2021177347396484F);
        escalar(g0, "nariz_416", 0.44528621455068457F, 1.0F, 0.49644731045195006F);
        escalar(g0, "nariz_417", 0.47319425907488916F, 1.0F, 0.4966430842927947F);
        escalar(g0, "nariz_418", 0.2765399267327522F, 1.0F, 0.49147967279198923F);
        escalar(g0, "nariz_419", 0.37717208750422415F, 1.0F, 0.4803851186169908F);
        escalar(g0, "nariz_420", 0.393022856797248F, 1.0F, 0.45925344349065417F);
        escalar(g0, "nariz_421", 0.4495975479411809F, 1.0F, 0.42871339644101125F);
        escalar(g0, "nariz_422", 0.47090795416359077F, 1.0F, 0.4892063791287333F);
        escalar(g0, "nariz_423", 0.47264041254454714F, 1.0F, 0.43685120054760646F);
        escalar(g0, "nariz_424", 0.46259370109386394F, 1.0F, 0.3805247505894373F);
        escalar(g0, "nariz_425", 0.44253463477693405F, 1.0F, 0.42862943677459436F);
        escalar(g0, "nariz_426", 0.4340564930034105F, 1.0F, 0.35013866160825646F);
        escalar(g0, "nariz_427", 0.44119272279624494F, 1.0F, 0.4086609098246645F);
        escalar(g0, "nariz_428", 0.45436831881643747F, 1.0F, 0.29128143419439395F);
        escalar(g0, "nariz_429", 0.4699942858784967F, 1.0F, 0.3570337063900884F);
        escalar(g0, "nariz_430", 0.44284747010356473F, 1.0F, 0.428172253176723F);
        escalar(g0, "nariz_431", 0.47300377165417906F, 1.0F, 0.42914860286090495F);
        escalar(g0, "nariz_432", 0.27428443892467624F, 1.0F, 0.4263652273526917F);
        escalar(g0, "nariz_433", 0.3733830399492411F, 1.0F, 0.4159984436675382F);
        escalar(g0, "nariz_434", 0.3881772993583846F, 1.0F, 0.495620608114218F);
        escalar(g0, "nariz_435", 0.44302848440478726F, 1.0F, 0.46058020805541355F);
        escalar(g0, "nariz_436", 0.4631069783405246F, 1.0F, 0.4176807395291155F);
        escalar(g0, "nariz_437", 0.4638521724148758F, 1.0F, 0.4924809288498144F);
        escalar(g0, "nariz_438", 0.4529901120513919F, 1.0F, 0.4228283184244612F);
        escalar(g0, "nariz_439", 0.43235365444307383F, 1.0F, 0.3499142603627387F);
        escalar(g0, "nariz_440", 0.42648820230771833F, 1.0F, 0.4186850907141705F);
        escalar(g0, "nariz_441", 0.4354216225876869F, 1.0F, 0.3170500425261487F);
        escalar(g0, "nariz_442", 0.4514559102217224F, 1.0F, 0.434142272380894F);
        escalar(g0, "nariz_443", 0.47096663243075754F, 1.0F, 0.24942785930816008F);
        escalar(g0, "chimenea_0", 0.4315455233774214F, 1.0F, 0.4315455233774214F);
        escalar(g0, "chimenea_1", 0.4315455233774214F, 1.0F, 0.4315455233774214F);
        escalar(g0, "chimenea_2", 0.4315455233774214F, 1.0F, 0.4315455233774214F);
        escalar(g0, "chimenea_3", 0.4315455233774214F, 1.0F, 0.4315455233774214F);
        escalar(g0, "silbato_0", 0.1077859454596501F, 1.0F, 0.1077859454596501F);
        escalar(g0, "silbato_1", 0.1077859454596501F, 1.0F, 0.1077859454596501F);
        escalar(g0, "cabina_cuna_0", 0.49231578734119075F, 1.0F, 0.5F);
        escalar(g0, "cabina_cuna_1", 0.49231578734119075F, 1.0F, 0.5F);
        escalar(g0, "cabina_techo_0", 1.0008695652173913F, 1.0F, 0.7308905619357534F);
        escalar(g0, "cabina_techo_1", 1.0008695652173913F, 1.0F, 0.7308905619357519F);
        escalar(g0, "cabina_techo_2", 1.0008695652173913F, 1.0F, 0.7308905619357532F);
        escalar(g0, "cabina_techo_3", 1.0008695652173913F, 1.0F, 0.7308905619357526F);
        escalar(g0, "cabina_techo_4", 1.0008695652173913F, 1.0F, 0.7308905619357526F);
        escalar(g0, "cabina_techo_5", 1.0008695652173913F, 1.0F, 0.7308905619357532F);
        escalar(g0, "cabina_techo_6", 1.0008695652173913F, 1.0F, 0.7308905619357522F);
        escalar(g0, "cabina_techo_7", 1.0008695652173913F, 1.0F, 0.7308905619357531F);
        escalar(g0, "cabina_techo_8", 1.0008695652173913F, 1.0F, 0.7308905619357532F);
        escalar(g0, "cabina_techo_9", 1.0008695652173913F, 1.0F, 0.7308905619357526F);
        escalar(g0, "cabina_techo_10", 1.0008695652173913F, 1.0F, 0.7308905619357525F);
        escalar(g0, "cabina_techo_11", 1.0008695652173913F, 1.0F, 0.7308905619357534F);
        escalar(g1, "tender_caja_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_cantoi_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g1, "tender_caja_cantoi_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g1, "tender_caja_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g1, "tender_caja_cantoi_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_cantod_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g1, "tender_caja_cantod_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g1, "tender_caja_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g1, "tender_caja_cantod_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tender_caja_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tope_ti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_ti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_ti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_tic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_td_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_td_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_td_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_tdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
    }
}
