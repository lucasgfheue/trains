package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "EMD SD40-2" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloSD40 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("sd40"), "main"),
            LocomotoraMod.id("textures/entity/sd40.png"),
            List.of(
                new DatosModelo.Animada("bogiefi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -79.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -79.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -79.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -60.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -60.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -60.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefi2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -79.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -79.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -79.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -60.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -60.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -60.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 62.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 62.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 62.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 81.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 81.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 81.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 62.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 62.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 62.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 81.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 81.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 81.0F, -4.5F, 1.0471975511965976F, "cuerpo")),
            ModeloSD40::crearCapa,
            16.0F,
            ModeloSD40::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -60.0F, 62.0F)));

    private ModeloSD40() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogiefi0_0", CubeListBuilder.create().texOffs(432, 134).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(536, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(230, 146).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-79.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi0_1", CubeListBuilder.create().texOffs(558, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-79.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi0_2", CubeListBuilder.create().texOffs(580, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-79.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefi1_0", CubeListBuilder.create().texOffs(432, 134).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(536, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(240, 146).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-60.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi1_1", CubeListBuilder.create().texOffs(558, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi1_2", CubeListBuilder.create().texOffs(580, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefi2_0", CubeListBuilder.create().texOffs(432, 134).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(536, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(250, 146).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-41.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi2_1", CubeListBuilder.create().texOffs(558, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi2_2", CubeListBuilder.create().texOffs(580, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd0_0", CubeListBuilder.create().texOffs(432, 134).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(536, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(260, 146).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-79.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd0_1", CubeListBuilder.create().texOffs(558, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-79.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd0_2", CubeListBuilder.create().texOffs(580, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-79.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd1_0", CubeListBuilder.create().texOffs(432, 134).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(536, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(270, 146).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-60.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd1_1", CubeListBuilder.create().texOffs(558, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd1_2", CubeListBuilder.create().texOffs(580, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd2_0", CubeListBuilder.create().texOffs(432, 134).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(536, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(280, 146).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-41.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd2_1", CubeListBuilder.create().texOffs(558, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd2_2", CubeListBuilder.create().texOffs(580, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogief", CubeListBuilder.create().texOffs(674, 134).addBox(-85.0F, -9.0F, 7.0F, 50.0F, 6.0F, 1.0F).texOffs(776, 134).addBox(-85.0F, -9.0F, -8.0F, 50.0F, 6.0F, 1.0F).texOffs(290, 146).addBox(-81.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(300, 146).addBox(-81.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(310, 146).addBox(-62.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(320, 146).addBox(-62.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(330, 146).addBox(-43.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(340, 146).addBox(-43.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(150, 146).addBox(-71.5F, -9.0F, 8.0F, 4.0F, 5.0F, 1.0F).texOffs(160, 146).addBox(-71.5F, -9.0F, -9.0F, 4.0F, 5.0F, 1.0F).texOffs(170, 146).addBox(-52.5F, -9.0F, 8.0F, 4.0F, 5.0F, 1.0F).texOffs(180, 146).addBox(-52.5F, -9.0F, -9.0F, 4.0F, 5.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogieti0_0", CubeListBuilder.create().texOffs(432, 134).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(536, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(350, 146).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(43.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti0_1", CubeListBuilder.create().texOffs(558, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti0_2", CubeListBuilder.create().texOffs(580, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogieti1_0", CubeListBuilder.create().texOffs(432, 134).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(536, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(360, 146).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(62.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti1_1", CubeListBuilder.create().texOffs(558, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(62.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti1_2", CubeListBuilder.create().texOffs(580, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(62.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogieti2_0", CubeListBuilder.create().texOffs(432, 134).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(536, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 146).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(81.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti2_1", CubeListBuilder.create().texOffs(558, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(81.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti2_2", CubeListBuilder.create().texOffs(580, 153).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 134).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(81.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd0_0", CubeListBuilder.create().texOffs(432, 134).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(536, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(380, 146).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(43.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd0_1", CubeListBuilder.create().texOffs(558, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd0_2", CubeListBuilder.create().texOffs(580, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd1_0", CubeListBuilder.create().texOffs(432, 134).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(536, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(390, 146).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(62.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd1_1", CubeListBuilder.create().texOffs(558, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(62.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd1_2", CubeListBuilder.create().texOffs(580, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(62.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd2_0", CubeListBuilder.create().texOffs(432, 134).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(536, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 146).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(81.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd2_1", CubeListBuilder.create().texOffs(558, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(81.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd2_2", CubeListBuilder.create().texOffs(580, 153).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 134).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(81.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiet", CubeListBuilder.create().texOffs(878, 134).addBox(37.0F, -9.0F, 7.0F, 50.0F, 6.0F, 1.0F).texOffs(0, 146).addBox(37.0F, -9.0F, -8.0F, 50.0F, 6.0F, 1.0F).texOffs(410, 146).addBox(41.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(420, 146).addBox(41.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(430, 146).addBox(60.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(440, 146).addBox(60.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(450, 146).addBox(79.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(460, 146).addBox(79.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(190, 146).addBox(50.5F, -9.0F, 8.0F, 4.0F, 5.0F, 1.0F).texOffs(200, 146).addBox(50.5F, -9.0F, -9.0F, 4.0F, 5.0F, 1.0F).texOffs(210, 146).addBox(69.5F, -9.0F, 8.0F, 4.0F, 5.0F, 1.0F).texOffs(220, 146).addBox(69.5F, -9.0F, -9.0F, 4.0F, 5.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tanque", CubeListBuilder.create().texOffs(814, 72).addBox(-36.0F, -10.0F, -11.0F, 74.0F, 7.0F, 22.0F).texOffs(308, 114).addBox(-36.0F, -12.0F, -9.0F, 74.0F, 2.0F, 18.0F).texOffs(798, 163).addBox(-36.0F, -7.0F, 11.0F, 74.0F, 1.0F, 1.0F).texOffs(0, 165).addBox(-36.0F, -7.0F, -12.0F, 74.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tanque_cantoi_0", CubeListBuilder.create().texOffs(150, 165).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -10.309016994374947F, -10.951056516295154F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_1", CubeListBuilder.create().texOffs(300, 165).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -10.89680224666742F, -10.7600735106701F, -2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_2", CubeListBuilder.create().texOffs(450, 165).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.39680224666742F, -10.39680224666742F, -2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_3", CubeListBuilder.create().texOffs(600, 165).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.7600735106701F, -9.89680224666742F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_4", CubeListBuilder.create().texOffs(750, 165).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.951056516295154F, -9.309016994374947F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_0", CubeListBuilder.create().texOffs(0, 167).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -10.309016994374947F, 10.951056516295154F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_1", CubeListBuilder.create().texOffs(150, 167).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -10.89680224666742F, 10.7600735106701F, 2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_2", CubeListBuilder.create().texOffs(300, 167).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.39680224666742F, 10.39680224666742F, 2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_3", CubeListBuilder.create().texOffs(450, 167).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.7600735106701F, 9.89680224666742F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_4", CubeListBuilder.create().texOffs(600, 167).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.951056516295154F, 9.309016994374947F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_tapaa", CubeListBuilder.create().texOffs(332, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 44.0F), PartPose.offset(-36.0F, -10.0F, -11.0F));
        g.addOrReplaceChild("tanque_tapab", CubeListBuilder.create().texOffs(422, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 44.0F), PartPose.offset(37.0F, -10.0F, -11.0F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(316, 72).addBox(-92.0F, -15.0F, -14.5F, 184.0F, 4.0F, 29.0F), PartPose.ZERO);
        g.addOrReplaceChild("barandas", CubeListBuilder.create().texOffs(68, 169).addBox(-86.0F, -26.0F, 13.0F, 12.0F, 1.0F, 1.0F).texOffs(94, 169).addBox(-86.0F, -26.0F, -14.0F, 12.0F, 1.0F, 1.0F).texOffs(274, 163).addBox(-42.0F, -26.0F, 13.0F, 130.0F, 1.0F, 1.0F).texOffs(536, 163).addBox(-42.0F, -26.0F, -14.0F, 130.0F, 1.0F, 1.0F).texOffs(478, 134).addBox(-86.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(482, 134).addBox(-86.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(486, 134).addBox(-75.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(490, 134).addBox(-75.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(494, 134).addBox(-42.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(498, 134).addBox(-42.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(502, 134).addBox(-10.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(506, 134).addBox(-10.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(510, 134).addBox(22.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(514, 134).addBox(22.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(518, 134).addBox(54.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(522, 134).addBox(54.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(526, 134).addBox(87.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(530, 134).addBox(87.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("pilotof", CubeListBuilder.create().texOffs(122, 146).addBox(-98.0F, -11.0F, -1.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("piloto_rayasf", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -20.0F, 0.0F, 4.0F, 20.0F, 52.0F), PartPose.offset(-94.0F, -5.0F, -13.0F));
        g.addOrReplaceChild("pilotot", CubeListBuilder.create().texOffs(136, 146).addBox(94.0F, -11.0F, -1.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("piloto_rayast", CubeListBuilder.create().texOffs(112, 0).addBox(0.0F, -20.0F, 0.0F, 4.0F, 20.0F, 52.0F), PartPose.offset(92.0F, -5.0F, -13.0F));
        g.addOrReplaceChild("capo_corto", CubeListBuilder.create().texOffs(742, 72).addBox(-88.0F, -28.0F, -10.0F, 16.0F, 13.0F, 20.0F).texOffs(580, 114).addBox(-88.0F, -31.0F, -7.0F, 16.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_corto_cantoi_0", CubeListBuilder.create().texOffs(750, 167).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -28.46352549156242F, -9.92658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_1", CubeListBuilder.create().texOffs(784, 167).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -29.34520337000113F, -9.640110266005152F, -2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_2", CubeListBuilder.create().texOffs(818, 167).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -30.09520337000113F, -9.095203370001132F, -2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_3", CubeListBuilder.create().texOffs(852, 167).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -30.640110266005152F, -8.345203370001132F, -2.670353755551325F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_4", CubeListBuilder.create().texOffs(886, 167).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -30.92658477444273F, -7.463525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_0", CubeListBuilder.create().texOffs(920, 167).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -28.46352549156242F, 9.92658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_1", CubeListBuilder.create().texOffs(954, 167).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -29.34520337000113F, 9.640110266005152F, 2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_2", CubeListBuilder.create().texOffs(988, 167).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -30.09520337000113F, 9.095203370001132F, 2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_3", CubeListBuilder.create().texOffs(0, 169).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -30.640110266005152F, 8.345203370001132F, 2.670353755551325F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_4", CubeListBuilder.create().texOffs(34, 169).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -30.92658477444273F, 7.463525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_tapaa", CubeListBuilder.create().texOffs(692, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 40.0F), PartPose.offset(-88.0F, -28.0F, -10.0F));
        g.addOrReplaceChild("capo_corto_tapab", CubeListBuilder.create().texOffs(774, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 40.0F), PartPose.offset(-73.0F, -28.0F, -10.0F));
        g.addOrReplaceChild("faro_a_0", CubeListBuilder.create().texOffs(248, 153).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(740, 114).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, -1.6F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_a_1", CubeListBuilder.create().texOffs(272, 153).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(764, 114).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, -1.6F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_a_2", CubeListBuilder.create().texOffs(296, 153).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(788, 114).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, -1.6F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_a_3", CubeListBuilder.create().texOffs(320, 153).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(812, 114).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, -1.6F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_a_vidrio", CubeListBuilder.create().texOffs(24, 134).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-89.02000000000001F, -28.0F, -1.6F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_0", CubeListBuilder.create().texOffs(344, 153).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(836, 114).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, 1.6F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_1", CubeListBuilder.create().texOffs(368, 153).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(860, 114).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, 1.6F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_2", CubeListBuilder.create().texOffs(392, 153).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(884, 114).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, 1.6F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_3", CubeListBuilder.create().texOffs(416, 153).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(908, 114).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, 1.6F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_vidrio", CubeListBuilder.create().texOffs(64, 134).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-89.02000000000001F, -28.0F, 1.6F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(224, 0).addBox(-72.0F, -38.0F, -14.0F, 26.0F, 23.0F, 28.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(470, 146).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -38.16644998527687F, -12.952375688249639F, -2.5706682836287893F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(532, 146).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -39.39999781853689F, -10.793045647306894F, -2.6744727145307907F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(594, 146).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -40.403159959547146F, -8.517521048120587F, -2.7782771454327917F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(656, 146).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -41.165136678034074F, -6.1502994777680815F, -2.8820815763347922F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(718, 146).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -41.67772477064898F, -3.7168657042768674F, -2.985886007236793F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(780, 146).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -41.93540587409307F, -1.2434173155721182F, -3.0896904381387915F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(842, 146).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -41.93540587409307F, 1.2434173155721167F, 3.0896904381387915F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(904, 146).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -41.67772477064898F, 3.7168657042768647F, 2.9858860072367936F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(0, 153).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -41.165136678034074F, 6.1502994777680815F, 2.8820815763347922F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(62, 153).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -40.403159959547146F, 8.517521048120587F, 2.7782771454327917F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(124, 153).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -39.39999781853689F, 10.79304564730689F, 2.6744727145307907F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(186, 153).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -38.16644998527687F, 12.952375688249639F, 2.5706682836287897F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo", CubeListBuilder.create().texOffs(0, 72).addBox(-46.0F, -35.0F, -11.0F, 136.0F, 20.0F, 22.0F).texOffs(0, 114).addBox(-46.0F, -37.0F, -9.0F, 136.0F, 2.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_largo_cantoi_0", CubeListBuilder.create().texOffs(0, 157).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -35.30901699437494F, -10.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_1", CubeListBuilder.create().texOffs(274, 157).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -35.89680224666742F, -10.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_2", CubeListBuilder.create().texOffs(548, 157).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -36.39680224666742F, -10.39680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_3", CubeListBuilder.create().texOffs(0, 159).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -36.7600735106701F, -9.89680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_4", CubeListBuilder.create().texOffs(274, 159).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -36.951056516295154F, -9.309016994374947F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_0", CubeListBuilder.create().texOffs(548, 159).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -35.30901699437494F, 10.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_1", CubeListBuilder.create().texOffs(0, 161).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -35.89680224666742F, 10.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_2", CubeListBuilder.create().texOffs(274, 161).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -36.39680224666742F, 10.39680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_3", CubeListBuilder.create().texOffs(548, 161).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -36.7600735106701F, 9.89680224666742F, 2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_4", CubeListBuilder.create().texOffs(0, 163).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -36.951056516295154F, 9.309016994374947F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_tapaa", CubeListBuilder.create().texOffs(512, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 44.0F), PartPose.offset(-46.0F, -35.0F, -11.0F));
        g.addOrReplaceChild("capo_largo_tapab", CubeListBuilder.create().texOffs(602, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 44.0F), PartPose.offset(89.0F, -35.0F, -11.0F));
        g.addOrReplaceChild("freno_dinamico", CubeListBuilder.create().texOffs(492, 114).addBox(-40.0F, -39.0F, -9.0F, 26.0F, 2.0F, 18.0F).texOffs(534, 134).addBox(56.0F, -35.0F, 11.0F, 34.0F, 9.0F, 1.0F).texOffs(604, 134).addBox(56.0F, -35.0F, -12.0F, 34.0F, 9.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("ventilador60_0", CubeListBuilder.create().texOffs(602, 153).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(144, 134).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(60.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador60_1", CubeListBuilder.create().texOffs(626, 153).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(168, 134).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador60_2", CubeListBuilder.create().texOffs(650, 153).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(192, 134).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador60_3", CubeListBuilder.create().texOffs(674, 153).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(216, 134).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("ventilador72_0", CubeListBuilder.create().texOffs(698, 153).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(240, 134).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(72.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador72_1", CubeListBuilder.create().texOffs(722, 153).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(264, 134).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(72.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador72_2", CubeListBuilder.create().texOffs(746, 153).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(288, 134).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(72.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador72_3", CubeListBuilder.create().texOffs(770, 153).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(312, 134).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(72.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("ventilador84_0", CubeListBuilder.create().texOffs(794, 153).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(336, 134).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(84.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador84_1", CubeListBuilder.create().texOffs(818, 153).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(360, 134).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(84.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador84_2", CubeListBuilder.create().texOffs(842, 153).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(384, 134).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(84.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador84_3", CubeListBuilder.create().texOffs(866, 153).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(408, 134).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(84.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("escape", CubeListBuilder.create().texOffs(102, 146).addBox(0.0F, -39.0F, -2.0F, 6.0F, 2.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("bocina_0", CubeListBuilder.create().texOffs(704, 114).addBox(-40.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(640, 114).addBox(-40.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -39.5F, 0.0F));
        g.addOrReplaceChild("bocina_1", CubeListBuilder.create().texOffs(722, 114).addBox(-40.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(672, 114).addBox(-40.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -39.5F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("faro_t_0", CubeListBuilder.create().texOffs(440, 153).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(932, 114).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(90.4F, -33.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_1", CubeListBuilder.create().texOffs(464, 153).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(956, 114).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(90.4F, -33.0F, 0.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_2", CubeListBuilder.create().texOffs(488, 153).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(980, 114).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(90.4F, -33.0F, 0.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_3", CubeListBuilder.create().texOffs(512, 153).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(0, 134).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(90.4F, -33.0F, 0.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_vidrio", CubeListBuilder.create().texOffs(104, 134).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(91.02000000000001F, -33.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "tanque_cantoi_0", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "tanque_cantoi_1", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "tanque_cantoi_2", 1.0F, 1.0F, 0.6257378601609229F);
        escalar(g0, "tanque_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "tanque_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "tanque_cantod_0", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "tanque_cantod_1", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "tanque_cantod_2", 1.0F, 1.0F, 0.6257378601609229F);
        escalar(g0, "tanque_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "tanque_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "tanque_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "tanque_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "piloto_rayasf", 0.5F, 0.5F, 0.5F);
        escalar(g0, "piloto_rayast", 0.5F, 0.5F, 0.5F);
        escalar(g0, "capo_corto_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_corto_cantoi_1", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_corto_cantoi_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g0, "capo_corto_cantoi_3", 1.0F, 1.0F, 0.9386067902413854F);
        escalar(g0, "capo_corto_cantoi_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "capo_corto_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_corto_cantod_1", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_corto_cantod_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g0, "capo_corto_cantod_3", 1.0F, 1.0F, 0.9386067902413854F);
        escalar(g0, "capo_corto_cantod_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "capo_corto_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_corto_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_a_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_a_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_a_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_a_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_a_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "faro_b_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_b_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_b_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_b_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_b_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "cabina_techo_0", 1.0007142857142857F, 1.0F, 0.8367293207319423F);
        escalar(g0, "cabina_techo_1", 1.0007142857142857F, 1.0F, 0.8367293207319428F);
        escalar(g0, "cabina_techo_2", 1.0007142857142857F, 1.0F, 0.836729320731942F);
        escalar(g0, "cabina_techo_3", 1.0007142857142857F, 1.0F, 0.8367293207319423F);
        escalar(g0, "cabina_techo_4", 1.0007142857142857F, 1.0F, 0.8367293207319416F);
        escalar(g0, "cabina_techo_5", 1.0007142857142857F, 1.0F, 0.8367293207319427F);
        escalar(g0, "cabina_techo_6", 1.0007142857142857F, 1.0F, 0.8367293207319416F);
        escalar(g0, "cabina_techo_7", 1.0007142857142857F, 1.0F, 0.8367293207319424F);
        escalar(g0, "cabina_techo_8", 1.0007142857142857F, 1.0F, 0.8367293207319425F);
        escalar(g0, "cabina_techo_9", 1.0007142857142857F, 1.0F, 0.8367293207319414F);
        escalar(g0, "cabina_techo_10", 1.0007142857142857F, 1.0F, 0.8367293207319428F);
        escalar(g0, "cabina_techo_11", 1.0007142857142857F, 1.0F, 0.8367293207319427F);
        escalar(g0, "capo_largo_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_largo_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_largo_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_largo_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_largo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_largo_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_largo_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_largo_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_largo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_largo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "ventilador60_0", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador60_1", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador60_2", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador60_3", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador72_0", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador72_1", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador72_2", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador72_3", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador84_0", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador84_1", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador84_2", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador84_3", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "bocina_0", 1.0F, 0.1077859454596501F, 0.1077859454596501F);
        escalar(g0, "bocina_1", 1.0F, 0.1077859454596501F, 0.1077859454596501F);
        escalar(g0, "faro_t_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_vidrio", 0.24F, 0.15F, 0.24F);
    }
}
