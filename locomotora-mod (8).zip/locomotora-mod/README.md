# 🚂 Locomotoras de Vapor y Diésel — mod para NeoForge 1.21.1

Locomotoras de trenes reales al estilo Traincraft, de **hasta 3 bloques de alto**, que andan sobre los rieles normales de Minecraft. Tienen marchas (incluida marcha atrás), silbato o bocina, humo, ruedas y bielas animadas, y empujan las vagonetas que tengan adelante.

## Las locomotoras

Son 24 trenes reales: 16 de vapor y 8 diésel.

![Las de vapor](docs/vapor.png)
![Vapor, segunda tanda](docs/vapor2.png)
![Las diésel](docs/diesel.png)

| Locomotora | Qué es | Velocidad máxima | Sonido |
|---|---|---|---|
| **Flying Scotsman** | Vapor británica de 1923 (Pacific 4-6-2), verde manzana, **con su ténder** | 8 bloques/s | silbato de campana |
| **A4 Mallard** | Vapor británica de 1938 con carenado aerodinámico azul: la más rápida del mundo (203 km/h), **con su ténder** | 8 bloques/s | silbato de acordes |
| **Big Boy** | Vapor norteamericana de 1941, articulada 4-8-8-4: **la unidad delantera gira en las curvas**, con ténder "ciempiés" | 7 bloques/s | silbato grave |
| **GS-4 Daylight** | Vapor norteamericana de 1941 (4-8-4) con la librea roja, naranja y negra del Daylight, **con su ténder** | 8 bloques/s | silbato grave |
| **BR 01** | Vapor alemana de 1926 (Pacific 4-6-2), negra con ruedas rojas y deflectores de humo, **con su ténder** | 8 bloques/s | silbato agudo |
| **Pannier** | Locomotora tanque británica de 1929 (0-6-0), con los tanques de agua a los costados de la caldera | 6 bloques/s, arranque rápido | silbato agudo |
| **Rocket** | La pionera británica de 1829 (0-2-2): caldera amarilla, chimenea blanca altísima y cilindros inclinados, **con su ténder** | 6 bloques/s | silbato agudo |
| **Jupiter** | 4-4-0 del Lejano Oeste de 1868: chimenea de globo, faro de cajón y quitapiedras, **con su ténder de leña** | 6 bloques/s | silbato agudo |
| **Hiawatha** | Aerodinámica norteamericana de 1935 (4-4-2) en gris, naranja y granate, con ruedas motrices de 2,13 m, **con su ténder** | 8 bloques/s | silbato |
| **PRR T1** | Duplex norteamericana de 1942 (4-4-4-4) con nariz de tiburón y dos juegos de bielas, **con su ténder** | 8 bloques/s | silbato grave |
| **N&W clase J** | Aerodinámica norteamericana de 1950 (4-8-4) con nariz de bala y franja roja, **con su ténder** | 8 bloques/s | silbato grave |
| **Merchant Navy** | Pacific británica de 1941 con carcasa lisa, verde, y ruedas de disco agujereadas, **con su ténder** | 8 bloques/s | silbato |
| **9F Evening Star** | La última vapor de British Railways (1960, 2-10-0), con diez ruedas motrices, **con su ténder** | 7 bloques/s | silbato |
| **D51** | La vapor japonesa más famosa (1936, 2-8-2), negra, **con su ténder** | 7 bloques/s | silbato agudo |
| **P36** | Soviética de 1950 (4-8-4), verde con franja roja y ruedas rojas, **con su ténder** | 8 bloques/s | silbato grave |
| **Garratt** | Articulada africana de 1955 (4-8-2+2-8-4): **la caldera va colgada entre dos unidades motrices** | 6 bloques/s | silbato grave |
| **EMD F7** | Diésel norteamericana de 1949: nariz "bulldog", verde con franja amarilla | 8 bloques/s | bocina americana |
| **V 200** | Diésel-hidráulica alemana de 1953: roja, con la "V" cromada y cabina en las dos puntas | 8 bloques/s, arranque rápido | bocina aguda |
| **InterCity 125** | Coche motor diésel británico de 1976 con nariz en cuña: el tren diésel más rápido del mundo (238 km/h) | 8 bloques/s, arranque rápido | bocina de dos tonos |
| **Deltic** | Diésel británica de 1961 con dos motores, verde en dos tonos y cabina en las dos puntas | 8 bloques/s | bocina británica |
| **EMD SD40-2** | Diésel de carga norteamericana de 1972, azul, con bogies de 3 ejes | 7 bloques/s | bocina americana |
| **GE ES44AC** | Diésel de carga norteamericana de 2003, cabina ancha y radiador grande atrás | 7 bloques/s | bocina grave |
| **DD51** | Diésel-hidráulica japonesa de 1962, roja, con la cabina en el medio entre dos capós | 7 bloques/s | bocina aguda |
| **Class 08** | Diésel de maniobras británica de 1952 (0-6-0 con bielas), azul con rayas de avispa | 5 bloques/s, arranque muy rápido | bocina |

Más imágenes de cada una: [Flying Scotsman](docs/reales_1.png) · [EMD F7](docs/reales_2.png) · [V 200](docs/reales_3.png) ·
[A4 Mallard](docs/tren_1.jpg) · [Big Boy](docs/tren_2.jpg) · [GS-4](docs/tren_3.jpg) · [BR 01](docs/tren_4.jpg) ·
[Pannier](docs/tren_5.jpg) · [InterCity 125](docs/tren_6.jpg) · [Deltic](docs/tren_7.jpg) · [SD40-2](docs/tren_8.jpg) ·
[ES44AC](docs/tren_9.jpg) · [DD51](docs/tren_10.jpg) · [Class 08](docs/tren_11.jpg) ·
[Rocket](docs/vapor_rocket.jpg) · [Jupiter](docs/vapor_jupiter.jpg) · [Hiawatha](docs/vapor_hiawatha.jpg) ·
[PRR T1](docs/vapor_t1.jpg) · [N&W J](docs/vapor_nwj.jpg) · [Merchant Navy](docs/vapor_merchant.jpg) ·
[9F](docs/vapor_br9f.jpg) · [D51](docs/vapor_d51.jpg) · [P36](docs/vapor_p36.jpg) · [Garratt](docs/vapor_garratt.jpg)

- Están hechas en la escala de Traincraft (16 píxeles por bloque) y con **superficies curvas de verdad**: narices, calderas, carenados, domos y techos lisos, sin escalones. Los faros son redondos. No llevan logos de empresas reales.
- Miden de 4 a 24 bloques de largo y **siguen la vía con sus bogies**: en las curvas y en las subidas cada cuerpo se apoya en los rieles como un tren de verdad. Los ténderes van articulados detrás de la locomotora, la unidad motriz delantera de la Big Boy gira debajo de la caldera, como en la real, y en la Garratt la caldera va colgada entre sus dos unidades motrices.
- Las curvas de Minecraft giran 90° en un solo bloque, así que en una curva los trenes largos cortan camino por adentro. Se lucen en rectas largas.
- Las de vapor usan carbón; las diésel, bidones de diésel. Las bielas de las de vapor se mueven con la cinemática real: biela motriz, cruceta y pistón (la Big Boy y la T1 tienen dos juegos; la Rocket, cilindros inclinados).

## Cómo se usan

| Acción | Qué hace |
|---|---|
| Clic derecho **sobre un riel** con el ítem | Coloca la locomotora mirando hacia donde miras |
| Clic derecho con **carbón / carbón vegetal** (vapor) | Carga 1 pieza en la caldera (un **bloque de carbón** carga 9) |
| Clic derecho con un **bidón de diésel** (diésel) | Carga el tanque (un bidón rinde como 6 carbones) |
| Clic derecho con la **mano vacía** | Te subes a la cabina como maquinista |
| **Shift + clic derecho** | Arranca (alejándose de ti) o frena, sin subirte |
| Montado: **W** / **S** | Sube / baja la marcha: atrás ◀, freno ■, 1, 2, 3 |
| Montado: **A** o **D** | Suena el silbato o la bocina 🎵 |
| Montado: **Shift** | Te bajas |

- Gastan más combustible cuanto más rápido van. Con una pieza de carbón andan 4 minutos en marcha 1.
- La caldera o el tanque guarda hasta 40 carbones (casi 7 bidones). Si rompes la locomotora te devuelve lo que quedaba.
- Si choca contra algo y queda trabada, se frena sola.
- Un riel propulsor **apagado** la detiene (sirve como estación).
- Empuja a las vagonetas que tenga delante (o detrás, en marcha atrás) sin que se metan dentro del modelo.
- Necesita **2 bloques libres de alto** sobre la vía para pasar (aunque se vea de 3, el techo de los túneles puede atravesarla).
- Miden de 4 a 24 bloques de largo y siguen la vía con sus bogies.

## Recetas

**Bidón de diésel** (sin forma): 1 lingote de hierro + 2 carbones (o carbón vegetal) + 1 alga seca.

**Locomotoras** — con un riel arriba:

```
             [Riel]
[Lingote de hierro] [Horno, Alto horno o Pistón] [Lingote de hierro]
   [ X ]          [Vagoneta]          [ X ]
```

| Locomotora | Al medio | X (tinte) |
|---|---|---|
| Flying Scotsman | Horno | verde lima |
| A4 Mallard | Horno | azul |
| Big Boy | Horno | negro |
| GS-4 Daylight | Horno | naranja |
| BR 01 | Horno | rojo |
| Pannier | Horno | verde |
| EMD F7 | Pistón | verde |
| V 200 | Pistón | rojo |
| InterCity 125 | Pistón | amarillo |
| Deltic | Pistón | verde lima |
| EMD SD40-2 | Pistón | azul |
| GE ES44AC | Pistón | gris claro |
| DD51 | Pistón | naranja |
| Class 08 | Pistón | cian |
| Rocket | Alto horno | amarillo |
| Jupiter | Alto horno | azul |
| Hiawatha | Alto horno | naranja |
| PRR T1 | Alto horno | verde |
| N&W clase J | Alto horno | negro |
| Merchant Navy | Alto horno | verde lima |
| 9F Evening Star | Alto horno | gris |
| D51 | Alto horno | blanco |
| P36 | Alto horno | rojo |
| Garratt | Alto horno | violeta |

Todo está también en el modo creativo, en la pestaña **Herramientas y utilidades**.

## Compilar el mod en GitHub (sin instalar nada)

**Una sola vez:**

1. Entra a <https://github.com/new>, ponle un nombre (por ejemplo `locomotora-mod`) y toca **Create repository**.
2. En la página del repositorio vacío toca el enlace **creating a new file**.
3. Como nombre del archivo escribe `.github/workflows/build.yml` (cada `/` crea una carpeta).
4. Pega adentro el contenido del archivo `.github/workflows/build.yml` de este zip y toca **Commit changes**.

**Cada vez que tengas una versión nueva del mod:**

1. En el repositorio toca **Add file → Upload files**.
2. Arrastra el archivo `locomotora-mod.zip` **tal cual, sin descomprimirlo**, y toca **Commit changes**. Si ya había uno, se reemplaza; si quedan varios, se usa el último que subiste.
3. Ve a la pestaña **Actions**. Vas a ver "Compilar mod" corriendo (tarda unos 3–5 minutos la primera vez).
4. Cuando tenga el tilde verde ✅, entra a esa ejecución y abajo, en **Artifacts**, descarga **locomotora-mod**. Es un `.zip` que adentro tiene `locomotora-6.0.0.jar`.

También funciona si subes los archivos ya descomprimidos en vez del `.zip`, o un `.rar`.

Si sale una cruz roja ❌, entra a la ejecución, abre el paso que falló y copia el error para arreglarlo.

## Instalar en Minecraft

1. Instala **NeoForge para 1.21.1** desde <https://neoforged.net>.
2. Copia `locomotora-6.0.0.jar` a la carpeta `mods` de tu `.minecraft` (borra la versión vieja si la tenías).
3. Abre el juego con el perfil de NeoForge.

## Compilar en tu computadora (opcional)

Con Java 21 instalado:

```
./gradlew build          (Linux / Mac)
gradlew.bat build        (Windows)
```

El `.jar` queda en `build/libs/`. Para probarlo directamente: `./gradlew runClient`.

## Estructura del código

```
src/main/java/com/locomotora/
├── LocomotoraMod.java                 clase principal y pestaña creativa
├── entidad/LocomotoraEntity.java      la locomotora: motor, marchas, combustible, controles, humo, sonidos
├── entidad/TipoLocomotora.java        medidas, velocidades y tipo (vapor o diésel) de cada modelo
├── item/LocomotoraItem.java           el ítem que la coloca sobre los rieles
├── cliente/LocomotoraRenderer.java    dibuja el modelo y anima ruedas y bielas
├── cliente/LocomotoraCliente.java     registra los modelos y renderers
├── cliente/Via.java                   recorre los rieles para que los trenes largos sigan la vía
├── cliente/modelos/Modelo*.java       los modelos 3D (generados desde el estudio de diseño)
└── registro/                          ítems (incluido el bidón), entidades y sonidos
```

Las velocidades, la aceleración y el tono del silbato o bocina de cada locomotora están en `TipoLocomotora.java`; el consumo, la capacidad y lo que rinde un bidón, al principio de `LocomotoraEntity.java`.
